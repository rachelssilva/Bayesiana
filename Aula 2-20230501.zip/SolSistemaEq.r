# Programação Bayesiana             #
# Disciplina: Estatística Bayesiana #
# Curso: Estatística                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#

# Resolução de Sistema de Equações Lineares - Pacote 'matlib' do R
https://rstudio-pubs-static.s3.amazonaws.com/721780_26d9fcb2425d4023991c5fbb82a27713.html

# install.packages("matlib")
library(matlib)

# Exemplo
# 1*x1 + 4*x2 + 3*x3 = 1 
# 2*x1 + 5*x2 + 4*x3 = 4 
# 1*x1 - 3*x2 - 2*x3 = 5 

A = matrix(c(1,2,1,
             4,5,-3,
			 3,4,-2), ncol=3)
b = c(1,4,5)
showEqn(A,b)                    # Estrutura do Sistema de Equações
solve(A,b)                      # Solução do Sistema de Equações
#------------------------------------------------------------#

# Calculadora de Sistemas de Equações (Não)Lineares Online
# Symbolab
https://pt.symbolab.com/solver

# Exemplo
# a/(a+b) = 0.2                 # média da Beta
# a*b/((a+b)^2*(a+b+1)) = 0.01  # variância da Beta

# Basta digitar as equações 
a/(a+b) = 0.2, a*b/((a+b)^2*(a+b+1)) = 0.01 

# na aba 'resolver para' e 'ir'
https://pt.symbolab.com/solver/pre-calculus-solve-for-equation-calculator

# a solução será dada: a=3 e b=12
#------------------------------------------------------------#

# Outras referências:
# Wagner H. Bonat (UFPR)
http://www.leg.ufpr.br/lib/exe/fetch.php/disciplinas:nonlineareq.pdf
