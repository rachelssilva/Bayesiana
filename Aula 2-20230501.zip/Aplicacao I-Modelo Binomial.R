# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Aplica��o/Simula��o de distribui��es de probabilidade discretas
# Dados dicot�micos, Y ~ Bernoulli(theta)

rm(list=ls(all=TRUE))

# Logaritmo da Fun��o de Verossimilhan�a da Bernoulli (logFV)

lvero.bern = function(t,n,theta)
{
   t*log(theta)+(n-t)*log(1-theta)
}  
#--------------------------------------------#

# Aplica��o I(a) (Slide)
# H0: "N�o h� influ�ncia da predisposi��o gen�tica da determina��o do sexo do animal"
t = 437
n = 980
theta.aux = seq(0.001,0.999,0.01)   # vetor de valores entre 0 e 1
l.theta = lvero.bern(t,n,theta.aux) # respectivos c�lculos na logFV

# Gr�fico do logFV
# Op��o 1:
plot(theta.aux,l.theta,type='l',bty='n',xlab='theta',ylab='l(theta|y)')

# Op��o 2:
library(rpanel)
rp.likelihood("sum(log(dbinom(data, size=n, theta)))", t, 0, 1)

# Estimador Frequentista
theta.est = t/n # e.m.v.
theta.est

# Constru��o de Intervalo com 95% de Confian�a Assint�tico
var.est  = n/(theta.est*(1-theta.est))  # vari�ncia estimada de e.m.v
IC.theta = theta.est+qnorm(c(0.025,0.975))*sqrt(1/var.est)
IC.theta

# Gr�ficos das distribui��es
par(mfrow=c(1,3))
# Fun��o de verossimilhan�a: T|theta ~ Bin(n,theta)
veross    = rbinom(1000, n, theta.est)
theta.est = veross/n
hist(theta.est, main="", xlab=expression(paste(theta)),
     ylab=expression(paste("L(",theta, "|T)")), col="gray", bty='n')
#--------------------------------------------#

# Procedimento Bayesiano

# hiperpar�metros da Distribui��o a priori:
# theta ~ Beta(a,b)
a = 1
b = 1
priori = rbeta(1000, a, b)  # n�o informativa
hist(priori, main="", xlab=expression(paste(theta)),
     ylab=expression(paste(pi,"(",theta,")")), col="gray", bty='n')

# Distribui��o a posteriori theta|T ~ Beta(t+a,n-t+b)
posteriori = rbeta(1000, t+a, n-t+b)
hist(posteriori, main="", xlab=expression(paste(theta, "|T")),
     ylab=expression(paste(pi,"(",theta,"|T)")), col="gray", bty='n')

# Estimativas Bayesianas
mean(posteriori)			# m�dia dos dados gerados
var(posteriori) 			# vari�ncia dos dados gerados
median(posteriori)  	   # mediana dos dados gerados
quantile(posteriori, c(0.025, 0.975))   # ICr(theta): percentis 2,5% e 97,5%

# Conclus�o do TH:
# Como o valor do par�metro, sob Ho, de 0.5 n�o est� contido no ICr, 
# Conclui-se pela rejei��o no mesmo e, portanto a predisposi��o gen�tica
# influencia no sexo do animal.
#********************************************#

# Aplica��o I(b) (Slide)

# Considere uma pesquisa que tem por objetivo inferir
# a uma popula��o de bovinos, a respeito de theta, a preval�ncia da vaca louca.

rm(list=ls(all=TRUE))

lvero.bern = function(t,n,theta)
{
   t*log(theta)+(n-t)*log(1-theta)
}
#--------------------------------------------#

# Simula��o dos dados
set.seed(1)
theta  = 0.3
n      = 30
y      = rbinom(n,1,theta)
t      = sum(y)

lvero.bern(t,n,theta=0.5)

theta.aux = seq(0.001,0.999,0.01)
theta.aux
l.theta = lvero.bern(t,n,theta.aux)
l.theta

# Gr�fico do logFV
par(mfrow=c(1,1))
plot(theta.aux,l.theta,type='l',bty='n',xlab='theta',ylab='l(theta|y)')

# Estimador frequentista
theta.est = t/n # e.m.v.
theta.est

# Constru��o de Intervalo com 95% de Confian�a assint�tico
var.est = n/(theta.est*(1-theta.est))  # vari�ncia estimada de e.m.v
IC.theta = theta.est+qnorm(c(0.025,0.975))*sqrt(1/var.est)
IC.theta

# Gr�ficos das distribui��es
x11()
par(mfrow=c(1,3))
# Fun��o de verossimilhan�a: T|theta ~ Bin(n,theta)
veross = rbinom(1000, n, theta)
theta.est = veross/n
hist(theta.est, main="", xlab=expression(paste(theta)),
     ylab=expression(paste("L(",theta, "|T)")), col="gray", bty='n')
#--------------------------------------------#

# Procedimento Bayesiano

# Caso 1 - Assumindo Distribui��o N�O informativa a Priori:

# hiperpar�metros da Distribui��o a priori:
# theta ~ Beta(1,1) := U(0,1) (n�o informativa)
a = 1
b = 1
priori = rbeta(1000, a, b) # ou runif(1000,0,1)
hist(priori, main="", xlab=expression(paste(theta)),
     ylab=expression(paste(pi,"(",theta,")")), col="gray", bty='n')

# Distribui��o a posteriori theta|T ~ Beta(t+a,n-t+b)
posteriori = rbeta(1000, t+a, n-t+b)
hist(posteriori, main="", xlab=expression(paste(theta, "|T")),
     ylab=expression(paste(pi,"(",theta,"|T)")), col="gray", bty='n')

# Gr�ficos simult�neos das distribui��es
x11()
par(mfrow=c(1,1))
plot(density(theta.est), xlim=c(0,1), ylim=c(0,6), main="",
     xlab=expression(paste(theta)), ylab="Densidade", lty=1, col=1, bty='n')
lines(density(priori), lty=2, col=2)
lines(density(posteriori), lty=1, col=2)
legend(0.6, 6, c("Verossimilhan�a","Priori n�o informativa","Posteriori"),
       lty=c(1,2,1), col=c(1,2,2), bty="n", cex=.8)

# Estimativas Bayesianas
mean(posteriori)			# m�dia dos dados gerados
var(posteriori) 			# vari�ncia dos dados gerados
median(posteriori) 	   # mediana dos dados gerados
quantile(posteriori, c(0.025, 0.975))   # ICr(theta): percentis 2,5% e 97,5%
#--------------------------------------------#

# Caso 2 - Assumindo Distribui��o Informativa a Priori:

# Se desejo informar a priori, deve determinar os valores dos
# hiperpar�metros 'a' e 'b' de uma distribui��o Beta, tais que
# a m�dia e uma medida de dispers�o, s�o conhecidos previamente, 
# digamos, m�dia = 0,20 e vari�ncia = 0,01. 

# A solu��o ser� via sistema de duas equa��es com duas inc�gnitas,
# considerando a m�dia e vari�ncia alg�bricas da Beta.

# Sugest�o: Usar um programa alg�brico como o 'Maple' como descrito no
# arquivo: "SolSistemaEq_Beta-SoftwareMaple.mw", assim, teremos:

a = 3
b = 12
priori2 = rbeta(1000, a, b)

# Distribui��o a posteriori theta|T ~ Beta(t+a,n-t+b)
posteriori2 = rbeta(1000, t+a, n-t+b)

# Gr�ficos simult�neos das distribui��es
lines(density(priori2), lty=2, col=4)
lines(density(posteriori2), lty=1, col=4)
legend(0.6, 3, c("Priori informativa","Posteriori"),
       lty=c(2,1), col=c(4,4), bty="n", cex=.8)       

# Estimativas Bayesianas
mean(posteriori2)			# m�dia dos dados gerados
var(posteriori2) 		    # vari�ncia dos dados gerados
median(posteriori2) 	    # mediana dos dados gerados
quantile(posteriori2, c(0.025, 0.975))   # ICr(theta): percentis 2,5% e 97,5%

# Intervalo de Alta Densidade (HPD)
library(coda)
post1 = mcmc(posteriori)
HPDinterval(post1,prob=0.95)

post2 = mcmc(posteriori2)
HPDinterval(post2,prob=0.95)
