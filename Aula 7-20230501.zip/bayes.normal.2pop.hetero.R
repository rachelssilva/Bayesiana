# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

# Livrarias necess�rias para o procedimento Bayesiano
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar duas m�dias de popula��es normais
# com vari�ncias heterog�neas 

normal.2pop.hetero.bayes = function(iter,burn,salto,semente,y1,y2)
{
# Fun��o Bayesiana para comparar duas m�dias de popula��es normais
# com vari�ncias heterog�neas 
set.seed(semente)
y1 = y1
y2 = y2
n1 = length(y1)
n2 = length(y2)
sink("normal2pophetero.txt")
cat("
model
{
   for(i in 1:n1)
      {
       y1[i] ~ dnorm(mu1, tau1)
      }

   for(i in 1:n2)
      {
       y2[i] ~ dnorm(mu2, tau2)
      }
         mu1 ~  dnorm(0, 0.000001)
         mu2 ~  dnorm(0, 0.000001)
      delta1 <- mu1 - mu2   
        tau1 ~  dgamma(0.001,0.001)
     sigma1  <- 1/sqrt(tau1)
        tau2 ~  dgamma(0.001,0.001)
     sigma2  <- 1/sqrt(tau2)
      delta2 <- sigma1 - sigma2
}
",fill=TRUE)
sink()		  
modelo = "normal2pophetero.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,y1=y1,y2=y2)
# Valores iniciais
chutes = function() list(mu1=mean(y1),mu2=mean(y2),tau1=1,tau2=1)
# Par�metros
parametros = c("mu1","mu2","delta1","tau1","tau2","sigma1","sigma2","delta2")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("delta1"),samplesSample("delta2"),
                samplesSample("mu1"),samplesSample("mu2"),
                samplesSample("sigma1"),samplesSample("sigma2"),
				samplesSample("tau1"),samplesSample("tau2"))
# An�lise de converg�ncia
cat("\n---------------Diagn�stico de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n---------------Diagn�stico de Heidelberg e Welch---")
cat("\n ")
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M2

y1 = c(6.025, 7.577, 3.636, 5.703, 5.713, 5.59, 5.187,
       4.966, 3.678, 6.037, 2.22, 4.866, 5.015, 3.662)

y2 = c(3.145, 3.596, 5.508, 2.583, 2.999, 6.357, 7.011,
       3.522, 5.671, 3.673, 2.05, 3.069, 7.641, 3.495)

saida = normal.2pop.hetero.bayes(iter=10000,burn=1000,salto=1,semente=111,y1,y2)

sumario(saida)

# Sobreposi��o das distribui��es das m�dias a posteriori
Y1 = hist(saida[,1],plot=F)
Y2 = hist(saida[,2],plot=F)
plot(Y1, xlim=c(min(saida[,1],saida[,2]),max(saida[,1],saida[,2])), 
     col='skyblue', main="", xlab="Produ��o (g/col�nia)", ylab='Densidade', freq=F)
plot(Y2, col='blue', freq=F, add=T)
legend('topleft', c("Leves","Pesadas"), text.col=c('skyblue', 'blue'), bty='n')
#--------------------------------------------#

# Exerc�cio
# Utilize o arquivo "DadosPosturaCodornas.txt", 
# assuma que a vari�vel Y (Total de ovos postos) tem distribui��o Normal
# ent�o obtenha as estimativas Bayesianas para as m�dias, por linhagem de codornas (L1 vs L2),
# considerando popula��es heterog�neas.
# Ao final conclua se, h� diferen�a entre as produ��es m�dias das linhagens
# em n�vel de 95% de credibilidade.
