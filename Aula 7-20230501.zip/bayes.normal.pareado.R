# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar duas m�dias de popula��es normais dependentes

normal.par.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana para comparar duas m�dias de popula��es normais dependentes
set.seed(semente)
dif = dados[,2]-dados[,1]
n   = length(dif)
# O Modelo
sink("modelonormalpareado.txt")
cat("
model
{
   for( i in 1:n )
      {
       dif[i] ~ dnorm(mu.d, tau)
      }
        mu.d ~  dnorm(0, 0.000001)
         tau ~  dgamma(0.001,0.001)
       sigma <- 1/sqrt(tau)
}
",fill=TRUE)
sink()		
modelo     = "modelonormalpareado.txt"
dados.aux  = list(n=n, dif=dif)
chutes     = function()list(mu=mean(dif), tau=1)
parametros = c("mu.d","tau","sigma")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
print(res)
cadeias = cbind(samplesSample("mu.d"),samplesSample("tau"),samplesSample("sigma"))
cadeias = mcmc(cadeias)
print(heidel.diag(cadeias))
print(geweke.diag(cadeias))
# Histogramas
par(mfrow=c(1,3))
hist(cadeias[,1],xlab=c(expression(paste(mu)),".d"),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,2],xlab=expression(paste(tau)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,3],xlab=expression(paste(sigma)),ylab="Frequ�ncia",main="",bty="n")
cadeias
}
#--------------------------------------------#

# Aplica��o M3
# N�veis de s�dio na sumplementa��o de sel�nio (tratamento)
y1    = c(0.036, 0.04, 0.096, 0.050, 0.094) # Pr�-tratamento
y2    = c(0.110, 0.13, 0.076, 0.080, 0.110) # P�s-tratamento
dados = cbind(y1,y2)
saida = normal.par.bayes(iter=10000,burn=1000,salto=1,semente=123,dados)
#--------------------------------------------#

# Exerc�cio
# Utilize o arquivo "DadosDietaPareado.txt", 
# assuma que a vari�vel Y (Peso em kg) tem distribui��o Normal.
# Tais dados s�o de pesos (kg) de pessoas, antes e depois de uma dieta para emagrecimento.
# Tem-se como objetivo testar ao n�vel de 95% de credibilidade se a dieta faz efeito.
# Em caso afirmativo saber se � boa ou ruim e apresar a medida do efeito da dieta!
