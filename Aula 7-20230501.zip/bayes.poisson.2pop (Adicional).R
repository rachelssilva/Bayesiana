# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar duas m�dias de popula��es Poisson 

poisson.2pop.bayes = function(iter,burn,salto,semente,y1,y2)
{
# Fun��o Bayesiana para comparar duas m�dias de popula��es Poisson 
set.seed(semente)
y1 = y1
y2 = y2
n1 = length(y1)
n2 = length(y2)
# modelo
sink("modeloPoisson2medias.txt")
cat("
model
{
   for(i in 1:n1) { y1[i] ~ dpois(mu1) }
   for(i in 1:n2) { y2[i] ~ dpois(mu2) }
   mu1 ~ dgamma(0.001, 0.001)
   mu2 ~ dgamma(0.001, 0.001)
   delta <- mu1 - mu2
}
",fill=TRUE)
sink()		    
modelo = "modeloPoisson2medias.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,y1=y1,y2=y2)
# Valores iniciais
chutes = function() list(mu1=mean(y1),mu2=mean(y2))
# Par�metros
parametros = c("mu1","mu2","delta")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("mu1"),samplesSample("mu2"),
                samplesSample("delta"))
# An�lise de converg�ncia
print(geweke.diag(cadeias))
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M4 (Adicional) - Aplica��o 3.3.9 (Rossi, 2011)
# Influ�ncia do sel�nio na produ��o de embri�es em cabras
# An�lise 1 - N�mero de O�citos vi�veis
y1 = c(45,26, 9, 3,32)  # Controles
y2 = c(46, 1,94,13,22)  # Tratados

saida1 = poisson.2pop.bayes(iter=10000,burn=1000,salto=1,semente=111,y1,y2)

# Sobreposi��o das distribui��es das m�dias a posteriori
Y1 = hist(saida1[,1],plot=F)
Y2 = hist(saida1[,2],plot=F)
plot(Y1, xlim=c(min(saida1[,1],saida1[,2]),max(saida1[,1],saida1[,2])),
     col='red', main="", xlab="N�mero de O�citos vi�veis", ylab='Densidade', freq=F)
plot(Y2, col='blue', freq=F, add=T)
legend('topright',c("Controles","Tratados"),text.col=c('red','blue'),bty='n')
#--------------------------------------------#

# An�lise 2 - N�mero de O�citos invi�veis
y1 = c( 4, 3,4,11) # Controles
y2 = c(17,19,4,5)  # Tratados
saida2 = poisson.2pop.bayes(iter=10000,burn=1000,salto=1,semente=123,y1,y2)

# Sobreposi��o das distribui��es das m�dias a posteriori
Y1 = hist(saida2[,1],plot=F)
Y2 = hist(saida2[,2],plot=F)
plot(Y1, xlim=c(min(saida2[,1],saida2[,2]),max(saida2[,1],saida2[,2])),
     col='red', main="", xlab="N�mero de O�citos invi�veis", ylab='Densidade', freq=F)
plot(Y2, col='blue', freq=F, add=T)
legend('topright',c("Controles","Tratados"),text.col=c('red','blue'),bty='n')
#--------------------------------------------#

# Exerc�cio
# Utilize o arquivo "DadosPosturaCodornas.txt", 
# assuma que a vari�vel Y (Total de ovos postos) tem distribui��o Poisson
# ent�o obtenha as estimativas Bayesianas para as m�dias, por linhagem de codornas.
# Ao final conclua se, h� diferen�a entre as produ��es m�dias das linhagens
# em n�vel de 95% de credibilidade.
