# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

# Livrarias necess�rias para o procedimento Bayesiano
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar duas m�dias de popula��es normais
# com vari�ncias homog�neas

normal.2pop.homo.bayes = function(iter,burn,salto,semente,y1,y2)
{
set.seed(semente)
y1 = y1
y2 = y2
n1 = length(y1)
n2 = length(y2)
sink("normal2pophomo.txt")
cat("
model
{
   for(i in 1:n1)
      {
       y1[i] ~ dnorm(mu1, tau)
      }

   for(i in 1:n2)
      {
       y2[i] ~ dnorm(mu2, tau)
      }
         mu1 ~  dnorm(0, 0.000001)
         mu2 ~  dnorm(0, 0.000001)
       delta <- mu1 - mu2   
         tau ~  dgamma(0.001,0.001)
      sigma  <- 1/sqrt(tau)
}
",fill=TRUE)
sink()		  
modelo = "normal2pophomo.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,y1=y1,y2=y2)
# Valores iniciais
chutes = function() list(mu1=mean(y1),mu2=mean(y2),tau=1)
# Par�metros
parametros = c("mu1","mu2","delta","tau","sigma")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("delta"),
                samplesSample("mu1"),samplesSample("mu2"),
                samplesSample("tau"),
				samplesSample("sigma"))
# An�lise de converg�ncia
cat("\n---------------Diagn�stico de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n---------------Diagn�stico de Heidelberg e Welch---")
cat("\n ")
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M1
# Ganho de peso de bovinos e o objetivo � comparar grupos de dietas.

y1 = c(135,125,131,119,136,138,139,125,131,134,
       129,134,126,132,141,131,135,132,139,132,
       126,135,134,128,130,138,128,127,131,124)

y2 = c(137,136,128,130,138,126,136,126,132,139,
       143,141,135,137,142,139,138,137,133,145,
       138,131,143,134,132,137,129,140,147,136)

saida = normal.2pop.homo.bayes(iter=100000,burn=10000,salto=1,semente=111,y1,y2)


sumario = function(amostra)
{
# Fun��o para retornar sum�rio a posteriori
e = matrix(0,ncol(amostra),5)
  for (k in 1:(ncol(amostra)))
		{
    e[k,1] = mean(amostra[,k])
    e[k,2] = sd(amostra[,k])
    e[k,3] = median(amostra[,k])
    e[k,4] = quantile(amostra[,k],0.025)
    e[k,5] = quantile(amostra[,k],0.975)
    }
est = round(e,5)
est.bayes = c("M�dia","Desvio-Padr�o","Mediana","P2.5%","P97.5%")
colnames(est)=(est.bayes)
est
}

sumario(saida)

# Sobreposi��o das distribui��es das m�dias a posteriori
Y1 = hist(saida[,1],plot=F)
Y2 = hist(saida[,2],plot=F)
plot(Y1, xlim=c(min(saida[,1],saida[,2]),max(saida[,1],saida[,2])), 
     col='red', main="", xlab = "Peso (kg)", ylab='Densidade', freq=F)
plot(Y2, col='green', freq=F, add=T)
legend('topleft', c("Ra��o","Pastagem"), text.col=c('red','green'), bty='n')
#--------------------------------------------#

# Exerc�cio
# Utilize o arquivo "DadosPosturaCodornas.txt", 
# assuma que a vari�vel Y (Total de ovos postos) tem distribui��o Normal
# ent�o obtenha as estimativas Bayesianas para as m�dias, por linhagem de codornas,
# considerando popula��es homog�neas.
# Ao final conclua se, h� diferen�a entre as produ��es m�dias das linhagens
# em n�vel de 95% de credibilidade.
