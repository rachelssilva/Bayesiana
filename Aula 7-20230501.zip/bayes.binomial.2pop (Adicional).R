# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

# Livrarias necess�rias para o procedimento Bayesiano
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar duas propor��es de popula��es Binomiais independentes 

binomial.2pop.bayes = function(iter,burn,salto,semente,y1,y2,N1,N2)
{
# Fun��o Bayesiana para comparar duas propor��es de popula��es Binomiais independentes 
set.seed(semente)
y1 = y1
y2 = y2
N1 = N1
N2 = N2
n1 = length(y1)
n2 = length(y2)
# modelo
sink("modelobinomial2pop.txt")
cat("
model
{
   for(i in 1:n1) { y1[i] ~ dbin(p1,N1[i]) }
   for(j in 1:n2) { y2[j] ~ dbin(p2,N2[j]) }
   p1 ~ dbeta(1,1)
   p2 ~ dbeta(1,1)
   delta <- p2 - p1
}
",fill=TRUE)
sink()		
modelo = "modelobinomial2pop.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,N1=N1,N2=N2,y1=y1,y2=y2)
# Valores iniciais
p10 = sum(y1)/sum(N1)
p20 = sum(y2)/sum(N2)
chutes = function() list(p1=p10,p2=p20)
# Par�metros
parametros = c("p1","p2","delta")
# Gerando amostras
res = BRugsFit(modelFile = modelo, data = dados.aux, inits = chutes,
               numChains = 1, parametersToSave = parametros, nBurnin = burn,
               nIter = iter, nThin = salto, DIC = TRUE, working.directory = NULL,
               digits = 5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("p1"),samplesSample("p2"),
                samplesSample("delta"))
# An�lise de converg�ncia
print(geweke.diag(cadeias))
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M5 (Adicional) - Aplica��o 3.3.9 (Rossi, 2011)

# Influ�ncia do sel�nio na produ��o de embri�es em cabras
# Y: N�mero de O�citos vi�veis
y1 = c(45,26,9,3,32)   # Controles
N1 = c(49,29,9,7,43)
y2 = c(46,1,94,13,22)  # Tratados
N2 = c(63,1,113,17,27)

saida = binomial.2pop.bayes(iter=10000,burn=1000,salto=1,semente=123,y1,y2,N1,N2)
