# Programação Bayesiana             #
# Disciplina: Estatística Bayesiana #
# Curso: Estatística                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula7")

# Teste unilateral para a média da Normal
# H0: mu  <= 3
# H1: mu  >  3

# Amostra aleatória, tal que Y ~ N(mu,1)
y = c(3.18, 3.27, 3.23, 3.2, 3.18, 3.19, 3.19, 3.27, 3.30, 3.15)
mean(y)
sd(y)

# Teste Frequentista
t.test(y, alternative=c("greater"), mu=3)
# p-value = 1.071e-07 # Rejeita-sa H0
#------------------------------------------------#

# Teste unilateral para a média da Normal via FB (Fator de Bayes)
# Supondo a priori mu ~ N(3,1)

library(BRugs)
library(coda)

FB.normal.bayes = function(iter,burn,salto,semente,dados)
{
# Função Bayesiana auxiliar para o cálculo do Fator de Bayes (FB)
# Caso especial do TH unilateral para a média da Normal
# H0: mu  <= 3
# H1: mu  >  3

# y  ~ dnorm(mu, 1)
# mu ~ dnorm(3, 1)

set.seed(semente)
y = dados
n = length(y)
sink("modeloFBnormal.txt")
cat("
model
{
   for( i in 1 : n ) 
   {
      y[i] ~ dnorm(mu, 1)
   }
   mu ~ dnorm(3, 1)
}
",fill=TRUE)
sink()		
modelo     = "modeloFBnormal.txt"
dados.aux  = list(n=n, y=y)
cat("\n---------------Estimativa frequentista---------------")
cat("\n ")
chutes     = function()list(mu=mean(y))
parametros = c("mu")
cat("\n-------------------------------------------------------")
cat("\n ")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
cat("\n---------------Estimativa Bayesiana---------------")
cat("\n ")					  
print(res)
cadeias = cbind(samplesSample("mu"))
cadeias = mcmc(cadeias)
cat("\n--------Análise de Convergência de Heidelberg e Welch----------")
cat("\n ")
print(heidel.diag(cadeias))
hist(cadeias[,1],xlab=expression(paste(mu, "|y")),ylab="Frequência",main="",bty="n")
cadeias
}

# Chamando a função
saida = FB.normal.bayes(iter=10000,burn=1000,salto=1,semente=123,y)
#------------------------------------------------#

# Cálculo das Razões de Chances (Odds) a priori e a posteriori:
# no R
set.seed(123)
# a priori
priori.H0 = pnorm(3, 3, 1)
priori.H0
# 0.5

priori.H1 = 1 - priori.H0
priori.H1
# 0.5

priori.FB = priori.H0/priori.H1
priori.FB
# 1

# a posteriori
set.seed(123)
posteriori.H0 = pnorm(3, mean(saida[,1]), sd(saida[,1])) # parâmetros provenientes da simulação
posteriori.H0
# 0.2600582

posteriori.H1 = 1 - posteriori.H0
posteriori.H1
# 0.7399418

posteriori.FB = posteriori.H0/posteriori.H1
posteriori.FB
# 0.3514576

# Fator de Bayes
FB = posteriori.FB/priori.FB
FB
# 0.3514576

# Uma aproximação ao p-valor frequentista:
p.valorFB = priori.H0*FB/(priori.H0*FB+priori.H1) 
p.valorFB
# 0.2600582 -> Baseado neste valor, pode-se concluir que
#              seja improvável que a média seja maior do que 3.
#------------------------------------------------#

# Observação: Há uma livraria que faz tudo isso: "LearnBayes"
library(LearnBayes)
pop.s = 1          # desvio-padrão populacional (conhecido ou estimado)
data  = c(mean(y),length(y),pop.s)
prior.par = c(3,1) # parâmetros da priori 
mu0   = 3          # média sob Hipótese nula
mnormt.onesided(mu0, prior.par, data)
# $BF
# 0.3466887

# $prior.odds
# 1

# $post.odds
# 0.3466887

# $postH
# 0.2574379 -> Baseado neste valor, pode-se concluir que
               # seja improvável que a média seja maior do que 3.
