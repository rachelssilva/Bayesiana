# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula8")
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar tr�s m�dias de popula��es Poisson 

poisson.3pop.bayes = function(iter,burn,salto,semente,y1,y2,y3)
{
set.seed(semente)
y1 = y1
y2 = y2
y3 = y3
n1 = length(y1)
n2 = length(y2)
n3 = length(y3)
# modelo
sink("modeloPoisson3medias.txt")
cat("
model
{
   for( i in 1 : n1 ) { y1[i] ~ dpois(mu1) }
   for( i in 1 : n2 ) { y2[i] ~ dpois(mu2) }
   for( i in 1 : n3 ) { y3[i] ~ dpois(mu3) }
   mu1 ~ dgamma(0.001,0.001)
   mu2 ~ dgamma(0.001,0.001)
   mu3 ~ dgamma(0.001,0.001)
   delta1 <- mu1 - mu2
   delta2 <- mu1 - mu3
   delta3 <- mu2 - mu3
}
",fill=TRUE)
sink()		    
modelo = "modeloPoisson3medias.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,n3=n3,y1=y1,y2=y2,y3=y3)
# Valores iniciais
mu10 = mean(y1)
mu20 = mean(y2)
mu30 = mean(y3)
chutes = function() list(mu1=mu10,mu2=mu20,mu3=mu30)
# Par�metros
parametros = c("mu1","mu2","mu3","delta1","delta2","delta3")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("mu1"),samplesSample("mu2"),samplesSample("mu3"),
                samplesSample("delta1"),samplesSample("delta2"),
                samplesSample("delta3"))
# An�lise de converg�ncia
print(geweke.diag(cadeias))
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M7 - An�lise dos dados de produ��o de ovos de codornas (Aula 7),
#                assumindo resposta Poisson.

dados = read.table("DadosPosturaCodornas.txt",header=T) # Aula 7

y1 = dados[dados[,1]==1,2] # Linhagem Amarela
y2 = dados[dados[,1]==2,2] # Linhagem Azul
y3 = dados[dados[,1]==3,2] # Linhagem Vermelha

saida = poisson.3pop.bayes(iter=10000,burn=1000,salto=1,semente=123,y1,y2,y3)

par(mfrow=c(1,3))
hist(saida[,1])
hist(saida[,2])
hist(saida[,3])

# Estimativas Bayesianas para delta1=mu1-mu2
quantile(saida[,4],c(0.025,0.975)) # ICr(95%)
saida.delta1 = mcmc(saida[,4])
HPDinterval(saida.delta1,prob=0.95)
