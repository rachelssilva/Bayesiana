# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula8")
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar tr�s m�dias de popula��es normais 
# Modelo homoced�stico (vari�ncias iguais)

ANOVA.normal.homo3.bayes = function(iter,burn,salto,semente,y1,y2,y3)
{
set.seed(semente)
y1 = y1
y2 = y2
y3 = y3
n1 = length(y1)
n2 = length(y2)
n3 = length(y3)
# O Modelo
sink("modelonormalhomo3.txt")
cat("
model
{
   for( i in 1 : n1 ) { y1[i] ~ dnorm(mu1,tau)  }
   for( i in 1 : n2 ) { y2[i] ~ dnorm(mu2,tau)  }
   for( i in 1 : n3 ) { y3[i] ~ dnorm(mu3,tau)  }
   mu1 ~ dnorm(0,0.000001)
   mu2 ~ dnorm(0,0.000001) 
   mu3 ~ dnorm(0,0.000001)
   tau ~ dgamma(0.001,0.001)
   sigma <- 1/sqrt(tau)
   delta1 <- mu1 - mu2
   delta2 <- mu1 - mu3
   delta3 <- mu2 - mu3
}
",fill=TRUE)
sink()		
modelo = "modelonormalhomo3.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,n3=n3,y1=y1,y2=y2,y3=y3)
# Valores iniciais
chutes = function() list(mu1=mean(y1),mu2=mean(y2),mu3=mean(y3),tau=1)
# Par�metros
parametros = c("mu1","mu2","mu3","delta1","delta2","delta3","tau","sigma")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("mu1"),samplesSample("mu2"),samplesSample("mu3"),
                samplesSample("delta1"),samplesSample("delta2"),
                samplesSample("delta3"),
                samplesSample("tau"),samplesSample("sigma"))
# An�lise de converg�ncia
cat("\n---------------Diagn�stico de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n---------------Diagn�stico de Heidelberg e Welch---")
cat("\n ")
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M6 - An�lise dos dados de ganho de peso (kg) 
#                devido a 3 tratamentos (ra��es):
y1 = c(78.9, 72.3, 81.7, 85.7)
y2 = c(63.5, 74.1, 75.5, 80.8, 71.3, 74.5)
y3 = c(79.1, 90.3, 85.6, 81.4, 95.3)

# An�lise frequentista
y    = c(y1,y2,y3)
trat = factor(c(rep(1,length(y1)),rep(2,length(y2)),rep(3,length(y3))))
res  = aov(y ~ trat)
summary(res)

par(mfrow=c(3,2))
boxplot(y ~ trat, xlab="Tratamentos", ylab="Ganho de peso (kg)",
        names=c("Y1", "Y2", "Y3"),)
text( 
     x = 1:3, 
     y = c(max(y1), max(y2), max(y3)) + 0.5, 
     c('79,7 ab', '73,3 b', '86,3 a') 
    )
	
plot(res)

# Teste de Homogeneidade de Vari�ncias
bartlett.test(y,trat)

# Teste de Normalidade
shapiro.test(res$residuals)

# Contrastes entre as m�dias
TukeyHSD(res, "trat", ordered=TRUE, conf.level=0.95)
plot(TukeyHSD(res, "trat"))

library(laercio)
LTukey(res, "trat", conf.level=0.95)
#--------------------------------------------#

# An�lise Bayesiana
saida = ANOVA.normal.homo3.bayes(iter=10000,burn=1000,salto=1,semente=123,y1,y2,y3)

par(mfrow=c(1,3))
hist(saida[,1])
hist(saida[,2])
hist(saida[,3])

# Estimativas Bayesianas para mu1
quantile(saida[,1],c(0.025,0.975)) # ICr(95%)
saida.mu1 = mcmc(saida[,1])
HPDinterval(saida.mu1,prob=0.95)
