# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula8")
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar tr�s m�dias de popula��es Normais 
# Modelo Heteroced�stico (Vari�ncias diferentes)
 
ANOVA.normal.hetero3.bayes = function(iter,burn,salto,semente,y1,y2,y3)
{
set.seed(semente)
y1 = y1
y2 = y2
y3 = y3
n1 = length(y1)
n2 = length(y2)
n3 = length(y3)
# modelo
sink("modelonormalhetero3.txt")
cat("
model
{
   for( i in 1 : n1 ) { y1[i] ~ dnorm(mu1,tau1)  }
   for( i in 1 : n2 ) { y2[i] ~ dnorm(mu2,tau2)  }
   for( i in 1 : n3 ) { y3[i] ~ dnorm(mu3,tau3)  }
   mu1 ~ dnorm(0,0.000001)
   mu2 ~ dnorm(0,0.000001) 
   mu3 ~ dnorm(0,0.000001)
   tau1 ~ dgamma(0.001,0.001)
   tau2 ~ dgamma(0.001,0.001)
   tau3 ~ dgamma(0.001,0.001)
   sigma1 <- 1/sqrt(tau1)
   sigma2 <- 1/sqrt(tau2)
   sigma3 <- 1/sqrt(tau3)

# Contrastes para as m�dias
   delta1 <- mu1 - mu2
   delta2 <- mu1 - mu3
   delta3 <- mu2 - mu3

# Contrastes para os desvios-padr�o
   delta.s1 <- sigma1 - sigma2
   delta.s2 <- sigma1 - sigma3
   delta.s3 <- sigma2 - sigma3
}
",fill=TRUE)
sink()	
modelo = "modelonormalhetero3.txt"
# Entrada de dados
dados.aux = list(n1=n1,n2=n2,n3=n3,y1=y1,y2=y2,y3=y3)
# Valores iniciais
mu10 = mean(y1)
mu20 = mean(y2)
mu30 = mean(y3)
chutes = function() list(mu1=mu10,mu2=mu20,mu3=mu30,tau1=1,tau2=1,tau3=1)
# Par�metros
parametros = c("mu1","mu2","mu3","delta1","delta2","delta3",
               "tau1","tau2","tau3","sigma1","sigma2","sigma3",
               "delta.s1","delta.s2","delta.s3")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("mu1"),samplesSample("mu2"),samplesSample("mu3"),
                samplesSample("delta1"),samplesSample("delta2"),
                samplesSample("delta3"),
                samplesSample("tau1"),samplesSample("tau2"),
                samplesSample("tau3"),
                samplesSample("sigma1"),samplesSample("sigma2"),
                samplesSample("sigma3"),
                samplesSample("delta.s1"),samplesSample("delta.s2"),
                samplesSample("delta.s3"))
# An�lise de converg�ncia
print(geweke.diag(cadeias))
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o M6 - An�lise dos dados de ganho de peso (kg) 
#                devido a 3 tratamentos (ra��es):
y1 = c(78.9, 72.3, 81.7, 85.7)
y2 = c(63.5, 74.1, 75.5, 80.8, 71.3, 74.5)
y3 = c(79.1, 90.3, 85.6, 81.4, 95.3)

saida1 = ANOVA.normal.hetero3.bayes(iter=1000000,burn=10000,salto=10,semente=123,y1,y2,y3)
#--------------------------------------------#

# Aplica��o M7: An�lise dos dados de produ��o de ovos de codornas,
#               assumindo resposta normal.

# Arquivo: "DadosPosturaCodornas.txt" (Aula 7)
# Pressupostos: A vari�vel Y (Total de ovos postos) tem distribui��o Normal
#               e com vari�ncias hetorog�neas para as 3 linhagens de codornas.
# Objetivo: Concluir se, h� diferen�a entre as produ��es m�dias das linhagens  (L1 vs L2)
#           em n�vel de 95% de credibilidade.

dados = read.table("DadosPosturaCodornas.txt",header=T)

y1 = dados[dados[,1]==1,2] # Linhagem Amarela
y2 = dados[dados[,1]==2,2] # Linhagem Azul
y3 = dados[dados[,1]==3,2] # Linhagem Vermelha

saida2 = ANOVA.normal.hetero3.bayes(iter=10000,burn=1000,salto=1,semente=123,y1,y2,y3)

# Exerc�cio: Refazer a an�lise considerando outras distribui��es para Y: Poisson e Gama

