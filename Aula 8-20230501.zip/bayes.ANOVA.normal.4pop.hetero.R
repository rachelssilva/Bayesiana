# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para comparar quatro m�dias de popula��es normais 
# Modelo heteroced�stico (vari�ncias diferentes)

ANOVA.normal.hetero4.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana para comparar quatro m�dias de popula��es normais 
# Modelo heteroced�stico (vari�ncias diferentes)

set.seed(semente)
y1 = dados[dados[,2]==1,1]
y2 = dados[dados[,2]==2,1]
y3 = dados[dados[,2]==3,1]
y4 = dados[dados[,2]==4,1]
n1 = length(y1)
n2 = length(y2)
n3 = length(y3)
n4 = length(y4)
# O Modelo
sink("modelonormalhetero4.txt")
cat("
model
{
   for( i in 1 : n1 )   {  y1[i] ~ dnorm(mu1,tau1) }
   for( i in 1 : n2 )   {  y2[i] ~ dnorm(mu2,tau2) }
   for( i in 1 : n3 )   {  y3[i] ~ dnorm(mu3,tau3) }
   for( i in 1 : n4 )   {  y4[i] ~ dnorm(mu4,tau4) }
   mu1 ~ dnorm(0,0.000001)
   mu2 ~ dnorm(0,0.000001)
   mu3 ~ dnorm(0,0.000001)
   mu4 ~ dnorm(0,0.000001)
   tau1 ~ dgamma(0.001,0.001)
   tau2 ~ dgamma(0.001,0.001)
   tau3 ~ dgamma(0.001,0.001)
   tau4 ~ dgamma(0.001,0.001)
   sigma1 <- 1 / sqrt(tau1)
   sigma2 <- 1 / sqrt(tau2)
   sigma3 <- 1 / sqrt(tau3)
   sigma4 <- 1 / sqrt(tau4)
   d1 <- mu1 - mu2
   d2 <- mu1 - mu3
   d3 <- mu1 - mu4
   d4 <- mu2 - mu3
   d5 <- mu2 - mu4
   d6 <- mu3 - mu4
}
",fill=TRUE)
sink()		
modelo = "modelonormalhetero4.txt"
dados.aux = list(n1=n1,n2=n2,n3=n3,n4=n4,y1=y1,y2=y2,y3=y3,y4=y4)
cat("\n -------------Estimativas Frequentistas-------------")
y = dados[,1]
trat = dados[,2]
aov.aux = aov(y ~ factor(trat))
cat("\n Estimativas Frequentistas")
print(summary(aov.aux))
chutes = function() list(mu1=mean(y1),mu2=mean(y2),mu3=mean(y3),mu4=mean(y4),
                         tau1=1,tau2=1,tau3=1,tau4=1)
parametros = c("mu1","mu2","mu3","mu4",
               "d1","d2","d3","d4","d5","d6",
               "sigma1","sigma2","sigma3","sigma4",
               "tau1", "tau2", "tau3", "tau4")
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, 
               nBurnin=burn, nIter=iter, nThin=salto, 
               working.directory=NULL, digits=5)
cadeias=cbind(samplesSample("mu1"),samplesSample("mu2"),
              samplesSample("mu3"),samplesSample("mu4"),
              samplesSample("d1"),samplesSample("d2"),samplesSample("d3"),
              samplesSample("d4"),samplesSample("d5"),samplesSample("d6"),
              samplesSample("sigma1"),samplesSample("sigma2"),
              samplesSample("sigma3"),samplesSample("sigma4"),
              samplesSample("tau1"), samplesSample("tau2"),
              samplesSample("tau3"), samplesSample("tau4"))
print(heidel.diag(cadeias))
print(res)
cadeias
}
#--------------------------------------------#

# Aplica��o 4.3.1 (Rossi, 2011)
# Programa para comparar quatro tratamentos por meio da ANOVA
# em procedimento Bayesiano.
# Os dados a seguir foram obtidos de um experimento inteiramente casualisado no
# departamento de odontologia da UEM - Pr�tese,
# com objetivo de fazer compara��es entre 4 tratamentos (cimentos para endocrown)
# em corpos de prova (dentes de bovinos) submetidos a tens�o
# (m�quina Emic DL1000) at� ruptura.
# O objetivo foi o de testar ao n�vel de 5% de signific�ncia,
# por meio de compara��es Bayesianas,
# a hip�tese nula de igualdade entre tratamentos. 

# Chamando os dados
setwd("C:/Users/AulasPraticas/Aula8")
dados = read.table("DadosOdonto.txt",header=T,skip=0)
dados = as.matrix(dados)
#--------------------------------------------#

# An�lise Bayesiana
saida = ANOVA.normal.hetero4.bayes(iter=11000,burn=1000,salto=1,semente=123,dados=dados)

n     = length(saida[,1])
resB  = c(saida[,1],saida[,2],saida[,3],saida[,4])
tratB = factor(rep(1:4, c(n,n,n,n)),labels = c("1","2","3","4"))
boxplot(resB ~ tratB, xlab="Tratamento", ylab="Resist�ncia (a posteriori)")

# Resumo a posteriori
media  = tapply(resB, tratB, mean)
dp     = tapply(resB, tratB, sd)
cv     = dp/media
descritiva = rbind(media, dp, cv)
descritiva

# Op��o 2
library(gplots)
plotmeans(resB ~ tratB, ylim=c(200,700), connect=T, n.label=F,
          xlab="Tratamento", ylab="Resist�ncia (a posteriori)", bty="n")

ICr1 = quantile(saida[,1],c(0.025,0.975))
ICr2 = quantile(saida[,2],c(0.025,0.975))
ICr3 = quantile(saida[,3],c(0.025,0.975))
ICr4 = quantile(saida[,4],c(0.025,0.975))

segments(x0=1, x1=1, y0=ICr1[[1]], y1=ICr1[[2]])
segments(x0=2, x1=2, y0=ICr2[[1]], y1=ICr2[[2]])
segments(x0=3, x1=3, y0=ICr3[[1]], y1=ICr3[[2]])
segments(x0=4, x1=4, y0=ICr4[[1]], y1=ICr4[[2]])

# An�lise Bayesiana do log(y)
dadost = cbind(log(dados[,1]),dados[,2])
saidat = ANOVA.normal.hetero4.bayes(iter=11000,burn=1000,salto=1,semente=123,dados=dadost)
# As decis�es permanecem as mesmas!
#--------------------------------------------#

# An�lise Frequentista
trat = factor(dados[,2])
y    = dados[,1]
res  = aov(y ~ trat)
summary(res)
par(mfrow=c(3,2))
boxplot(y ~ trat)
plot(res)

# Teste de Homogeneidade de Vari�ncias
bartlett.test(y,trat)
# p-valor = 0.0008667 (Falha de pressuposto!)

# Teste de Normalidade
shapiro.test(res$residuals)
# p-valor = 0.2844 

# Contrastes
TukeyHSD(res, "trat", ordered=TRUE, data=dados, conf.level=0.95)
plot(TukeyHSD(res, "trat"))

library(laercio) 
LTukey(res, "trat", conf.level=0.95)
#--------------------------------------------#

# An�lise Frequentista dos dados transformados
yt   = log(y)
res  = aov(yt ~ trat)
summary(res)
par(mfrow=c(3,2))
boxplot(yt ~ trat)
plot(res)

# Teste de Homogeneidade de Vari�ncias
bartlett.test(yt,trat)
# p-valor = 0.002 (Falha de pressuposto!)

# Teste de Normalidade
shapiro.test(res$residuals)
# p-valor = 0.2553 

# Contrastes
TukeyHSD(res, "trat", ordered=TRUE, data=dados, conf.level=0.95)
plot(TukeyHSD(res, "trat"))
LTukey(res, "trat", conf.level=0.95)
# As decis�es se alteram!

