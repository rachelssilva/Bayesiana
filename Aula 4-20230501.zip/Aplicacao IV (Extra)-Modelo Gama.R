# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Aplica��o IV (Extra) por meio da distribui��o Gama

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula4")

# Livrarias necess�rias para o procedimento Bayesiano
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
library(MASS)
library(rpanel)
#--------------------------------------------#

# Lendo o arquivo de dados
dados = read.table("milho.txt",head=T); dados
attach(dados)
#--------------------------------------------#

# Estimativas Frequentistas
est = fitdistr(y,'gamma')
est
confint(est)

# OBSERVA��O: SE N�O FUNCIONAR NO RSTUDIO, ABRIR EM OUTRO EDITOR!
rp.likelihood("sum(log(dgamma(data, theta[1], theta[2])))",
              y, c(0.1, 0.01), c(15, 1))

# Montando uma fun��o:
gama.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana  para estimar par�metros e a m�dia de uma popula��o com erros Gama
# Y ~ Gama(alfa,beta); Y>0; alfa>0; beta>0
# alfa ~ Gama(a,b) : priori; a>0; b>0
# beta ~ Gama(c,d) : priori; c>0; d>0
# E = alfa/beta    : m�dia da Gama
# iter : N�mero de itera��es MCMC
# burn : N�mero de valores eliminados ("queima")
# salto: Tamanho dos saltos para eliminar poss�veil autocorrela��o
set.seed(semente)
y = dados
n = length(y)
sink("modelogama.txt")
cat("
model
{
   for(i in 1:n)
      {
       y[i] ~ dgamma(alfa, beta)
      }
         # Distribui��es a priori n�o informativas
         alfa ~  dgamma(0.001, 0.001)
         beta ~  dgamma(0.001, 0.001)
		 # M�dia da gama
         E <- alfa/beta 
}
",fill=TRUE)
sink()
modelo    = "modelogama.txt"
dados.aux = list(n=n, y=y)
est       = fitdistr(y,'gamma')
cat("\n---------------Estimativas Frequentistas---------------")
cat("\n ")
print(est)
chutes    = function()list(alfa=est[[1]][1], beta=est[[1]][2]) # Valores iniciais frequentistas
parametros = c("alfa","beta","E")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("alfa"),samplesSample("beta"),samplesSample("E"))
cadeias = mcmc(cadeias)
# An�lise de converg�ncia
cat("\n---------------An�lise de Converg�ncia de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n--------An�lise de Converg�ncia de Heidelberg e Welch----------")
cat("\n ")
print(heidel.diag(cadeias))
# Histogramas a posteriori
par(mfrow=c(1,3))
hist(cadeias[,1],xlab=expression(paste(alpha,"|y,",beta)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,2],xlab=expression(paste(beta,"|y,",alpha)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,3],xlab=expression(paste("E","|y,",alpha,",",beta)),ylab="Frequ�ncia",main="",bty="n")
cadeias
}

# Chamando a fun��o Gama
saida2 = gama.bayes(iter=10000,burn=1000,salto=1,semente=123,y)
