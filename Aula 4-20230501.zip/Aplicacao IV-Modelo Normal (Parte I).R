# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Aplica��o/Simula��o de distribui��es de probabilidade cont�nuas
# An�lise de dados cont�nuos, Y ~ Normal(mu,sigma)

rm(list=ls(all=TRUE))
# Exemplo Simulado
set.seed(2)
y = rnorm(50,0,1) # Simulando uma N(0,1)

library(rpanel)
rp.normal(y)
  
# Estimativas Frequentistas
rp.likelihood("sum(log(dnorm(data, theta[1], theta[2])))",
              y, c(-5, 0.01), c(5, 10))

library(MASS)
est = fitdistr(y,'normal')
est
#--------------------------------------------#

# Fun��o para obter estimativas Bayesianas
# via condicionais completas

Gibbs.Normal = function(a,b,s2,y,N,nburn,semente)
{
set.seed(semente)
# Fun��o para estima��o Bayesiana para dados Y~N(mu,sigma2)
# Amostrador de Gibbs (Gibbs Sampler) para dados Normais
# usando reparametriza��o tau = 1/(sigma2)
# via condicionais completas dos par�metros.

# Distribui��es a priori independentes:
# mu  ~ Normal(0;s2)
# tau ~ Gamma(a;b)
# s2, a, b s�o hiperpar�metros conhecidos
# N: n�mero de simula��es (itera��es)
# nburn: descarte ('queima') da primeiras simula��es

# n: tamanho da amostra
n        = length(y)
mu.post  = numeric(N)
tau.post = numeric(N)

# Valores iniciais para o processo MCMC
tau.post[1] = 1
mu.post[1]  = mean(y)

# C�lculos auxiliares
C           = 1/(n*tau.post[1] + 1/s2)
m           = C*mean(y)*n*tau.post[1]

# Processo MCMC (Gibbs)
for (i in 2:N)
    {
     mu.post[i]  = rnorm(1, m, sqrt(C))
#     tau.post[i] = rgamma(1, a+n/2, b+0.5*sum((y - mu.post[i])^2))
     tau.post[i] = rgamma(1, a+n/2, b+0.5*(sum(y^2)-2*sum(y)*mu.post[i]+n*mu.post[i]^2))
     # Atualiza��o
     C           = 1/(n*tau.post[i]+1/s2)
     m           = C*mean(y)*n*tau.post[i]
    }
sigma.post = 1/sqrt(tau.post)    
post = cbind(mu.post=mu.post, sigma.post=sigma.post, tau.post=tau.post)

# Realizando o descarte ('queima') da primeiras simula��es
post.final = post[(nburn+1):N,]  # amostra final � posteriori
}
#--------------------------------------------#

# Chamada da fun��o com distribui��es a priori n�o informativas:                       
res1 = Gibbs.Normal(a=0.001,b=0.001,s2=1000000,y,N=100,nburn=1,semente=123) 

# Verificando converg�ncia das cadeias
library(coda)          # ver Rossi (2011, p.75)
heidel.diag(res1)
geweke.diag(res1)
plot(res1[,1],type="l") # hist�rico do processo mcmc para mu
acf(res1[,1])           # Autocorrela��o 

res = Gibbs.Normal(a=0.001,b=0.001,s2=1000000,y,N=10000,nburn=1000,semente=123)
heidel.diag(res)
plot(res2[,1],type="l") # hist�rico do processo mcmc para mu

# Gr�ficos das distribui��es a posteriori
x11()
par(mfrow=c(3,1))
hist(res2[,1],main="",xlab=expression(paste(mu,"|y,",sigma)),ylab="Frequ�ncia")
hist(res[,2],main="",xlab=expression(paste(sigma,"|y,",mu)),ylab="Frequ�ncia")
hist(res2[,3],main="",xlab=expression(paste(tau,"|y,",mu)),ylab="Frequ�ncia")

# Estimativas Bayesianas para mu
media.mu = mean(res2[,1])
media.mu
sd.mu = sd(res2[,1])
sd.mu
quantile(res2[,1],c(0.025,0.975))

# Estimativas Bayesianas para sigma
media.sigma = mean(res2[,2])
media.sigma
sd.sigma = sd(res2[,2])
sd.sigma
quantile(res[,2],c(0.025,0.975))

# Estimativas Bayesianas para tau
media.tau = mean(res[,3])
media.tau
sd.tau = sd(res2[,3])
sd.tau
quantile(res2[,3],c(0.025,0.975))

sumario = function(amostra)
{
# Fun��o para retornar sum�rio a posteriori
e = matrix(0,ncol(amostra),5)
  for (k in 1:(ncol(amostra)))
		{
    e[k,1] = mean(amostra[,k])
    e[k,2] = sd(amostra[,k])
    e[k,3] = median(amostra[,k])
    e[k,4] = quantile(amostra[,k],0.025)
    e[k,5] = quantile(amostra[,k],0.975)
    }
est = round(e,5)
est.bayes = c("M�dia","Desvio-Padr�o","Mediana","P2.5%","P97.5%")
colnames(est)=(est.bayes)
est
}
sumario(res1)

f.descritiva = function(amostra,alfa)
{
# Fun��o c�lculo de Estat�sticas descritivas de um vetor
         e = matrix(0,1,5)
    e[1,1] = mean(amostra)
    e[1,2] = sd(amostra)
    e[1,3] = median(amostra)
    e[1,4] = quantile(amostra,alfa/2)
    e[1,5] = quantile(amostra,1-alfa/2)
est = round(e,5)
var.nomes= c("Estat�stica")
col.nomes = c("M�dia","DP","Mediana","P2.5%","P97.5%")
dimnames(est)=list(var.nomes,col.nomes)
est
}
f.descritiva(res1[,1],alfa=0.05)
#*******************************************************************************

# Aplica��o IV (Slide)
# Um grupo internacional quer modelar dados de
# produ��o de milho (tonelas) em suas propriedades,
# em um certo per�odo de observa��o:
y = c(17,22,23,23,23,23,24,24,24,24,24,24,25,25,25,25,25,25,25,26,28,28,29,
      30,30,31,31,35,35,35,36,40,41,41,41,42,51,54,56,56,56,58,60,68,79)

# ou lendo o arquivo de dados
setwd("C:/Users/AulasPraticas/Aula4")
dados = read.table("milho.txt",head=T)
attach(dados)

library(rpanel)
rp.normal(y)

# Estimativas Frequentistas
rp.likelihood("sum(log(dnorm(data, theta[1], theta[2])))",
              y, c(0, 0.001), c(100, 20))
library(MASS)
est = fitdistr(y,'normal')
est

# Estimativas Bayesianas via fun��o:
saida1 = Gibbs.Normal(a=0.001,b=0.001,s2=1000000,y,N=10000,nburn=1000,semente=123) 

# Verificando converg�ncia das cadeias
heidel.diag(saida1)
geweke.diag(saida1)

x11()
par(mfrow=c(2,1))
plot(saida1[,1],type="l") # hist�rico do processo mcmc para mu
acf(saida1[,1])           # Autocorrela��o 

# Gr�ficos das distribui��es a posteriori
x11()
par(mfrow=c(3,1))
hist(saida1[,1],main="",xlab=expression(paste(mu,"|y,",sigma)),ylab="Frequ�ncia")
hist(saida1[,2],main="",xlab=expression(paste(sigma,"|y,",mu)),ylab="Frequ�ncia")
hist(saida1[,3],main="",xlab=expression(paste(tau,"|y,",mu)),ylab="Frequ�ncia")

# Estimativas Bayesianas para mu
media.mu = mean(saida1[,1])
media.mu
sd.mu = sd(saida1[,1])
sd.mu
quantile(saida1[,1],c(0.025,0.975))

# Estimativas Bayesianas para sigma
media.sigma = mean(saida1[,2])
media.sigma
sd.sigma = sd(saida1[,2])
sd.sigma
quantile(saida1[,2],c(0.025,0.975))

# Estimativas Bayesianas para tau
media.tau = mean(saida1[,3])
media.tau
sd.tau = sd(saida1[,3])
sd.tau
quantile(saida1[,3],c(0.025,0.975))
