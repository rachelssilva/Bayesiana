# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#
    
# Aplica��o IV (Extra) por meio da distribui��o Poisson

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula4")

library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
library(MASS)
library(rpanel)
#--------------------------------------------#

# Lendo o arquivo de dados
dados = read.table("milho.txt",head=T)
attach(dados)

# Estimativas Frequentistas
est = fitdistr(y,'poisson')
est

rp.likelihood("sum(log(dpois(data, theta)))", y, 20, 50)

#----------------------------------------------------------#

poisson.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana  para estimar a m�dia em uma popula��o com erros Poisson
# Y ~ Poisson(theta); Y=0,1,2,...; theta>0
# theta ~ Gama(a,b) : m�dia a priori; a>0; b>0
# iter : N�mero de itera��es MCMC
# burn : N�mero de valores eliminados ("queima")
# salto: Tamanho dos saltos para eliminar poss�veil autocorrela��o
set.seed(semente)
y = dados
n = length(y)
sink("modelopoisson.txt")
cat("
model
{
 for(i in 1:n)
    {
     y[i] ~ dpois(theta)
    }
    # Distribui��o a priori n�o informativa
    theta ~  dgamma(0.001, 0.001)
}
",fill=TRUE)
sink()		
modelo = "modelopoisson.txt"
dados.aux  = list(n=n, y=y)
chutes     = function()list(theta=mean(y)) 
parametros = c("theta")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("theta"))
cadeias = mcmc(cadeias)
# An�lise de converg�ncia
cat("\n---------------An�lise de Converg�ncia de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n--------An�lise de Converg�ncia de Heidelberg e Welch----------")
cat("\n ")
print(heidel.diag(cadeias))
# Histograma a posteriori
hist(cadeias[,1],xlab=expression(paste(theta,"|y")),ylab="Frequ�ncia",main="",bty="n")
cadeias
}

# Chamando a fun��o
saida3 = poisson.bayes(iter=10000,burn=1000,salto=1,semente=123,y)
