# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Aplica��o/Simula��o de distribui��es de probabilidade cont�nuas
# An�lise de dados de tempos, Y ~ Exponencial(theta)

# Aplica��o III (Slide)
# Considere dados de tempo de vida de
# equipamentos eletr�nicos (anos)

rm(list=ls(all=TRUE))
y = c(14,21,9,19,12,4,9,7,15,9,7,5,15,19,10)
n = length(y)
n
y.bar = mean(y)
y.bar
t = sum(y)
t

# e.m.v. (Frequentista)
library(rpanel)
rp.likelihood("sum(log(dexp(data, theta)))", y, 0.001, 0.5)

emv1 = 1/y.bar
emv1
1/emv1

library(MASS)
emv2 = fitdistr(y,'exponential')
emv2
confint(emv2)
ttab = qnorm(c(0.025, 0.975))
IC   = emv2$est[[1]]+ttab*(emv2$sd[[1]])
1/IC

# Bayesiano
x11()
par(mfrow=c(1, 2))
a = 1
b = 0.001
priori = rgamma(1000, a, b)
hist(priori,main="", xlab=expression(paste(theta)), ylab="Densidade",
     col="gray",freq=F)
posteriori = 1/rgamma(1000, a+n, b+t)
hist(posteriori, main="", xlab=expression(paste(theta,"|y")),
     ylab="Densidade", col="gray",freq=F)
# Estimativas Bayesianas
mean(posteriori)			# m�dia estimada
mean(1/posteriori)		    # taxa estimada
median(posteriori) 		
var(posteriori) 			# vari�ncia dos dados gerados
sqrt(var(posteriori)) 
quantile(posteriori, c(0.025, 0.975))   # ICr(theta): percentis 2,5% e 97,5%
#******************************************************************************#

# Simula��o dos dados
rm(list=ls(all=TRUE))
set.seed(1)
media  = 6       # m�dia dos tempos
theta  = 1/media # taxa ou rate
theta
n      = 50
y      = rexp(n,theta)
t      = sum(y)

library(MASS)
fitdistr(y,'exponential') # Estima��o frequentista
#-----------------------------------#

# Gr�ficos das distribui��es
par(mfrow=c(1,3))
# Fun��o de verossimilhan�a: L(theta|T) ~ Gama(t+1,n)
veross = rgamma(1000, n+1, t)
E.veross =  1/veross # E(theta) � a m�dia!
hist(veross, main="", xlab=expression(paste(theta)),
     ylab=expression(paste("L(",theta, "|T)")), col="gray", bty='n')
# hiperpar�metros da Distribui��o � priori: theta ~ Gama(a,b)
a = 1
b = 0.001
priori = rgamma(1000, a, b)  # um pouco informativa
hist(priori, main="", xlab=expression(paste(theta)),
     ylab=expression(paste(pi,"(",theta,")")), col="gray", bty='n')
# Distribui��o � posteriori theta|T ~ Gama(n+a,t+b)
posteriori = rgamma(1000, n+a, t+b)
hist(posteriori, main="", xlab=expression(paste(theta, "|T")),
     ylab=expression(paste(pi,"(",theta,"|T)")), col="gray", bty='n')

# Gr�ficos simult�neos das distribui��es
par(mfrow=c(1,1))
plot(density(veross), xlim=c(0,0.3), ylim=c(0,30), main="",
     xlab=expression(paste(theta)), ylab="Densidade", lty=1, col=1, bty='n')
lines(density(priori), lty=2, col=2)
lines(density(posteriori), lty=1, col=2)
legend(0.2, 30, c("Verossimilhan�a","Priori","Posteriori"),
       lty=c(1,2,1), col=c(1,2,2), bty="n", cex=.7)

# Estimativas Bayesianas
mean(posteriori)			# taxa estimada
mean(1/posteriori)		    # m�dia estimada
median(posteriori) 		
var(posteriori) 			# vari�ncia dos dados gerados
sqrt(var(posteriori)) 
quantile(posteriori, c(0.025, 0.975))   # ICr(theta): percentis 2,5% e 97,5%
