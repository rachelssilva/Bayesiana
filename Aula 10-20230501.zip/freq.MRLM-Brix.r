# Prof. Robson M. Rossi        
# Regress�o Linear M�ltipla (Procedimento Frequentista)
# An�lise do banco de dados brix.txt

setwd("C:/Users/AulasPraticas/Aula10")
brix = read.table("dadosBrix.txt",header=T)
brix = brix[,-c(1)]
attach(brix)
brix

# Brix (s�mbolo �Bx) ou �ndice refractom�trico
# � uma escala num�rica que mede a quantidade 
# de s�lidos sol�veis em uma solu��o de sacarose.

# A escala de Brix, criada por Adolf Ferdinand Wenceslaus Brix (1873),
# foi baseada originalmente na escala de Balling, 
# recalculando a temperatura de refer�ncia de 15,5 �C.
# A aferi��o do �ndice refractom�trico duma dada 
# solu��o aquosa � realizada com recurso a 
# um refract�metro de escala percentual dos 0 a 30.

# A escala Brix � utilizada na ind�stria de alimentos 
# para medir a quantidade aproximada de a��cares em 
# sucos de fruta, vinhos e na ind�stria de a��car.
# Um grau Brix (1�Bx) � igual a 1 grama de a��car
# por 100 gramas de solu��o ou 1% de a��car.

# Fonte: https://pt.wikipedia.org/wiki/Grau_Brix

plot(brix, pch=16)

panel.cor = function(x, y, prefix = "", ...)
{
   usr  =  par("usr"); on.exit(par(usr))
   par(usr = c(0, 1, 0, 1))
   r    =  cor(x, y)
   txt  =  format(c(r, 0.123456789), digits = 2)[1]
   txt  =  paste0(prefix, txt)
   text(0.5, 0.5, txt, cex=2)
}
pairs(brix, upper.panel=panel.cor)

# Ajuste Modelo completo (M1)
fit1 = lm(Brix~Diametro+Altura+Peso+pH+Acucar)
summary(fit1)

# Ajuste Modelo somente com as significativas (M2)
fit2 = lm(Brix~Diametro+Acucar)
summary(fit2)    # Observe a n�o signific�ncia de 'Diametro'
anova(fit2,fit1) # Teste F para comparar modelos -> Rejeita M1

#-------------------- Sele��o de vari�veis --------------------#

# Utilizando as fun��es step (basic) e stepAIC (MASS) do R:

brix  = data.frame(Brix)
fit1  = lm(Brix~Diametro+Altura+Peso+pH+Acucar)

# Op��o "backward" - Para tr�s (default no R):
# Inicia-se com todas vari�veis no modelo e, segue excluindo uma-a-uma.
step1 = step(fit1)
step1$anova
# Op��o "forward" - Para frente:
# Inicia-se sem nenhuma vari�vel no modelo e, segue incluindo um-a-uma
# pela ordem de maior correla��o com y.
step2 = step(fit1, direction="forward")
# Op��o "both" - Ambos (Para frente e para tr�s):
step3 = step(fit1, direction="both")
#--------------------------------------------------------------#

# Observa��es:
# Os procedimentos de sele��o forward, elimina��o backward e sele��o stepwise,
# n�o necessariamente levam a escolha do mesmo modelo final;
# Recomenda-se que todos os procedimentos sejam aplicados na esperan�a de que
# haja alguma concord�ncia entre eles, ou mesmo para aprender algo mais sobre a
# estrutura dos dados;
# O procedimento de sele��o forward tende a concordar com o de todas as
# regress�es poss�veis para subconjuntos pequenos de regressoras, enquanto
# procedimento de elimina��o backward para subconjuntos grandes de regressoras;
# O modelo final obtido por qualquer um dos procedimentos deve ser analisado
# quanto ao seu sentido pr�tico.

# Quando n�o existe uma escolha clara da melhor equa��o de regress�o, j� que
# cada procedimento sugere, em geral, produz equa��es diferentes, todas as
# candidatas ao modelo final e devem ser analisadas quanto a sua adequacidade,
# pontos influentes, efeito de multicolinearidade etc.
# Para mais detalhes ver Giolo (2007, p.30-32)

Influencia = influence.measures(fit1)
Influencia
summary(Influencia)
# Influ�ncia dos coeficientes de regress�o - Pontos de corte:
# Di          > 1           (observa��o i poss�vel influente)
# |DFBetaj,i| > 2/raiz(n)   (amostras grandes)
# |DFBetaj,i| > 1           (amostras pequenas)
# |DFFiti|    > 2/raiz(p/n) (amostras grandes)
# |DFFiti|    > 1           (amostras pequenas)
# Covratioi   se fora do intervalo [1-3p/n, 1+3p/n], 
#             i � um poss�vel influente (amostras grandes)
# D de Cook   > 0.5
plot(fit1,which=c(1:4),pch=16,add.smooth=FALSE)

# VIF :  Fator de Infla��o da Vari�ncia (verifica��o de multicolinearidade)
#        reflete o montante de variabilidade explicada pela regress�o.
# Esperamos que VIF < 10.
library(car)
vif(fit1)  # Modelo completo 

# Sele��o de vari�veis por meio do procedimento Stepwise 
# Fonte: Blog de Paul A. Rubin
# http://orinanobworld.blogspot.ca/2011/02/stepwise-regression-in-r.html
# O Crit�rio � por meio da Estat�stica Cp de Mallows
# Giolo (2007, p.30-32) ou Draper e Smith (1988)

source("Stepwise.R")
stepwise(full.model = Brix~Diametro+Altura+Peso+pH+Acucar,
         initial.model = Brix~1,
         alpha.to.enter = 0.10,
         alpha.to.leave = 0.10)

# Observa��es:
# O valor nnS (Vari�ncia) -> quanto menor melhor!
# O valor Cp              -> quanto menor melhor!
# O R^2                   -> quanto maior melhor!

# Neste caso, somente a vari�vel A��car permanece no modelo!
#--------------------------------------------------------------#

step1 = step(fit1)
# Neste caso, todas as vari�veis permanecem no modelo!

# Entretanto, considerando o modelo: Brix = Diametro+Altura+Acucar
fit3 = lm(Brix~Diametro+Altura+Acucar)
summary(fit3)

predict(fit3, int="conf")
confint(fit3)
par(mfrow=c(2,2))
plot(fit3, which=c(1,2,4,5))
# Observe que ainda h� an�lises a considerar!

fit.model = fit3
x11()
source("envelr_normal.R")
envelr_normal(fit.model)

# op��es via pacote hnp
library(hnp)
hnp(fit3,halfnormal=FALSE)
hnp(fit3,halfnormal=TRUE)

# Infer�ncia para novas observa��es:
predict(fit3, new=data.frame(Diametro=c(2), Altura=c(2), Acucar=c(4)), interval="pred")
#**************************************************************#

# Exerc�cio: Realizar a an�lise de regress�o m�ltipla 
#            por meio de procedimento Bayesiano.

