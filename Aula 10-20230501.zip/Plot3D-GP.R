﻿# Prof. Robson M. Rossi        
# Regressão Linear Múltipla (Procedimento Frequentista)
# Criando gráficos 3D para duas variáveis contínuas

library(rgl)

# Função para cálculo de uma Superfície de Resposta
# Estimativas de um MRLM Com variáveis X1 e X2 Contínuas, ambas de grau 1
# Sem interação - Erros normais
sr.mrlm.1e1 = function(x1,x2,pars)
{
# Estimativas de um MRLM Com variáveis X1 e X2 Contínuas, ambas de grau 1
# Sem interação - Erros normais
# pars: parâmetros da regressão
  n1 = n2 = 100
  x1 = seq(min(x1), max(x1), length=n1)
  x2 = seq(min(x2), max(x2), length=n2)
  M.aux = matrix(0,n1,n2)
# modelo polinomial
  sr.1e1 = function (x1, x2)
         {
          y  = pars[1] + pars[2]*x1 + pars[3]*x2
          y
         }
# Cálculo da SR
  for (i in 1:n1)
      {
      for (j in 1:n2)
          {
           M.aux[i,j] = sr.1e1(x1[i],x2[j])
          }
      }         
  z = outer(x1, x2, sr.1e1)
  aux = unique(cbind(x1,x2,z))
# Gráfico da Superfície de Resposta
  library(rgl)
  persp3d(x1,x2,z,color="white",xlab="x1",ylab="x2",zlab="z",box=FALSE)
  aux
}

# Exemplo 1 - dados simulados
set.seed(2)
y   = c(rnorm(5,1),rnorm(5,5),rnorm(5,10),rnorm(5,15),rnorm(5,20),rnorm(5,30))
x1  = seq(-10, 10, length= 30)
x2  = sort(rbinom(30,size=5,prob=0.2))
reg = lm(y ~ x1 + x2)
summary(aov(reg))
pars  = coef(reg)
saida = sr.mrlm.1e1(x1,x2,pars=pars)
#------------------------------------------------------------------------------#

# Análise do banco de dadosGP.txt

# Aplicação 1: Dados da área zootécnica sobre Ganho de peso (g) animal (aves),
# em função de dois tratamentos: níveis de Arginina e Lisina na ração.

setwd("C:/Users/AulasPraticas/Aula10")
dados = read.table("dadosGP.txt",header=TRUE)
attach(dados)
x1 = arg
x2 = lis
y  = gp
dados0 = cbind(y,x1,x2); dados0

# Modelo com interação
reg = lm(y ~ x1 + I(x1^2) + x2 + I(x2^2) +x1*x2)
summary(reg)
     
# Gráfico 3D com Função Estimada para GP
n1 = n2 = 100 
A  = seq(1.22, 2.12, length=n1)  # Arginina
L  = seq(1.10, 2.00, length=n2)  # Lisina
GP.aux = matrix(0,n1,n2)
est = coef(reg)
GP = function (A, L)
   {
    gp = est[1]+est[2]*L+est[3]*L^2+est[4]*A+est[5]*A^2 
    gp
   }
    
for (i in 1:n1)
    {
      for (j in 1:n2)
          {
           GP.aux[i,j] = GP(A[i],L[j])
          }
    }
      
persp(A, L, GP.aux, theta=120, phi=30, d=1, expand = 1,
      xlab="Níveis de Arginina", ylab="Níveis de Lisina digestível (%)",
      zlab="Ganho de peso (g)", cex=0.2, ticktype = "detailed")      
#--------------------------------#

# Função para cálculo de uma Superfície de Resposta
# Estimativas de um MRLM Com variáveis X1 e X2 Contínuas, ambas de grau 2
# Sem interação - Erros normais
sr.mrlm.2e2 = function(x1, x2, pars)
{
# Função para cálculo de uma Superfície de Resposta
# Estimativas de um MRLM Com variáveis X1 e X2 Contínuas, ambas de grau 2
# Sem interação - Erros normais
# pars: parâmetros da regressão
  n1 = n2 = 100
  x1 = seq(min(x1), max(x1), length=n1)
  x2 = seq(min(x2), max(x2), length=n2)
  M.aux = matrix(0,n1,n2)
# modelo polinomial
  sr.2e2 = function (x1, x2)
               {
                y = pars[1]+pars[2]*x1+pars[3]*x1^2+pars[4]*x2+pars[5]*x2^2
                y
               }
# Cálculo da SR
  for (i in 1:n1)
      {
      for (j in 1:n2)
          {
           M.aux[i,j] = sr.2e2(x1[i],x2[j])
          }
      }
# Determinação do ponto máximo na SR e os níveis respectivos
  for (i in 1:n1)
      {
      for (j in 1:n2)
          {
             if (M.aux[i,j]==max(M.aux))
                {cat("\n","x1 =", x1[i], "x2 =", x2[j], "Máximo =", max(M.aux))}
          }
      }
  z = outer(x1, x2, sr.2e2)
  aux = unique(cbind(x1,x2,z))
# Gráfico da Superfície de Resposta
  library(rgl)
  persp3d(x1,x2,z,color="white",xlab="x1",ylab="x2",zlab="z",box=FALSE)
  aux
}

# Exemplo
n1 = n2 = 100 
x1 = seq(1.10, 2.00, length=n2)  
x2 = seq(1.22, 2.12, length=n1)  
pars  = est[1:5] 
saida = sr.mrlm.2e2(x1, x2, pars) 

