# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula10")
library(BRugs)  # Infer�ncia Bayesiana
library(coda)   # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para Regress�o Linear M�ltipla (Erros normais)

MRLM.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana para Regress�o Linear M�ltipla (Erros normais)
set.seed(semente)
# y: resposta
# X: matrix incid�ncia dos dados
y = dados[,1]
n = length(y)
p = ncol(dados)-1
x = as.matrix(dados[,-1])
sink("modeloMRLM.txt")
cat("
model
{
   for (i in 1:n)
	    {
          y[i] ~ dnorm(mu[i], tau)
         mu[i] <- beta0 + inprod(x[i, ], beta[])
		 # ver mais comandos em Nitzoufras (2009, p.94)
  	     }
         beta0 ~ dnorm(0, 0.000001)
   for (j in 1:p)
        {
         beta[j] ~ dnorm(0, 0.000001)
        }		 
        tau ~ dgamma(0.001, 0.001)
        sigma <- 1/sqrt(tau)
		sigma2 <- sigma*sigma
}
",fill=TRUE)
sink()		
modelo = "modeloMRLM.txt"
dados.aux = list(n=n, p=p, x=x, y=y)
cat("\n -------------Estimativas Frequentistas-------------")
cat("\n ")
reg = lm(y ~ x)
print(summary(reg))
beta.aux = numeric()
for (j in 1:(p+1))
 {
  beta.aux[j] = reg$coef[[j]] 
 }
beta.aux = beta.aux[2:(p+1)] 
chutes = function() list(beta0=reg$coef[1], beta=beta.aux, tau=1)
parametros = c("beta0","beta","sigma","sigma2","tau")
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros,
               nIter=iter, nBurnin=burn, nThin=salto,
               DIC=TRUE, working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)               
nome.beta = paste("beta[",1:p,"]",sep="")
cadeias = cbind(samplesSample("sigma"),samplesSample("sigma2"),
                samplesSample("tau"),samplesSample("beta0"))
for (j in 1:p)
 {
 cadeias = cbind(cadeias,samplesSample(nome.beta[j]))
 }
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----")
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Aplica��o 1: Aplic. 3.3.16 (Rossi, 2011).
# Birkes e Dodge (1993, Apud WinBUGS Examples Vol. I "Stacks: robust regression")
# aplicaram a regress�o linear m�ltipla em dados de
# Y: perda de empilhamento de materiais de Brownlee (1965)
#    em fun��o das vari�veis explicativas
# X1: quantidade de am�nia solta no fluxo de ar
# X2: temperatura (�C)
# X3: concentra��o de �cido (%) 

dados = read.table("dadosPerda.txt",header=TRUE)
dados = as.matrix(dados)
y     = dados[,1]
x1    = dados[,2]
x2    = dados[,3]
x3    = dados[,4]

# Gr�ficos descritivos
library(rpanel) 
rp.regression(x1, y)
rp.regression(x2, y)
rp.regression(x3, y)
rp.regression(cbind(x1, x2), y)
rp.regression(y ~ x1+x2+x3) # ind�cios de efeito ns em X3

# Procedimento Frequentista
Mc = lm(y ~ x1+x2+x3)
library(MASS)
select = stepAIC(Mc)
select$anova 
# Final Model: y ~ x1 + x2
#--------------------------------------------#

# Procedimento Bayesiano
# y~x1+x2+x3
M123 = MRLM.bayes(iter=1000000, burn=10000, salto=1, semente=123, dados=dados)

# y~x1+x2
M12 = MRLM.bayes(iter=500000, burn=10000, salto=1, semente=123, dados=dados[,1:3])

# y~x1+x3
M13 = MRLM.bayes(iter=500000, burn=10000, salto=1, semente=123, dados=dados[,c(1,2,4)])

# y~x2+x3
M23 = MRLM.bayes(iter=500000, burn=10000, salto=1, semente=123, dados=dados[,c(1,3,4)])

# Implementar a fun��o MRL.bayes (Aula 9)
# y~x1
M1 = MRL.bayes(iter=100000, burn=10000, salto=1, semente=123, x1, y, x0=20)

# y~x2
M2 = MRL.bayes(iter=100000, burn=10000, salto=1, semente=123, x2, y, x0=20)

# y~x3
M3 = MRL.bayes(iter=200000, burn=10000, salto=1, semente=123, x3, y, x0=80)
#--------------------------------------------#

# Exerc�cio: Alisar os dados a seguir via MRLM

# Exemplo 7.2 (Achcar et al., 2019, p.123)
# Os dados s�o de um estudo m�dico considerado para 
# avaliar a influ�ncia de 3 (co)vari�veis na resposta (y):
#  y: �ndice m�dio de resposta para pacientes recebendo uma
#     nova terapia contra o v�rus HIV realizado por oito hospitais
#     um estudo de metan�lise
# X1: propor��o de pacientes que frequentaram a escola por pelomenos 8 anos
# X2: propor��o de pacientes do sexo feminino
# X3: sal�rio mensal m�dio dos pacientes em unidades de R$1.000,00

y  = c(0.10,0.65,0.30,0.30,0.28,0.78,0.28,0.45)
x1 = c(0.08,0.17,0.08,0.30,0.05,0.18,0.09,0.45)
x2 = c(0.40,0.40,0.38,0.50,0.52,0.32,0.45,0.65)
x3 = c(0.75,1.02,1.09,1.35,1.20,2.20,2.95,2.50)
dados = cbind(y,x1,x2,x3); dados

