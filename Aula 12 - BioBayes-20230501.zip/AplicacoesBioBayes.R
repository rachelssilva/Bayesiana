# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# An�lises Bayesianas B�sicas via pacote 'BioBayes'
# https://github.com/rmrossidesuem/BioBayes

# Livrarias necess�rias para rodar o 'BioBayes':
#install.packages(c("fitdistrplus","data.table","ggplot2","RColorBrewer","rmarkdown","survival"))

library(BioBayes) # IMPORTANTE: 
                  # Instalar manualmente o arquivo "BioBayes_0.1.0_ing.tar" via RStudio 
                  # utilizar a vers�o do R 32 bits

# Aplica��o I: An�lise de Vari�ncia Heterosced�stica para dados simulados
help(anova_hetero_model)

set.seed(123)
y            = c(rnorm(10, 0, 1), rnorm(15, 3, 1), rnorm(12, 5, 3))
group        = rep(c(1, 2, 3), c(10, 15, 12))
priors_parm  = list('mu_mu'=0,     'tau_mu'=0.000001,
                    'a_tau'=0.001, 'b_tau' =0.001)
get_fit_data = anova_hetero_model(y, group)

fit  = BioBayes.fit(bug_model = get_fit_data$model,
                    database = get_fit_data$dados,
                    priors = priors_parm,
                    parameters = get_fit_data$parametros,
                    initials = get_fit_data$kicks,
                    iter = 10000,
                    burn = 1000,
                    jump = 1,
                    Round = 3,
                    seed = 123,
                    title = 'Bayesian ANOVA Results',
                    save_html = NULL,
                    render = TRUE)
names(fit) # Mostra onde s�o armazenados os resultados
#**********************************************************#

# Aplica��o II: An�lise de Regress�o Binomial (Log�stica) M�ltipla 
# Estudo sobre Infec��es Urin�rias (Koch et al., 1985) - (Giolo, 2012 - Slide p.117)
# Ensaio cl�nico Aleatorizado em que tr�s tratamentos foram 
# avaliados em pacientes cujos diagn�sticos apresentaram 
# infec��o urin�ria complicada (1) ou n�o (0).

resim  = c(78,101,68,40,54,34)
resnao = c(28,11,46,5,5,6)
diag   = c(1,1,1,0,0,0)
trat   = c(1,2,3,1,2,3) # Tratamento=3 � a refer�ncia
dados  = as.data.frame(cbind(resim,resnao,diag,trat)) 
dados$trat = relevel(factor(trat),ref='3')
attach(dados)
dados

#---------------- An�lise Frequentista ---------------------#

y     = as.matrix(dados[,c(1,2)])
ajust = glm(y ~ diag+trat, family=binomial(link="logit"), data=dados)
summary(ajust)
anova(ajust,test="Chisq")

cbind(ajust$y,ajust$fitted.values,ajust$residuals)
dev = residuals(ajust,type='deviance'); dev
QL  = sum(dev^2)
gl  = ajust$df.residual
p1  = 1-pchisq(QL,gl)
cbind(QL,p1) # Teste de ader�ncia

par(mfrow=c(1,2))
plot(dev, pch=16,ylim=c(-3,3),ylab="Res�duos deviance")
abline(h=0,lty=3)

# Verificando o ajuste via envelope Binomial via 'hnp'
library(hnp)
hnp(ajust, data=dados, halfnormal=F)
  
X = model.matrix(ajust,type='lm'); X 
# diag                trat
#    1(complicado)     	 1     0(A) 
#    1    				       0     1(B)
#    1    				       0     0(C)
#    0(n�o complicada)   1     0
#    0     				       0     1
#    0 				           0     0

est  = ajust$coef 
odds = exp(X%*%est)
cbind(X,odds)

#---------------- An�lise Bayesiana ---------------------#

y   = c(78, 101, 68, 40, 54, 34)
n   = c(106, 112, 114, 45, 59, 40)
y0  = n - y
x1  = c(1, 1, 1, 0, 0, 0)
x21 = c(1, 0, 0, 1, 0, 0)
x22 = c(0, 1, 0, 0, 1, 0)

x    = matrix(c(x1, x21, x22), byrow=F, ncol=3)
              colnames(x)[1:3] <- c("x1", "x21", "x22")
resp = cbind(y, y0)
data = cbind(y, n, x)
k    = ncol(data)-2

data_input  = list('N'=length(y), 'n'=n, 'y'=y, 'x'=x, 'k'=k)
priors_parm = list('mu_beta'=0, 'tau_beta'=0.000001)
parms       = c('beta0', 'beta', 'OR0', 'OR')

fit_freq    = glm(resp ~ x, family=binomial(link="logit"))
summary(fit_freq)

beta.aux    = numeric()
for (j in 1:(k+1)) { beta.aux[j] = fit_freq$coef[[j]] }
beta.aux = beta.aux[2:(k+1)]

start_kick  = function() list('beta0'=fit_freq$coef[[1]], 'beta'=beta.aux)

fit  = BioBayes.fit(bug_model = bin_multi_reg_model_logit,
                    database = data_input,
                    priors = priors_parm,
                    parameters = parms,
                    initials = start_kick,
                    iter = 200000,
                    burn = 20000,
                    jump = 20,
                    Round = 3,
                    seed = 123,
                    title = 'Bayesian Inferential Results',
                    save_html = NULL,
                    render = TRUE)
#**********************************************************#

# Exerc�cio 1a)
# Utilize o banco de dados "ServEmerg.txt" e "ServEmerg-info.txt"
# Fa�a uma an�lise de regress�o, via BioBayes, para o modelo:
# y ~ esc, assumindo Y ~ Po()
#----------------#

# Exerc�cio 1b)
# Considere os mesmos dados e agora fa�a uma an�lise para o modelo:
# y ~ idade+sexo+crc+serv+entr+sf+ecj+esc+cor, assumindo Y ~ Bin(), link="logit".

# Para tal, recodifique a resposta da seguinte forma:
# y = 0, se Y=2
# y = 1, se Y>2

