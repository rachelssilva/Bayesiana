# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Fun��o Bayesiana para Regress�o C�bica (Erros normais)

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
library(BRugs)
library(coda)

# Motiva��o via dados
# http://sites.uem.br/ppz/trabalhos-de-conclusao/teses/2014/osvaldo-martins-de-souza.pdf
# (Cap.III, p.21): Estudo do comportamento do pH e N-NH3 em bovinos

dados = read.table("dadospHeNa.txt",header=TRUE); dados
attach(dados)

# An�lise frequentista
reg.pH = lm(pH ~ tempo+I(tempo^2)+I(tempo^3),data=dados)
summary(reg.pH)

reg.Na = lm(Na ~ tempo+I(tempo^2)+I(tempo^3),data=dados)
summary(reg.Na)
#------------------------------------------------------------------------------#

# Fun��o Bayesiana para Regress�o C�bica (Erros normais)
x = tempo
y = pH
bayes.regcubica.normal = function(iter,burn,salto,,semente,x,y,x0)
{
# Exerc�cio!
}
#------------------------------------------------------------------------------#

# Gr�fico do ajuste Bayesiano
graf.regcubica =  function(saida,x,y)
{
plot(x,y,xlab="x",ylab="y",bty="n",pch=20)
f     = function(beta,x)  {beta[1]+beta[2]*x+beta[3]*x^2+beta[4]*x^3}
est   = c(mean(saida[,1]),mean(saida[,2]),mean(saida[,3]),mean(saida[,4]))
x0    = seq(min(dados[,1]),max(dados[,1]),0.1)
y.est = f(beta=est,x=x0)
lines(x0,y.est,lty=1,col=2,lwd=2)
}

x11()
graf.regcubica(saida3.pH,x,y)

# Quadr�tico vx C�bico
f2    = function(beta,x)  {beta[1]+beta[2]*x+beta[3]*x^2}
f3    = function(beta,x)  {beta[1]+beta[2]*x+beta[3]*x^2+beta[4]*x^3}
est2  = c(mean(saida2.pH[,1]),mean(saida2.pH[,2]),mean(saida2.pH[,3]))
est3  = c(mean(saida3.pH[,1]),mean(saida3.pH[,2]),mean(saida3.pH[,3]),mean(saida3.pH[,4]))
x0    = seq(min(dados.pH[,1]),max(dados.pH[,1]),0.1)
y2.est = f2(beta=est2,x=x0)
y3.est = f3(beta=est3,x=x0)
plot(x=dados[,1],y=dados[,2],xlab="Tempos (h)",ylab="pH",bty="n",pch=20)
lines(x0,y2.est,lty=1,col=2,lwd=2)
lines(x0,y3.est,lty=1,col=4,lwd=2)
legend('topright', c("Quadr�tico","C�bico"), lty=1, lwd=2,col=c(2,4), bty="n",cex=0.8)
#------------------------------------------------------------------------------#

# Resultados Na
x = tempo
y = Na
saida.Na = bayes.regcubica.normal(iter=1000000,burn=10000,salto=50,semente=123,x,y,x0=4)

x11()
graf.regcubica(saida.Na,x,y)
