# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
library(BRugs)  # Infer�ncia Bayesiana
library(coda)   # An�lise de converg�ncia
library(gamlss) # Estima��o Frequentista
library(hnp)    # Verifica��o do ajuste (GOF)
library(rpanel) # Gr�ficos interativos
#--------------------------------------------#

# Exemplo 1: Simula��o dos dados
set.seed(12345)
n    = 100
b0   = 0.5
b1   = 2
x    = rnorm(n)
mu   = b0 + b1*x
dp   = 0.5
y    = rnorm(n, mean = mu, sd = dp)
dados.aux = list(y,x,n=length(y))
# Estima��o
rp.regression(x, y)             # via rpanel
summary(lm(y~x))                # via lm
summary(glm(y~x))               # via glm
reg1 = gamlss(y~x, family=NO)   # via gamlss
summary(reg1)
# Verifica��o do ajuste (GOF)
plot(x,y,xlab="X (Vari�vel explicativa)",ylab="Y (Resposta)",bty="n")
lines(x,predict(reg1),lty=1,col=2)
plot(reg1)	
hnp(reg1$residuals, how.many.out=T, print.on=T,
    xlab="Quantis Te�ricos N(0,1)", half=T,
    ylab="Res�duos quant�licos aleatorizados")
#********************************************#

# Fun��o Bayesiana para Regress�o Linear Simples e 
# c�lculo de uma predi��o - Erros normais

MRL.bayes = function(iter,burn,salto,semente,x,y,x0)
{
# Fun��o Bayesiana para Regress�o Linear Simples e 
# c�lculo de uma predi��o - Erros normais
set.seed(semente)
x = x
y = y
n = length(y)
# O Modelo
sink("modeloMRL.txt")
cat("
model
{
	for (i in 1 : n) 
	{
	 y[i] ~ dnorm(mu[i], tau)
	 mu[i] <- beta0 + beta1* x[i]
   	}
	beta0 ~  dnorm(0, 0.00001)
    beta1 ~  dnorm(0, 0.00001)   
	tau ~ dgamma(0.001,0.001)
	sigma <- sqrt(1 /  tau)             	  
	sigma2 <- pow(sigma,2)
# Procedimento para obten��o do R2B (Coef. de Determina��o Bayesiano)
	sy2 <- pow(sd(y[]),2)
	R2B <- 1 - sigma2/sy2
# C�lculo de uma predi��o
    y.pred <- beta0 + beta1*x0
}
",fill=TRUE)
sink()		
modelo = "modeloMRL.txt"
# Entrada de dados
dados.aux = list(n=n,y=y,x=x,x0=x0)
# Valores iniciais
est.freq = lm(y~x)
cat("\n --------- An�lise Frequentista ------------- ")
cat("\n")
print(summary(est.freq))
# Valores ajustados
b0 = est.freq$coef[1]
b1 = est.freq$coef[2]
chutes = function() list(beta0=b0,beta1=b1,tau=1)
# Par�metros
parametros = c("beta0","beta1","sigma","sigma2","tau","R2B","y.pred")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, nBurnin=burn,
               nIter=iter,nThin=salto,DIC=TRUE,working.directory=NULL,digits=5)           
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("beta0"),samplesSample("beta1"),
                samplesSample("sigma"),samplesSample("tau"),
                samplesSample("y.pred"))
# An�lise de converg�ncia
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

saida1 = MRL.bayes(iter=10000,burn=1000,salto=1,semente=111,x,y,x0=0.5)

# Fun��o para o ajuste do MRQ Bayesiano
graf.linear =  function(saida,x,y)
{
plot(x,y,xlab="x",ylab="y",bty="n",pch=20)
f     = function(beta,x)  {beta[1]+beta[2]*x}
est   = c(mean(saida[,1]),mean(saida[,2]))
x0    = seq(min(x),max(x),0.1)
y.est = f(beta=est,x=x0)
lines(x0,y.est,lty=1,col=2,lwd=2)
}

x11()
graf.linear(saida1,x,y)

library(MCMCpack) # Modelos de Regress�o Linear Bayesianos
modelo.M1 = MCMCregress(y~x,
                        burnin=5000, mcmc=50000, thin=1,
                        b0=c(2.7,0), B0=c(0.000001,0.000001),
                        c0=0.001, d0=0.001,
                        marginal.likelihood="Chib95")
summary(modelo.M1)
heidel.diag(modelo.M1)
HPDinterval(modelo.M1)
plot(modelo.M1)
#--------------------------------------------#

# Exemplo 2: Aplica��o 3.3.13 (Rossi, 2011)
y = c(2.75, 10.0, 5.5, 7.0, 5.5, 2.75, 7.0, 8.25, 5.75, 3.0, 4.0, 4.25, 9.25,
      5.5, 3.5, 2.5, 7.25, 3.0, 5.5, 5.5, 3.0, 3.5, 5.0, 9.0, 3.5, 2.25, 5.0,
      2.0, 2.0, 2.25)
x = c(100,100,100,100,100,100,100,100,120,120,120,120,120,120,120,120,
      140,140,140,140,140,140,140,140,160,160,160,160,160,160)
# Estima��o
rp.regression(x, y)             # via rpanel
reg2 = gamlss(y~x, family=NO)   # via gamlss
summary(reg2)
# Verifica��o do ajuste (GOF)
plot(reg2)	
hnp(reg2$residuals, how.many.out=T, print.on=T,
    xlab="Quantis Te�ricos N(0,1)", half=T,
    ylab="Res�duos quant�licos aleatorizados")

saida2 = MRL.bayes(iter=10000,burn=1000,salto=1,semente=333,x,y,x0=130)

x11()
graf.linear(saida2,x,y)
#--------------------------------------------#

# Exemplo 3: Aplica��o 3.3.19. 
# y: quantidade de �gua absorvida (ml)
# x: ponto da raiz (cm)

y = c(1.3,1.3,1.9,3.4,5.3,7.1,10.6,16,16.4,18.3,20.9,20.5,21.3,21.2,20.9)
x = c(0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5,13.5,14.5)

# Estima��o
rp.regression(x, y)             # via rpanel
reg3 = gamlss(y~x, family=NO)   # via gamlss
summary(reg3)
# Verifica��o do ajuste (GOF)
plot(reg3)	
hnp(reg3$residuals, how.many.out=T, print.on=T,
    xlab="Quantis Te�ricos N(0,1)", half=T,
    ylab="Res�duos quant�licos aleatorizados")

saida3 = MRL.bayes(iter=10000,burn=1000,salto=1,semente=333,x,y,x0=10)

x11()
graf.linear(saida3,x,y)