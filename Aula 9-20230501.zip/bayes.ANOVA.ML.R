# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#
rm(list=ls(all=TRUE))
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para An�lise de Vari�ncia com Um Fator (One Way)
# Erros normais

# Observa��o: Este modelo � an�logo ao modelo homoced�stico

ANOVAoneway.ML.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana para An�lise de Vari�ncia com Um Fator (One Way)
# Erros normais

set.seed(semente)
y = dados[,1]
n = length(y)
trat = factor(dados[,2])
nTrat = length(as.numeric(levels(trat)))
sink("modeloanovaonewayML.txt")
cat("
model
{
   for (i in 1:n)
        {
         y[i] ~ dnorm(mu[i], tau)
        mu[i] <- mu0 + beta[trat[i]]
        }
# Restri��o
         beta[1] <- -sum(beta[2:nTrat])
# Distribui��es a priori n�o-informativas
            mu0 ~ dnorm(0, 0.000001)
   for (i in 2:nTrat)
        {
         beta[i] ~ dnorm(0, 0.000001)
        }		 
             tau ~ dgamma(0.001, 0.001)
          sigma <- 1/sqrt(tau)
# C�lculo dos efeitos (m�dias de cada tratamento)
   for (i in 1:nTrat)
        {
         efeito[i] <- mu0 + beta[i]
        }
}
",fill=TRUE)
sink()			
modelo = "modeloanovaonewayML.txt"
dados.aux = list(n=n,y=y,trat=trat,nTrat=nTrat)
cat("\n -------------Estimativas Frequentistas-------------")
aov.aux = aov(y ~ factor(trat))
cat("\n Estimativas Frequentistas")
print(summary(aov.aux))
w = rep(0,nTrat-1)
chutes = function() list(mu0=mean(y), beta=c(NA,w), tau=1)
parametros = c("mu0","beta","sigma","efeito")
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, nBurnin=burn,
               nIter=iter,nThin=salto,DIC=TRUE,working.directory=NULL,digits=5)           
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
nome.beta = paste("beta[",1:nTrat,"]",sep="")
nome.efeito = paste("efeito[",1:nTrat,"]",sep="")
cadeias = samplesSample("mu0")
for (j in 1:nTrat)
 {
  cadeias=cbind(cadeias,samplesSample(nome.beta[j]))
 }
 for (j in 1:nTrat)
 {
  cadeias=cbind(cadeias,samplesSample(nome.efeito[j]))
 }
cadeias = cbind(cadeias,samplesSample("sigma"))
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Exemplo:
y     = c(25,17,27,21,15,10,-2,12,4,16,18,8,4,14,
          6,23,29,25,35,33,11,23,5,17,9,8,-6,6,0,2)
trat  = c(1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,
          4,4,4,4,4,5,5,5,5,5,6,6,6,6,6)
dados1 = cbind(y,trat)

# Chamada do modelo Bayesiano
# 
saida1 = ANOVAoneway.ML.bayes(iter=11000,burn=1000,salto=1,semente=123,dados=dados1)
#--------------------------------------------#

# Aplica��o 4.3.1
setwd("C:/Users/AulasPraticas/Aula8")

dados2 = read.table("DadosOdonto.txt",header=T,skip=0)
dados2 = as.matrix(dados2)

# Chamando a fun��o
saida2 = ANOVAoneway.ML.bayes(iter=11000,burn=1000,salto=1,semente=123,dados=dados2)

