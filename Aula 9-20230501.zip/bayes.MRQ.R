# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
library(BRugs) # Infer�ncia Bayesiana
library(coda)  # An�lise de Converg�ncia
#--------------------------------------------#

# Fun��o Bayesiana para Regress�o Quadr�tica (Erros normais),
# calcula um valor predito e as coordenadas do ponto cr�tico.

MRQ.bayes = function(iter,burn,salto,semente,x,y,x0)
{
# Fun��o Bayesiana para Regress�o Quadr�tica (Erros normais),
# calcula um valor predito e as coordenadas do ponto cr�tico.
set.seed(semente)
x = x
y = y
n = length(y)
# Modelo
sink("modeloMRQ.txt")
cat("
model
{
	for (i in 1 : n) 
		{
		 y[i] ~ dnorm(mu[i], tau)
		 mu[i] <- beta0 + beta1*x[i] + beta2*pow(x[i],2)
		 # ver mais comandos em Nitzoufras (2009, p.94)
   		}
	beta0 ~  dnorm(0, 0.00001)
	beta1 ~  dnorm(0, 0.00001)   
    beta2 ~  dnorm(0, 0.00001)   
	tau ~ dgamma(0.001,0.001)
	sigma <- sqrt(1 /  tau)             	  
# C�lculo de uma predi��o
	y.pred <- beta0 + beta1*x0 + beta2*pow(x0,2)
# Coordenadas do ponto cr�tico
	PCx <- - (beta1/(2*beta2))
	PCy <- - ((pow(beta1,2)-4*beta2*beta0)/(4*beta2))
}
",fill=TRUE)
sink()		
modelo = "modeloMRQ.txt"
# Entrada de dados
dados.aux = list(n=n,y=y,x=x,x0=x0)
# Valores iniciais
est.freq = lm(y~x+I(x^2))
cat("\n --------- An�lise Frequentista ------------- ")
cat("\n")
print(summary(est.freq))
# Valores ajustados
b0 = est.freq$coef[1]
b1 = est.freq$coef[2]
b2 = est.freq$coef[3]
chutes = function() list(beta0=b0,beta1=b1,beta2=b2,tau=1)
# Par�metros
parametros = c("beta0","beta1","beta2","sigma","tau","y.pred","PCx","PCy")
# Gerando amostras
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
               numChains=1, parametersToSave=parametros, nBurnin=burn,
               nIter=iter,nThin=salto,DIC=TRUE,working.directory=NULL,digits=5)           
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("beta0"),samplesSample("beta1"),
                samplesSample("beta2"),
                samplesSample("sigma"),samplesSample("tau"),
                samplesSample("y.pred"),samplesSample("PCx"),
                samplesSample("PCy"))
# An�lise de converg�ncia
print(heidel.diag(cadeias))
cadeias
}
#--------------------------------------------#

# Exemplo 1:
dados = read.table("dadosPV.txt",header=T,skip=0)
attach(dados)
x = trat
y = PV
plot(x, y, bty="n", xlab="N�veis de Tratamento (prote�na %)",
     ylab="PV (kg)", pch=20, bty='n')
saida1 = MRQ.bayes(iter=100000,burn=10000,salto=1,semente=123,x,y,x0=1.5)
#--------------------------------------------#

# Fun��o para o ajuste do MRQ Bayesiano
graf.quadratico =  function(saida,x,y)
{
plot(x,y,xlab="x",ylab="y",bty="n",pch=20)
f     = function(beta,x)  {beta[1]+beta[2]*x+beta[3]*x^2}
est   = c(mean(saida[,1]),mean(saida[,2]),mean(saida[,3]))
x0    = seq(min(x),max(x),0.1)
y.est = f(beta=est,x=x0)
lines(x0,y.est,lty=1,col=2,lwd=2)
}

x11()
graf.quadratico(saida1,x,y)

# Ajuste do modelo linear simples
saida1b = MRL.bayes(iter=10000,burn=1000,salto=1,semente=123,x,y,x0=1.5)

x11()
graf.linear(saida1b,x,y) # Fun��o Linha 115 de "bayes.MRL.R"
#--------------------------------------------#

# Exemplo 2:
# Utilize o banco de dados sobre CA: Convers�o Alimentar (dadosCA.txt)
# e ajuste um MRQ. Fa�a uma infer�ncia para x=12 (idade, em meses, do animal)
dados = read.table("dadosCA.txt",header=TRUE)
attach(dados)
x  = Idade
y  = CA
plot(x, y, bty="n", xlab="Idade (meses)",
     ylab="Convers�o Alimentar (CA)", pch=20, bty='n')

saida2b = MRQ.bayes(iter=100000,burn=10000,salto=1,semente=123,x,y,x0=12)

x11()
graf.quadratico(saida2b,x,y)
#--------------------------------------------#

# Simula��o (Exemplo 3)
set.seed(123)
trat  =  5                                       # n�mero de n�veis (tratamento)   
r     =  10                                      # n�mero de r�plicas de Y
n     =  trat*r                                  # tamanho da amostra de Y
beta0 =  0.7                                     # intercepto
beta1 =  1.5                                     # coef. linear
beta2 = -0.4                                     # coef. quadr�tico
sigma =  0.5                                     # desvio-padr�o do erro
x     =  rep(1:trat, each=r)                     # Vari�vel regressora
y     =  numeric()
e     =  numeric()
for(i in 1:n)
{
e[i] =  rnorm(1)                                 # Erro Normal
y[i] =  beta0 + beta1*x[i] + beta2*(x[i]^2) + sigma*e[i]        
}
#--------------------------------------------#

# Gr�ficos de y e erros
par(mfrow=c(3,1))
hist(y, main="", xlab="y", ylab="Frequ�ncia")
hist(e, main="", xlab="Erro", ylab="Frequ�ncia")
plot(x, y, bty="n", xlab="N�vel", xlim=c(0,max(x)), pch=20)

pars = lm(y ~ x + I(x^2))
pars
summary(pars)

# Gr�ficos
fquad = function(beta,x)  {beta[1] +  beta[2]*x +  beta[3]*x^2}
y.aux = numeric()
x.aux = seq(min(x), max(x), 0.01)
y.aux = fquad(beta=pars$coef,x.aux)
lines(x.aux, y.aux, lty=1)

# Maximiza��o - Obten��o no ponto cr�tico (m�ximo ou m�nimo)
f   = function(x)  {pars$coef[[1]] +  pars$coef[[2]]*x +  pars$coef[[3]]*x^2}
f2  = function(x) {- f(x)}
z   = nlm(f2, 5)
x.c = z$estimate    # ponto cr�tico (x.c)
x.c
# 
y.c = f(z$estimate) # ponto de m�ximo ou imagem da fun��o f(x.c)
y.c
# 
points(x.c, y.c, col=4, pch=10)
#--------------------------------------------#

# Estimativas Bayesianas
# Modelo quadr�tico
saida3 = MRQ.bayes(iter=10000,burn=1000,salto=1,semente=123,x,y,x0=2)

x11()
graf.quadratico(saida3,x,y)
#--------------------------------------------#

# An�lise de dados de experimento com peixes (Exerc�cio)
dados = read.table("dadosPeixes.txt",header=T,skip=0)
attach(dados)
x = teor
y = comp

# Escolha por indica��o gr�fica via diagrama de dispers�o
x11()
plot(x, y, bty="n", xlab="Teor de prote�na (%)",
     ylab="Comprimento (cm)", pch=19, bty='n')

saida4a = MRL.bayes(iter=100000,burn=10000,salto=10,semente=123,x,y,x0=20)
# Fun��o dispon�vel no script "bayes.MRL.R"

saida4b = MRQ.bayes(iter=500000,burn=10000,salto=10,semente=123,x,y,x0=20)
#--------------------------------------------#

# Gr�ficos ajustados - Bayesianos
# Linear
flinear   = function(beta,x)  {beta[1] +  beta[2]*x}
beta.est1 = c(21,0.3)
x.aux     = seq(10, 30, 0.01)
y.aux1    = numeric()
y.aux1    = flinear(beta=beta.est1,x=x.aux)
x11()
plot(x,y,xlab="Teor de prote�na (%)",
     ylab="Comprimento (cm)",pch=19,bty="n")
lines(x.aux,y.aux1,lty=1,col=2)

# Quadr�tico
fquad     = function(beta,x)  {beta[1] +  beta[2]*x +  beta[3]*x^2}
beta.est2 = c(3.73,2.27,-0.049)
y.aux2    = numeric()
y.aux2    = fquad(beta=beta.est2,x=x.aux)
lines(x.aux,y.aux2,lty=1,col=4)
legend('topleft', c("Linear","Quadr�tico"), lty=1, col=c(2,4), bty="n",cex=0.8)
