# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
library(rpanel) # Gr�ficos interativos
#----------------------------------------------------------#

# Fun��o Bayesiana para estimar os par�metros da curva de Gompertz - Erros normais

gompertz.normal.bayes = function(iter,burn,salto,chutes,semente,x,y)
{
# Fun��o Bayesiana para estimar os par�metros da curva de Gompertz - Erros normais

set.seed(semente)
x = x
y = y
n = length(y)
dados.aux = list(n=n,y=y,x=x)
# Modelo
sink("modelogompertz.txt")
cat("
model
{
 for( i in 1:n )
 {
   FNL[i] <- beta1*exp(-beta2*exp(-beta3*x[i]))	# Gompertz Tipo I
      y[i] ~ dnorm(FNL[i],tau)
 }
     beta1 ~ dnorm(0,0.000001)
     beta2 ~ dnorm(0,0.000001)
     beta3 ~ dnorm(0,0.000001)
       tau ~ dgamma(0.001,0.001)
    sigma <- 1 / sqrt(tau)
}
",fill=TRUE)
sink()		
modelo = "modelogompertz.txt"
chutes.aux = function() list(beta1=chutes[1],beta2=chutes[2],beta3=chutes[3],tau=1) 
parametros = c("beta1","beta2","beta3","tau","sigma")
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes.aux,
               numChains=1, parametersToSave=parametros, nBurnin=burn,
               nIter=iter,nThin=salto,DIC=TRUE,working.directory=NULL,digits=5)           
print(res)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")           
cadeias = cbind(samplesSample("beta1"),samplesSample("beta2"),
                samplesSample("beta3"),
				samplesSample("tau"),samplesSample("sigma"))
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----") 
print(heidel.diag(cadeias)) 
alfa = 0.05
e = matrix(0, ncol(cadeias), 5)
  for (k in 1:(ncol(cadeias)))
		{
    e[k,1] = mean(cadeias[,k])
    e[k,2] = sd(cadeias[,k])
    e[k,3] = median(cadeias[,k])
    e[k,4] = quantile(cadeias[,k],alfa/2)
    e[k,5] = quantile(cadeias[,k],1-alfa/2)
    }
est = round(e,5)
est.bayes = c("M�dia","Desvio-Padr�o","Mediana","P2.5%","P97.5%")
colnames(est)=(est.bayes)
var.nomes= c("beta1","beta2","beta3","tau","sigma")
dimnames(est)=list(var.nomes,est.bayes)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(est)
cat("\n---------------Intervalos HPD---------------")
cat("\n ")
print(HPDinterval(mcmc(cadeias),0.95))
print(res$DIC)
cadeias
}
#----------------------------------------------------------#

gompertz = function(pars,x)
        {
         # Curva Gompertz tipo I para dados de crescimento
         beta1 = pars[1]
         beta2 = pars[2]        
         beta3 = pars[3]    
             y = beta1*exp(-beta2*exp(-beta3*x))   
             y
        }
		
# Exemplo:        
# Chamando os dados em BOX
dados = read.table("dadospesobox.txt",header=TRUE)	
x = dados$idade
y = dados$pesomediobox
peso = data.frame(cbind(x,y)); peso

plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")

# Estimativas Frequentistas via 'rpanel'
model =  y ~ beta1*exp(-beta2*exp(-beta3*x))

start = list(beta1=c(init=500, from=1, to=800),
             beta2=c(init=2, from=1, to=10),
			 beta3=c(init=0.5, from=0.01, to=1))

source("rp.nls.R")
rp.nls(model=model, data=peso, start=start, assignTo="peso.fit", xlim=c(0,max(x)))
# beta1    beta2     beta3 
# 307.28   3.63617   0.07172 
# residual sum-of-squares: 5.839

# O��o 2:
fit = nls(y ~ gompertz(pars,x),start=list(pars=c(300,4,0.05)))
summary(fit)
       # Estimate Std. Error t value Pr(>|t|)    
# pars1 3.073e+02  3.621e+00   84.87 1.16e-07 ***
# pars2 3.636e+00  5.947e-02   61.14 4.29e-07 ***
# pars3 7.172e-02  1.478e-03   48.51 1.08e-06 ***
# Residual standard error: 1.208 -> sigma

# Estimativas Bayesianas
saida1 = gompertz.normal.bayes(iter=300000,burn=10000,salto=20,semente=123,chutes=c(307,3.6,0.07),x,y)

acf(saida1)
acf(saida1[,1]) # Observa��o: mesmo com salto=20, acf de beta1 ainda � alto!
                # Solu��o: aumentar 'iter' e 'salto'

saida1b = gompertz.normal.bayes(iter=1000000,burn=100000,salto=50,semente=123,chutes=c(307,3.6,0.07),x,y)
acf(saida1b[,1])
# DIC = 29.24 e sigma = 1.52 

saida1 = saida1b
beta.est1 = c(mean(saida1[,1]),mean(saida1[,2]),mean(saida1[,3]))
beta.est1
y.est1 = gompertz(pars=beta.est1, sort(x))
plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")
lines(sort(x), y.est1, type="l", col=4, lwd=2)

# Implementar a Fun��o Log�stica Bayesiana:
saida2 = logistica.normal.bayes(iter=1000000,burn=100000,salto=50,semente=123,chutes=c(270,3,0.1),x,y)
# DIC = 53.32 e sigma = 8.9 (significativamente pior comparado ao modelo Gompertz!) 
 
beta.est2 = c(mean(saida2[,1]),mean(saida2[,2]),mean(saida2[,3]))
beta.est2
y.est2 = logistica(pars=beta.est2, sort(x))
lines(sort(x), y.est2, type="l", col=2, lwd=2)
legend('topleft', c("Gompertz","Log�stica"), lty=1, col=c(4,2), bty="n",cex=0.8)
#----------------------------------------------------------#


# Exerc�cio resolvido:
# Objetivo: Ajustar duas curvas n�o-lineares (Log�stica e Gompertz)
#           aos dados individuais de crescimento de codornas da Linhagem '0'

# Chamando os dados
dados  = read.table("dadospesoind.txt",header=TRUE)
dados0 = subset(dados, dados$Linhagem==0)
dados0
y = dados0$Peso
x = dados0$Idade
plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")

# Ajuste da curva de Gompertz
# Estimativas Frequentistas
fit.g = nls(y ~ gompertz(pars,x),start=list(pars=c(312,4,0.07)))
summary(fit.g)
coef(fit.g)

# Estimativas Bayesianas
saida.g = gompertz.normal.bayes(iter=300000,burn=10000,salto=20,semente=123,chutes=c(312, 3.7, 0.07),x,y)
           # M�dia Desvio-Padr�o   Mediana     P2.5%    P97.5%
# beta1 311.47621       3.42047 311.40012 304.81055 318.40875
# beta2   3.68913       0.05168   3.68834   3.58861   3.79307
# beta3   0.07037       0.00129   0.07037   0.06783   0.07293
# sigma   2.35661       0.30535   2.32479   1.84438   3.03186

#DIC = 162.9

y.est.g = gompertz(pars=c(311.5, 3.7, 0.07),sort(x))
plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")
lines(sort(x), y.est.g, type="l", col=4, lwd=2)
#----------------------------------------------------------#

# Ajuste da curva Log�stica
# Estimativas Frequentistas
fit.l = nls(y ~ logistica(pars,x),start=list(pars=c(270,3,0.13)))
summary(fit.l)
coef(fit.l)

# Estimativas Bayesianas
saida.l = logistica.normal.bayes(iter=500000,burn=10000,salto=20,semente=123,chutes=c(270,3,0.13),x,y)
           # M�dia Desvio-Padr�o   Mediana     P2.5%    P97.5%
# beta1 271.00095       4.80811 270.82008 261.92948 280.85835
# beta2   2.79943       0.07270   2.79759   2.66001   2.94728
# beta3   0.13017       0.00478   0.13010   0.12103   0.13988
# tau     0.02584       0.00641   0.02531   0.01475   0.03982
# sigma   6.36961       0.82224   6.28534   5.01158   8.23415

#DIC = 232.4 (significativamente pior comparado ao modelo Gompertz!)

y.est.l = logistica(pars=c(271,2.8,0.13),sort(x))
lines(sort(x), y.est.l, type="l", col=2, lwd=2)
legend('topleft', c("Gompertz","Log�stica"), lty=1, col=c(4,2), bty="n", cex=0.8)
