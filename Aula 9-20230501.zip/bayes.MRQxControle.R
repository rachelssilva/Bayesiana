# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
setwd("E:/Dropbox/UEM/EstBayes/AulasPraticas/Aula9")
library(BRugs) # Infer�ncia Bayesiana
library(coda)  # An�lise de Converg�ncia
#--------------------------------------------#

# Simula��o para um Modelo de Regress�o Quadr�tica vs Testemunha/Controle

set.seed(123)
trat  =  5                                 # n�mero de n�veis (tratamento)   
r     =  10                                # n�mero de r�plicas de Y
n     =  trat*r                            # tamanho da amostra de Y
beta0 =  0.7                               # intercepto
beta1 =  1.5                               # coef. linear
beta2 = -0.4                               # coef. quadr�tico
sigma =  0.5                               # desvio-padr�o do erro
x     =  rep(1:trat, each=r)               # Vari�vel regressora
y     =  numeric()
e     =  numeric()
for(i in 1:n)
{
e[i] =  rnorm(1)                           # Erro Normal
y[i] =  beta0 + beta1*x[i] + beta2*(x[i]^2) + sigma*e[i]        
}
dados = cbind(x,y)
dados
 
# Gr�ficos de y e erros
par(mfrow=c(3,1))
hist(y, main="", xlab="y", ylab="Frequ�ncia")
hist(e, main="", xlab="Erro", ylab="Frequ�ncia")
plot(x, y, bty="n", xlab="N�vel", xlim=c(0,max(x)), pch=20)

pars = lm(y ~ x+ I(x^2))
pars
summary(pars)

# Gr�ficos
f = function(x)  {pars$coef[[1]] +  pars$coef[[2]]*x +  pars$coef[[3]]*x^2}
y.aux = numeric()
x.aux = seq(min(x), max(x), 0.01)
y.aux = f(x.aux)
lines(x.aux, y.aux, lty=1)

# Maximiza��o - Obten��o no ponto cr�tico (m�ximo ou m�nimo)
f2 = function(x) {- f(x)}
z  = nlm(f2, 5)
x.c = z$estimate    # ponto cr�tico (x.c)
x.c

y.c = f(z$estimate) # ponto de m�ximo ou imagem da fun��o f(x.c)
y.c

points(x.c, y.c, col=4, pch=10)

# Montando o contraste LB
x0   = rep(0,r)     # n�vel testemunha
# Op��es para simular testemunha com m�dia fixa
#mu.0 > y.c - t.tab*sqrt(var.LB)  # para que haja diferen�a significativa!
#mu.0 = 1.6  # H� diferen�a
mu.0 = 1.7  # N�o h� diferen�a
y0   = rnorm(r, mu.0, sigma)
mu.0 = mean(y0)
points(x0, y0, col=1, pch=4)

# Matriz de incid�ncia
X  = cbind(c(rep(1,r),rep(0,n)),c(rep(0,r),rep(1,n)),c(rep(0,r),x),c(rep(0,r),x^2))
# Resposta simulada
y  = c(y0, y)
x  = c(x0, x)

# Conjunto de dados simulados final
dados.sim = cbind(x,y)
head(dados.sim)

# Regress�o
w  = aov(y ~ X)
summary(w)

# Martinho (2008, p.98) 
# "Modelos Lineares Aplicados ao Melhoramento Gen�tico Animal"
beta     = solve(t(X)%*%X)%*%t(X)%*%y
beta
gl.res   = length(y) - length(beta) 
SQRes    = t(y)%*%y - t(beta)%*%t(X)%*%X%*%beta 
sigma2.e = SQRes/gl.res
sigma2.e
xmax     = x.c
ymax     = y.c
dif      = beta[1] - ymax
dif
L        = c(1, -1, -xmax, -xmax^2) # Constraste
LB       = L%*%beta
var.LB   = t(L)%*%solve(t(X)%*%X)%*%L*sigma2.e
var.LB

# Teste de hip�tese Bilateral a 5% de signific�ncia
t.test   = dif/sqrt(var.LB)
t.test
t.tab    = qt(0.025,gl.res) 
t.tab
t.test < t.tab # Se t.test < t.tab -> M�dia.test e Ymax diferem!

# C�lculo dos y estimados
x.aux2   = c(1,2,3,4,5)
y.0      = beta[1]
y.1      = beta[2]+beta[3]*x.aux2[1]+beta[4]*x.aux2[1]^2
y.2      = beta[2]+beta[3]*x.aux2[2]+beta[4]*x.aux2[2]^2
y.3      = beta[2]+beta[3]*x.aux2[3]+beta[4]*x.aux2[3]^2
y.4      = beta[2]+beta[3]*x.aux2[4]+beta[4]*x.aux2[4]^2
y.5      = beta[2]+beta[3]*x.aux2[5]+beta[4]*x.aux2[5]^2
nivel    = c(0,x.aux2) 
y.est    = c(y.0, y.1, y.2, y.3, y.4, y.5)
est      = cbind(nivel,y.est)
est
points(est, col=2, pch=10)
points(0, beta[1], col=4, pch=10)
#--------------------------------------------#

# Fun��o Bayesiana para Regress�o Quadr�tica, 
# que calcula as coordenadas do ponto cr�tico
# e o compara com dados controle/testemunha

MRQxControl.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana para Regress�o Quadr�tica, 
# que calcula as coordenadas do ponto cr�tico
# e o compara com dados controle/testemunha

set.seed(semente)
y0 = dados[dados[,1]==0,2]    # controles
y  = dados[dados[,1]!=0,2]
x  = dados[dados[,1]!=0,1]
n0 = length(y0)
n  = length(y)
# Modelo
sink("modeloMRQxControl.txt")
cat("
model
{
# Modelando os controles
	   for(i in 1:n0)
      		{
   		 y0[i] ~ dnorm(mu0, tau0)
      		}
  	        mu0 ~  dnorm(0, 0.000001)
        	tau0 ~  dgamma(0.001,0.001)
      		sigma0 <- 1/sqrt(tau0)
#--------------------------------------------------------------------------
# Modelando os tratamentos
		for (i in 1:n) 
		{
		 y[i] ~ dnorm(mu[i], tau)
		 mu[i] <- beta0 + beta1*x[i] + beta2*pow(x[i],2) 
   		}
		beta0 ~  dnorm(0, 0.00001)
   		beta1 ~  dnorm(0, 0.00001)   
        beta2 ~  dnorm(0, 0.00001)   
		tau ~ dgamma(0.001,0.001)
		sigma <- sqrt(1/tau)             	  
# Coordenadas do ponto cr�tico
		PCx <- - (beta1/(2*beta2))
		PCy <- - ((pow(beta1,2)-4*beta2*beta0)/(4*beta2))
# Contraste
		delta <- mu0 - PCy
}
",fill=TRUE)
sink()		
modelo = "modeloMRQxControl.txt"
# Entrada de dados
dados.aux = list(n0=n0,y0=y0,n=n,y=y,x=x)
# Valores iniciais para a reg. quadr�tica
est.freq = lm(y~x+I(x^2))
cat("\n --------- An�lise Frequentista ------------- ")
cat("\n")
print(summary(est.freq))
# Valores ajustados
b0 = est.freq$coef[1]
b1 = est.freq$coef[2]
b2 = est.freq$coef[3]
chutes = function() list(mu0=mean(y0),tau0=1,beta0=b0,beta1=b1,beta2=b2,tau=1)
# Par�metros
parametros = c("mu0","sigma0","tau0","beta0","beta1","beta2","sigma","tau","PCx","PCy","delta")
# Gerando amostras
res = BRugsFit(modelFile = modelo, data = dados.aux, inits = chutes,
            numChains = 1, parametersToSave = parametros, nBurnin = burn,
            nIter = iter, nThin = salto, DIC = TRUE, working.directory = NULL,
            digits = 5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("mu0"),samplesSample("tau0"),
                samplesSample("sigma0"),
				samplesSample("beta0"),samplesSample("beta1"),
                samplesSample("beta2"),
                samplesSample("tau"),samplesSample("sigma"),
                samplesSample("PCx"),samplesSample("PCy"),
				samplesSample("delta"))
# An�lise de converg�ncia
print(heidel.diag(cadeias))
alfa = 0.05
e = matrix(0, ncol(cadeias), 5)
  for (k in 1:(ncol(cadeias)))
		{
    e[k,1] = mean(cadeias[,k])
    e[k,2] = sd(cadeias[,k])
    e[k,3] = median(cadeias[,k])
    e[k,4] = quantile(cadeias[,k],alfa/2)
    e[k,5] = quantile(cadeias[,k],1-alfa/2)
    }
est = round(e,5)
var.nomes = c("mu0","tau0","sigma0",
              "beta0","beta1","beta2","tau","sigma",
			  "PCx","PCy","delta")
col.nomes = c("M�dia","DP","Mediana","P2.5%","P97.5%")
dimnames(est) = list(var.nomes, col.nomes)
cat("\n-------------Estimativas Bayesianas-------------")
cat("\n ")
print(est)  
cadeias
}

# Aplica��o 1
saida1 = MRQxControl.bayes(iter=100000,burn=10000,salto=10,semente=123,dados=dados.sim)
           # M�dia      DP  Mediana    P2.5%   P97.5%
# mu0     1.81002 0.15394  1.81016  1.50870  2.11896
# tau0    5.41565 2.54956  5.01441  1.61978 11.29728
# sigma0  0.46992 0.12695  0.44657  0.29752  0.78573

# beta0   0.84841 0.32632  0.85208  0.20772  1.48604
# beta1   1.39109 0.24745  1.39194  0.90867  1.87659
# beta2  -0.38231 0.04037 -0.38233 -0.46162 -0.30342 sig
# tau     4.48315 0.91861  4.43170  2.87567  6.45403
# sigma   0.47987 0.05025  0.47502  0.39363  0.58970

# PCx     1.80564 0.14612  1.81883  1.48273  2.05337
# PCy     2.12158 0.09341  2.12029  1.93998  2.30782
# delta  -0.31156 0.18152 -0.31132 -0.67482  0.04863 ns


# Gr�fico para os ajustes obtidos na 
# Fun��o Bayesiana para comparar o ponto de m�ximo de uma Regress�o Quadr�tica
# com Testemunha (ou Controle)

grafico.MRQxControl.bayes = function(dados,saida)
{
# Gr�fico para os ajustes obtidos na 
# Fun��o Bayesiana para comparar o ponto de m�ximo/m�nimo de uma Regress�o Quadr�tica
# com Testemunha (ou Controle)
beta  = c(mean(saida[,4]),mean(saida[,5]),mean(saida[,6]))
xc    = mean(saida[,9])
yc    = mean(saida[,10])
#
f     = function(x,beta)  {beta[1] + beta[2]*x + beta[3]*x^2}
y.aux = numeric()
# Controle
x0 = dados[dados[,1]==0,1]
y0 = dados[dados[,1]==0,2]
# Tratamento
x1 = dados[dados[,1]!=0,1]
y1 = dados[dados[,1]!=0,2]
x.aux = seq(min(x1), max(x1), 0.01)
y.aux = f(x.aux,beta)
#
xlim = c(min(dados[,1]), max(dados[,1]))
ylim = c(min(dados[,2]), max(dados[,2]))
par(mfrow=c(1,1))
plot(dados[,1], dados[,2], xlim=xlim, ylim=ylim,
	 xlab="N�vel", ylab="Resposta", bty="n", pch=20) #Pontos observados (N�veis)
mu0.bayes = mean(saida[,1])                  #M�dia Testemunha
points(x0, y0, col=1, pch=4)                 #Pontos observados (Testemunha)
points(0, mu0.bayes, col=4, pch=10)          #M�dia Testemunha
text(0.2, mu0.bayes, round(mu0.bayes,1), cex=0.8, col=4)
lines(x.aux, y.aux, lty=1, col=2)            #Equa��o ajustada
points(xc, yc, col=2, pch=10)                #Ponto Cr�tico 
segments(xc, ylim[1], xc, yc, col=2, lty=3)
segments(0.2, yc, xc, yc, col=2, lty=3)
text(xc+0.2, ylim[1], round(xc,1), cex=0.8, col=2)  
text(0.2, yc, round(yc,1), cex=0.8, col=2)
#
cadeias = cbind(saida[,1],saida[,9],saida[,10])
alfa = 0.05
e = matrix(0, ncol(cadeias), 5)
  for (k in 1:(ncol(cadeias)))
		{
    e[k,1] = mean(cadeias[,k])
    e[k,2] = sd(cadeias[,k])
    e[k,3] = median(cadeias[,k])
    e[k,4] = quantile(cadeias[,k],alfa/2)
    e[k,5] = quantile(cadeias[,k],1-alfa/2)
    }
est = round(e,5)
var.nomes = c("mu0","PCx","PCy")
col.nomes = c("M�dia","DP","Mediana","P2.5%","P97.5%")
dimnames(est) = list(var.nomes, col.nomes)
cat("\n-------------Estimativas Bayesianas-------------")
cat("\n ")
print(est)  
}

grafico.MRQxControl.bayes(dados.sim,saida1)
#------------------------------------------------------------------------------#

# Aplica��o 2
dadosmelao = read.table("dadosMelao.txt",header=TRUE)
saida2 = MRQxControl.bayes(iter=100000,burn=10000,salto=10,semente=123,dados=dadosmelao)
grafico.MRQxControl.bayes(dadosmelao,saida2)
#--------------------------------------------#

# Exerc�cio sobre Convers�o Alimentar em coelhos
dadosCAcoelhos = read.table("dadosCAcoelhos.txt",header=TRUE)
