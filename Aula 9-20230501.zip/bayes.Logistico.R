# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula9")
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
library(rpanel) # Gr�ficos interativos
#----------------------------------------------------------#

# Fun��o Bayesiana para estimar os par�metros da curva Log�stica - Erros normais

logistica.normal.bayes = function(iter,burn,salto,semente,chutes,x,y)
{
# Fun��o Bayesiana para estimar os par�metros da curva Log�stica - Erros normais

set.seed(semente)
x = x
y = y
n = length(y)
dados.aux = list(n=n,y=y,x=x)
# Modelo
sink("modelologistico.txt")
cat("
model
{
 for( i in 1:n )
 {
   FNL[i] <- beta1/(1+ exp(beta2 - beta3*x[i])) 
      y[i] ~ dnorm(FNL[i],tau)
 }
     beta1 ~ dnorm(0,0.000001)
     beta2 ~ dnorm(0,0.000001) 
     beta3 ~ dunif(0,1) 
       tau ~ dgamma(0.001,0.001)
     sigma <- 1 / sqrt(tau)
}
",fill=TRUE)
sink()		
modelo = "modelologistico.txt"
chutes.aux = function() list(beta1=chutes[1],beta2=chutes[2],beta3=chutes[3],tau=1) 
parametros = c("beta1","beta2","beta3","tau","sigma")
res = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes.aux,
               numChains=1, parametersToSave=parametros, nBurnin=burn,
               nIter=iter,nThin=salto,DIC=TRUE,working.directory=NULL,digits=5)           
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")           
cadeias = cbind(samplesSample("beta1"),samplesSample("beta2"),
                samplesSample("beta3"),
				samplesSample("tau"),samplesSample("sigma"))
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----") 
print(heidel.diag(cadeias)) 
alfa = 0.05
e = matrix(0, ncol(cadeias), 5)
  for (k in 1:(ncol(cadeias)))
		{
    e[k,1] = mean(cadeias[,k])
    e[k,2] = sd(cadeias[,k])
    e[k,3] = median(cadeias[,k])
    e[k,4] = quantile(cadeias[,k],alfa/2)
    e[k,5] = quantile(cadeias[,k],1-alfa/2)
    }
est = round(e,5)
est.bayes = c("M�dia","Desvio-Padr�o","Mediana","P2.5%","P97.5%")
colnames(est)=(est.bayes)
var.nomes = c("beta1","beta2","beta3","tau","sigma")
dimnames(est)=list(var.nomes,est.bayes)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(est)
cat("\n---------------Intervalos HPD---------------")
cat("\n ")
print(HPDinterval(mcmc(cadeias),0.95))
print(res$DIC)
cadeias
}
#----------------------------------------------------------#

# Curva Log�stica para dados de crescimento
logistica = function(pars,x)
        {
		 # Curva Log�stica para dados de crescimento
         beta1 = pars[1]
         beta2 = pars[2]        
         beta3 = pars[3]        
             y = beta1/(1+exp(beta2-beta3*x)) 
             y
        }
		
# Exemplo:
# Aplica��o 3.3.19. Modelo log�stico para curva de crescimento (Rossi, 2011)
## y: quantidade de �gua absorvida (ml)
## x: ponto da raiz (cm)

y = c(1.3,1.3,1.9,3.4,5.3,7.1,10.6,16,16.4,18.3,20.9,20.5,21.3,21.2,20.9)
x = c(0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5,9.5,10.5,11.5,12.5,13.5,14.5)
feijao = data.frame(cbind(x,y))

plot(x, y, xlab="Ponto da raiz (cm)", ylab="H2O (ml)", bty="n")

# Estimativas Frequentistas via 'rpanel'
model =  y ~ beta1/(1 + exp(beta2 - beta3*x)) 

start = list(beta1=c(init=2, from=1, to=50),
             beta2=c(init=2, from=1, to=10),
			 beta3=c(init=0.5, from=0.01, to=1))

source("rp.nls.R")
rp.nls(model=model, data=feijao, start=start, assignTo="feijao.fit", xlim=c(0,15))
#   beta1   beta2   beta3 
# 21.5089  3.9573  0.6222 
# residual sum-of-squares: 6.21

# Estimativas Frequentistas
fit = nls(y ~ logistica(pars,x), start=list(pars=c(20,4,0.5)))
summary(fit)

# Estimativas Bayesianas
saida1 = logistica.normal.bayes(iter=10000,burn=1000,salto=1,semente=123,chutes=c(21.5,3.9,0.6),x,y)

acf(saida1)
acf(saida1[,1]) # observa��o: acf de beta1 � alto, ent�o devemos aumentar 'salto'

saida1b = logistica.normal.bayes(iter=100000,burn=10000,salto=10,semente=123,chutes=c(21.5,3.9,0.6),x,y)
acf(saida1b[,1])

beta.est = c(mean(saida1b[,1]),mean(saida1b[,2]),mean(saida1b[,3]))
beta.est

plot(x, y, xlab="Ponto da raiz (cm)", ylab="H2O (ml)", bty="n")
y.est = logistica(pars=beta.est, x)
lines(x, y.est, type="l", col=2, lwd=2)
#----------------------------------------------------------#


# Exerc�cio - Dados de Pesos de Codornas
dados = read.table("dadospesobox.txt",header=TRUE)
dados = as.matrix(dados)
x = dados[,1]
y = dados[,2]
plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")

fit = nls(y ~ logistica(pars,x),start=list(pars=c(210,3,0.1)))
summary(fit)

saida2 = logistica.normal.bayes(iter=100000,burn=10000,salto=10,semente=123,chutes=c(269,2.8,0.1),x,y)

y.est = logistica(pars=c(271,2.8,0.13),sort(x))
plot(x, y, xlab="Idade (dias)", ylab="Peso (g)", bty="n")
lines(sort(x), y.est, type="l", col=2, lwd=2)
