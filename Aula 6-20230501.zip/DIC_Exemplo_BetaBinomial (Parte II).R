# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Parte I

# C�lculo do DIC
www.mrc-bsu.cam.ac.uk/software/bugs/the-bugs-project-dic/

# Exemplo: Modelo Beta-Binomial
# Y ~ Bernoulli(theta)
# theta: par�metro de interesse (propor��o de sucessos)

rm(list=ls(all=TRUE))
set.seed(123)
n         = 16     # tamanho da amostra
theta0    = 0.8    # par�metro (fixado)
y         = rbinom(n, size=1, prob=theta0)
t         = sum(y) # n�mero de sucessos
theta.est = t/n    # e.m.v. frequentista
theta.est

# hiperpar�metros (n�o-informativos) a priori de theta ~ Beta(alpha,beta)
alpha     = 0.5
beta      = 0.5

# Posteriori de theta
N          = 1000
post.theta = function(N,n,t,alpha,beta) { rbeta(N,t+alpha,n-t+beta) }
thetapost = post.theta(N,n,t,alpha,beta)
mean(thetapost) # m�dia a posteriori
hist(thetapost, main="", xlab=expression(paste(theta, "|y")),
     ylab=expression(paste(pi,"(",theta,"|y)")), col="gray", bty='n')

# Logaritmo da Fun��o de Verossimilhan�a da Binomial (logFV)
lvero.bin = function(t,n,theta)
{
   t*log(theta)+(n-t)*log(1-theta)
} 				   
				   
v1        = lvero.bin(t,n,thetapost) 
D         = -2*v1      # D: Deviance = -2*log(p(y|theta))

Dbar      = mean(D)    # Dbar: Deviance m�dia
Dbar

thetabar  = mean(thetapost)    # m�dia a posteriori
thetabar

v2        = lvero.bin(t,n,thetabar)
Dhat      = -2*v2      # Dhat: valor de thetabar aplicado � logFV
Dhat                   # Dhat = -2*log(p(y|theta.bar))

pD        = Dbar-Dhat  # pD: n�mero efetivos de par�metros (estimado)
pD 

DIC       = Dbar+pD    # DIC: Deviance Information Criterion
                       # Spiegelhalter et al. (2002)
DIC                    # DIC = Dbar + pD = Dhat + 2*pD

# ou
DIC       = Dhat+2*pD
DIC
#--------------------------------------------#

# Parte II

library(BRugs) # Infer�ncia Bayesiana
library(coda)  # An�lise de Converg�ncia

beta.bin.bayes = function(iter,burn,salto,n,y,alpha,beta)
{
# Fun��o Bayesiana para estimar a propor��o de sucessos
# em uma popula��o com Erros Binomiais
# Y ~ Bernoulli(theta), theta: propor��o de sucessos
n = length(y)
# alpha, beta: hiperpar�metros a priori para theta ~ Beta(alpha,beta)
# O Modelo
sink("modelobetabinomial.txt")
cat("
model
{
for (i in 1:n)
     { y[i] ~ dbern(theta) }
      theta ~ dbeta(alpha, beta)
}
",fill=TRUE)
sink()		
modelo     = "modelobetabinomial.txt"
dados.aux  = list(alpha=alpha, beta=beta, n=n, y=y)
chutes     = function() list(p=sum(y)/n)
parametros = c("theta")
res        = BRugsFit(modelFile=modelo,
					  data=dados.aux, inits=chutes,
					  numChains=1, parametersToSave=parametros,
					  nIter=iter, nThin=salto, DIC=TRUE,
					  working.directory=NULL, digits=5)          
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias = cbind(samplesSample("theta"))
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----") 
print(heidel.diag(cadeias))
cadeias
}     

saida = beta.bin.bayes(iter=10000,burn=1000,salto=1,n,y,alpha,beta)

# Curiosidade: Mais dados e programas
http://www.biostat.umn.edu/~brad/data.html
