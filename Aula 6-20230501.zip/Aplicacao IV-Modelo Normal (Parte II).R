# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Aplica��o/Simula��o de distribui��es de probabilidade cont�nuas
# An�lise de dados cont�nuos, Y ~ Normal(mu,sigma)

rm(list=ls(all=TRUE))

# Aplica��o IV (Slide)
# Um grupo internacional quer modelar dados de
# produ��o de milho (tonelas) em suas propriedades,
# em um certo per�odo de observa��o:
y = c(17,22,23,23,23,23,24,24,24,24,24,24,25,25,25,25,25,25,25,26,28,28,29,
      30,30,31,31,35,35,35,36,40,41,41,41,42,51,54,56,56,56,58,60,68,79)

# Existem muitos pacotes sobre o tema "Infer�ncia Bayesiana" dispon�veis no R:
https://cran.r-project.org/web/views/Bayesian.html

#---------- Utiliza��o do pacote BRugs e coda -------------#
# Livrarias necess�rias para o procedimento Bayesiano
library(BRugs)   # Infer�ncia Bayesiana
library(coda)    # An�lise de Converg�ncia
#--------------------------------------------#

# Lendo o arquivo de dados
setwd("C:/Users/AulasPraticas/Aula6")
dados = read.table("milho.txt",head=T)
attach(dados)

iter      = 110000 # N�mero de itera��es MCMC
burn      = 10000  # N�mero de valores eliminados ("queima")
salto     = 10     # Tamanho dos saltos para eliminar poss�veil autocorrela��o
n         = length(y)

# Op��o 1:
#modelo   = "modelonormal.bug" # O arquivo *.bug deve estar na pasta de trabalho

# Op��o 2 (mais pr�tica):
sink("modelonormal.txt")
cat("
model
{
   for(i in 1:n)
      {
       y[i] ~ dnorm(mu, tau)
      }
         mu ~  dnorm(0, 0.000001)  # M�dia
        tau ~  dgamma(0.001,0.001) # Precis�o
      sigma <- 1/sqrt(tau) 	       # Desvio-padr�o	 
}
",fill=TRUE)
sink()		
modelo     = "modelonormal.txt"

dados.aux = list(n=n, y=y)

library(MASS)
est.f = fitdistr(y,'normal') # Estimativas frequentistas
est.f
# precisao = 1/sd^2
prec = 1/(est.f$estimate[2])^2
prec
chutes     = function()list(mu=est.f$estimate[1], tau=prec) # Chutes/valores iniciais ou 
parametros = c("mu","tau","sigma")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
print(res)

cadeias = cbind(samplesSample("mu"),samplesSample("tau"),samplesSample("sigma"))
cadeias = mcmc(cadeias)
print(heidel.diag(cadeias))
print(geweke.diag(cadeias))
x11()
acf(cadeias)
x11()
plot(cadeias)

# Comandos gr�ficos adicionais (OpenBugs):
samplesHistory("*", mfrow=c(3,1))    # Hist�ricos
samplesBgr("*", mfrow=c(3,1))        # Tra�os
samplesAutoC("*", mfrow=c(3,1), 1)   # Autocorrela��es
samplesDensity("*", mfrow=c(3,1), 1) # Densidades

head(cadeias)
# Histogramas
x11()
par(mfrow=c(1,3))
hist(cadeias[,1],xlab=expression(paste(mu, "|y,",tau)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,2],xlab=expression(paste(tau, "|y,",mu)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,3],xlab=expression(paste(sigma, "|y,",mu,",",tau)),ylab="Frequ�ncia",main="",bty="n")
#dev.copy(png,"HistPosterioris.png", width=800, height=800, bg="transparent")
#dev.off()
#--------------------------------------------#

# Montando uma fun��o geral:
normal.bayes = function(iter,burn,salto,semente,dados)
{
# Fun��o Bayesiana  para estimar par�metros de uma popula��o com erros normais
# Y   ~ N(mu,tau) : Y real; mu real; tau>0
# mu  ~ N(a,b)    : m�dia a priori; a real; b>0
# tau ~ Gama(c,d) : precis�o a priori; c>0; d>0
# sigma <- 1/sqrt(tau) : desvio-padr�o, fun��o da precis�o
# iter : N�mero de itera��es MCMC
# burn : N�mero de valores eliminados ("queima")
# salto: Tamanho dos saltos para eliminar poss�veil autocorrela��o
set.seed(semente)
y         = dados
n         = length(y)
sink("modelonormal.txt")
cat("
model
{
   for(i in 1:n)
      {
       y[i] ~ dnorm(mu, tau)
      }
         mu ~  dnorm(0, 0.000001)  # M�dia
        tau ~  dgamma(0.001,0.001) # Precis�o
      sigma <- 1/sqrt(tau) 	       # Desvio-padr�o
}
",fill=TRUE)
sink()		
modelo     = "modelonormal.txt"
dados.aux  = list(n=n, y=y)
cat("\n---------------Estimativas frequentistas---------------")
cat("\n ")
library(MASS)
est.f = fitdistr(y,'normal') 
print(est.f)
# precisao = 1/sd^2
prec = 1/(est.f$estimate[2])^2
chutes     = function()list(mu=est.f$estimate[1], tau=prec) # Chutes/valores iniciais
parametros = c("mu","tau","sigma")
cat("\n-------------------------------------------------------")
cat("\n ")
res        = BRugsFit(modelFile=modelo, data=dados.aux, inits=chutes,
                      numChains=1, parametersToSave=parametros,
                      nBurnin=burn, nIter=iter, nThin=salto, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")					  
print(res)
cadeias = cbind(samplesSample("mu"),samplesSample("tau"),samplesSample("sigma"))
cadeias = mcmc(cadeias)
# An�lise de converg�ncia
cat("\n---------------An�lise de Converg�ncia de Geweke---------------")
cat("\n ")
print(geweke.diag(cadeias))
cat("\n--------An�lise de Converg�ncia de Heidelberg e Welch----------")
cat("\n ")
print(heidel.diag(cadeias))
# Histogramas a posteriori
par(mfrow=c(1,3))
hist(cadeias[,1],xlab=expression(paste(mu, "|y,",tau)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,2],xlab=expression(paste(tau, "|y,",mu)),ylab="Frequ�ncia",main="",bty="n")
hist(cadeias[,3],xlab=expression(paste(sigma, "|y,",mu,",",tau)),ylab="Frequ�ncia",main="",bty="n")
cadeias
}

# Chamando a fun��o
saida = normal.bayes(iter=10000,burn=1000,salto=1,semente=123,y)

sumario = function(amostra)
{
# Fun��o para retornar sum�rio a posteriori
e = matrix(0,ncol(amostra),5)
  for (k in 1:(ncol(amostra)))
		{
    e[k,1] = mean(amostra[,k])
    e[k,2] = sd(amostra[,k])
    e[k,3] = median(amostra[,k])
    e[k,4] = quantile(amostra[,k],0.025)
    e[k,5] = quantile(amostra[,k],0.975)
    }
est = round(e,5)
est.bayes = c("M�dia","Desvio-Padr�o","Mediana","P2.5%","P97.5%")
colnames(est)=(est.bayes)
est
}

sumario(saida)

# Intervalo de Alta Densidade (HPD)
saida1 = mcmc(saida)
HPDinterval(saida1,prob=0.95)
#--------------------------------------------#

# Simula��o
y0 = rnorm(5,5,0.8)
est = fitdistr(y0,'normal'); est
# O IC(mu,95%) ser�:
ttab = qnorm(c(0.025, 0.975))
IC = est$est[[1]] + ttab*est$sd[[1]]; IC  # est +- (Z_alfa/2)*sd(est)

saida0 = normal.bayes(iter=100000,burn=1000,salto=10,semente=333,y0)
#--------------------------------------------#

# Exerc�cio
# Utilize o arquivo "prod.txt", assuma que a vari�vel "prod" � Normal
# ent�o obtenha as estimativas Bayesianas para os par�metros,
# por tipo de tratamento. 
# Ao final conclua se, h� diferen�a entre as produ��es m�dias
# em n�vel de 95% de credibilidade.

dados  = read.table("prod.txt",head=T)
dados1 = subset(dados, dados$trat==1)
dados2 = subset(dados, dados$trat==2)

saida1 = normal.bayes(iter=100000,burn=1000,salto=10,semente=333,dados1$prod)

saida2 = normal.bayes(iter=100000,burn=1000,salto=10,semente=333,dados2$prod)

#***************************************************************************#
#                                                                           #
#            Salvando/Lendo arquivos e fun��es externas                     #
#                                                                           #
#***************************************************************************# 

# Voc� pode criar um arquivo com um banco de fun��es previamente criadas
# e chamar todas quando desejar: 

setwd("C:\\...\\Trabalho")
source("function.R") # l� o arquivo de fun��es de nome "function.R"
  
# Voc� pode salvar tudo o que foi feito em trabalho
# e chamar os arquivos, as fun��es, os resultados, etc, quando desejar:


savehistory(file="projeto.Rhistory") # salva o hist�rico
save(list=ls(),file="projeto.Rdata") # salva tudo
load("projeto.Rdata")                # l� tudo

