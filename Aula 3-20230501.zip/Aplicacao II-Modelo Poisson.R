# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#-----------------------------------#

# Aplica��o/Simula��o de distribui��es de probabilidade discretas
# An�lise de dados de contagem, Y ~ Poisson(lambda)

# Aplica��o II (Slide)
# (Exemplo 2.6.2; Rossi, 2011) Considere que Y represente o n�mero de ovos
# postos por n = 10 aves em tratamento com ra��o especial durante o per�odo
# de um m�s. O interesse � estimar a m�dia de produ��o.
# Para tal, uma amostra aleat�ria de Y foi obtida experimentalmente:
        
rm(list=ls(all=TRUE))
# Simula��o dos dados
#set.seed(2)
#lambda = 26
#n      = 10
#y      = rpois(n,lambda)

y = c(33,21,22,24,26,28,26,26,22,36)
n = length(y)

hist(y, bty='n')
mean(y)         # emv
sd(y)
var(y)

# Infer�ncia Frequentista
library(MASS)
est = fitdistr(y,'poisson')
est

library(rpanel) # Se n�o funcionar no RStudio abrir em outro editor!
rp.likelihood("sum(log(dpois(data, theta)))", y, 10, 50)

# O IC(lambda,95%) baseado no logFV ser�:
amplitude1 = 29.703-23.372
amplitude1

# O IC(lambda,95%) baseado na normalidade assint�tica ser�:
ttab = qnorm(c(0.025, 0.975))
sd.est = est$sd[[1]]
IC1 = est$est[[1]] + ttab*sd.est
IC1
amplitude2 = IC1[2]-IC1[1]
amplitude2

# Observa��o: Os limites do intervalo de confian�a para lambda
# podem ser obtidos por meio do quantil da distribui��o Qui-quadrado
# de forma mais coerente com a forma da distribui��o que � assim�trica!
# Introdu��o ao Ambiente Estat�stico R (JUSTINIANO, 2011, p.134-136)
# Dispon�vel em: www.leg.ufpr.br/~paulojus/embrapa/Rembrapa
#-------------------------------#

# Infer�ncia Bayesiana
par(mfrow=c(1,3))
# Fun��o de verossimilhan�a: T|lambda ~ Gama(t+1,n)
t = sum(y)
set.seed(123)
veross = rgamma(1000,t+1,n)
hist(veross, main="", xlab=expression(paste(lambda)),
     ylab=expression(paste("L(",lambda, "|y)")), col="gray", bty='n')

# Distribui��o a priori lambda ~ Gama(a,b)
a = 1
b = 0.001
priori = rgamma(1000,a,b) # a=1, b=0.001 � n�o informativa (flat ou vaga)

hist(priori, main="", xlab=expression(paste(lambda)),
     ylab=expression(paste(pi,"(",lambda,")")), col="gray", bty='n')

# Distribui��o a posteriori lambda|y ~ Gama(t+a,n+b)
posteriori = rgamma(1000,t+a,n+b)
hist(posteriori, main="", xlab=expression(paste(lambda, "|y")),
     ylab=expression(paste(pi,"(",lambda,"|y)")), col="gray", bty='n')

# Gr�ficos simult�neas das distribui��es
x11()
par(mfrow=c(1,1))
plot(density(veross), xlim=c(0,40), ylim=c(0,1), main="",
     xlab=expression(paste(lambda)), ylab="Densidade", lty=1, col=1, bty='n')
lines(density(priori), lty=2, col=4)
lines(density(posteriori), lty=1, col=2)
legend(6, 0.8, c("Verossimilhan�a","Priori","Posteriori"),
       lty=c(1,2,1), col=c(1,4,2), bty="n", cex=.7)

# Estatimativas Bayesianas
mean(posteriori)
sd(posteriori)
median(posteriori)

# Intervalo de Credibilidade para lambda
ICr1 = quantile(posteriori,c(0.025, 0.975))
ICr1
amplitude3 = ICr1[2]-ICr1[1]
amplitude3
#**************************************************************

# Distribui��o a priori lambda ~ Gama(a,b) um pouco informativa
a = 1
b = 1
set.seed(123)
priori2 = rgamma(1000,a,b)

x11()
par(mfrow=c(1,3))
# Fun��o de verossimilhan�a: T|lambda ~ Gama(t+1,n)
hist(veross, main="", xlab=expression(paste(lambda)),
     ylab=expression(paste("L(",lambda, "|y)")), col="gray", bty='n')

hist(priori2, main="", xlab=expression(paste(lambda)),
     ylab=expression(paste(pi,"(",lambda,")")), col="gray", bty='n')

# Distribui��o a posteriori lambda|y ~ Gama(t+a,n+b)
posteriori2 = rgamma(1000,t+a,n+b)
hist(posteriori2, main="", xlab=expression(paste(lambda, "|y")),
     ylab=expression(paste(pi,"(",lambda,"|y)")), col="gray", bty='n')

# Gr�ficos simult�neos das distribui��es
x11()
par(mfrow=c(1,1))
plot(density(veross), xlim=c(0,30), ylim=c(0,1), main="",
     xlab=expression(paste(lambda)), ylab="Densidade", lty=1, col=1, bty='n')

lines(density(priori), lty=2, col=2)
lines(density(posteriori), lty=1, col=2)
legend(20, 0.8, c("Verossimilhan�a","Priori n�o informativa","Posteriori"),
       lty=c(1,2,1), col=c(1,2,2), bty="n", cex=.8)
       
lines(density(priori2), lty=2, col=4)
lines(density(posteriori2), lty=1, col=4)
legend(20, 0.6, c("Priori informativa","Posteriori"),
       lty=c(2,1), col=c(4,4), bty="n", cex=.8)       

# Estatimativas Bayesianas
mean(posteriori2)
sd(posteriori2)
median(posteriori2)

# Intervalo de Credibilidade para lambda
ICr2 = quantile(posteriori2,c(0.025, 0.975))
ICr2

# Intervalo de Alta Densidade (HPD)
library(coda)
post2 = mcmc(posteriori2)
HPDinterval(post2,prob=0.95)

amplitude4 = ICr2[2]-ICr2[1]
amplitude4

# Comparando amplitudes dos intervalos:
amp = c(amplitude1,amplitude2,amplitude3,amplitude4)
res = matrix(amp,1,4,byrow=T,
             dimnames= list(c('amplitude'),
                            c('freq. logFV','freq. assint.',
							  'bayes n�o inf','bayes inf')))
res
