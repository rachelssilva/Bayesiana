# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula11")
library(BRugs)
library(coda)
library(INLA) # Instalar previamente:
#install.packages("INLA",repos=c(getOption("repos"),INLA="https://inla.r-inla-download.org/R/stable"),dep=TRUE)
#inla.upgrade(()
#--------------------------------------------#

# Especificando distribui��es a priori
#   Y ~ N(mu,tau)
#  mu ~ N(a,b)
# tau ~ Gama(c,d)

# Estimativa via MCMC
# Fun��o Bayesiana para estimar par�metros de uma popula��o - Erros Normais
# prioris especificadas
bayes.normal = function(iter,burn,salto,a,b,c,d,y)
{
# Fun��o Bayesiana para estimar par�metros de uma popula��o - Erros Normais
# hiperpar�metros espec�ficos para as prioris
# a, b: para mu  ~ N(a,b)
# c, d: para tau ~ Gama(c,d)
y = na.omit(y)
y = y[1:length(y)]
n = length(y)
# O Modelo
sink("modelonormal.txt")
cat("
model
{
   for( i in 1 : n ) { y[i] ~ dnorm(mu, tau) }
   mu ~ dnorm(a, b)
   tau ~ dgamma(c, d)
   sigma <- 1 / sqrt(tau)
}
",fill=TRUE)
sink()		
modelo = "modelonormal.txt"
dados.aux = list(n=n, y=y, a=a, b=b, c=c, d=d)
chutes = function() list(mu=mean(y), tau=1)
parametros = c("mu", "tau", "sigma")
res = BRugsFit(modelFile = modelo,
               data = dados.aux, inits = chutes,
               numChains = 1, parametersToSave = parametros,
               nBurnin = burn, nIter = iter, nThin = salto,
               working.directory = NULL, digits = 5)
cadeias  = cbind(samplesSample("mu"), samplesSample("tau"), samplesSample("sigma"))
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----")
print(heidel.diag(cadeias))
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
cadeias
}

# Simula��o de dados normais
set.seed(321)
n = 100
y = rnorm(n)
# Os hiperpar�metros das distribui��es a priori n�o-informativas
# default no INLA s�o:
a = 0
b = 0.00001
c = 1
d = 0.01

s1 = bayes.normal(iter=10000,burn=1000,salto=1,a,b,c,d,y)
#--------------------------------------------#

# Via INLA
formula = y ~ 1
res1    = inla(formula, data=data.frame(y))
summary(res1)
#--------------------------------------------#

# Especificando distribui��es a priori informativas:

# para mu (escala: m�dia)
a = 3  # mean
b = 4  # precision

# para tau (precis�o)
c = 1  # shape
d = 4  # inverse-scale

# via MCMC
s2 = bayes.normal(iter=10000,burn=1000,salto=1,a,b,c,d,y)
#--------------------------------------------#

# via INLA   
res2 = inla(formula, data  = data.frame(y),
            control.fixed  = list(mean.intercept=a, prec.intercept=b),
            control.family = list(prior="loggamma", param=c(c, d)))
summary(res2)

inla.doc('expression')

# sigma (desvio-padr�o) ~ Gamma(c,d): "sigma=exp(-log_precision/2)"

# Definindo a express�o considerando sigma:
loggamma_Sigma = "expression:
    c = 1;
    d = 4;
    sigma = exp(-log_precision/2);
    logdens = log(d^c) - lgamma(c) + (c-1)*log_precision - d*precision;
    log_jacobian = log_precision;
    return(logdens + log_jacobian);"
hyper.new = list(prec=list(prior=loggamma_Sigma))
res3 = inla(formula, data=data.frame(y),
             control.fixed=list(mean.intercept=a, prec.intercept=b),
             control.family=list(hyper=hyper.new))
summary(res3)

#standard deviation scale
sigma = inla.contrib.sd(res3, nsamples=1000)
sigma$hyper
