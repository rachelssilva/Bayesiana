# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula11")
library(INLA)  
#--------------------------------------------#

# Aplica��o TA2 (Slide de aula)

dados0 = read.table("dadosPiau.txt",header=TRUE)
attach(dados0)
head(dados0)

# F�meas - Fase crescimento
# trat: n�vel de PB%
#   ca: convers�o alimentar (resposta)
dadosF2f = dados0[fase==2&sexo==2,]
attach(dadosF2f)
#-----------------------#
y = ca
n = length(y)
dados.aux = list(n=n,y=y,trat=trat,periodo=periodo,pesoini=pesoini,tratcrep=tratcrep)
formula = y ~ trat+I(trat^2)+factor(periodo)+pesoini+f(tratcrep, model="iid")
#-----------------------#
reg.Bayes.SN = inla(formula, family = "skewnormal", data = dados.aux,
               control.predictor = list(compute = TRUE),
               control.compute = list(cpo=TRUE,dic=TRUE,config=TRUE))
summary(reg.Bayes.SN)
y.pred.bayes.SN = reg.Bayes.SN$summary.linear.predictor[,1]
res.pred.B.SN = matrix(c(mean(y.pred.bayes.SN),sd(y.pred.bayes.SN),
                quantile(y.pred.bayes.SN,c(0.025,0.975))),1,4,
                dimnames=list(NULL,c("M�dia","dp","P2.5%","P97.5%")))
# predi��o da CA a posteriori
res.pred.B.SN
#-----------------------#
par(mfrow=c(1,1))
plot(trat,y,xlab="PB (%)",ylab="CA",bty="n",pch=4)
points(trat,y.pred.bayes.SN,pch=16,col=4,cex=0.5)
legend(0.9*max(trat),3.4,c("Observados","Preditos.bayes"),
       pch=c(4,16),col=c(1,4),cex=0.7,bty="n")
# Reg. quadr�tica ajustada aos y.pred.bayes
regQuad.pred.SN = lm(y.pred.bayes.SN~trat+I(trat^2))
summary(regQuad.pred.SN)
a = regQuad.pred.SN$coef[[1]]
b = regQuad.pred.SN$coef[[2]]
c = regQuad.pred.SN$coef[[3]]
f = function(x) { a+b*x+c*x^2 }
z = nlm(f,mean(trat))
# Coordenada do Ponto Cr�tico
z$est
z$m
curve(a+b*x+c*x^2, min(trat), max(trat), add=T, col=4)
points(z$est, z$m, pch=19, col=4, cex=1)
arrows(z$est, z$m, z$est, min(y), length = 0.1, lty=2, col=4)
text(z$est, min(y), round(z$est,1), cex = 0.7, offset = 0.05)
arrows(z$est, z$m, min(trat), z$m, length = 0.1, lty=2, col=4)
text(min(trat), z$m, round(z$m,1), cex = 0.7, pos=1, offset=-1)
# Teste de ajuste
ks.test(y,y.pred.bayes.SN)
