# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#

#--------- M�todos Computacionais Intensivos ---------#

# Material did�tico sugerido:

# M�todos MCMC (Monte Carlo via Cadeias de Markov)
# http://cursos.leg.ufpr.br/ce089/08_MCMC.html

# M�todo da aceita��o e rejei��o Frequentista (Walmes - LEG/UFPR, 2017)
# http://www.leg.ufpr.br/~walmes/ensino/EC2/tutoriais/06-met-ac-rej.html

# Uma introdu��o aos m�todos bayesianos (Achar et al., Cap.7.2, 2019)

# Bayesian Modeling Using WinBUGS (Ntzoufras, Cap.2.3, 2009)

# M�todos MCMC (Firmino, Tese, 2009)
# https://repositorio.ufpe.br/bitstream/123456789/4950/1/arquivo3632_1.pdf

# Estat�stica Computacional e Simula��o MCMC (Alves, 2013)
# Dispon�vel dispon�vel na pasta do Moodle:
# Material Did�tico -> Diversos

# V�deo-aulas do canal do prof. Carlos A. Zarzar (UFOPA):
# www.youtube.com/@carloszarzar 
# 1) M�todos computacionais de integra��o 3.1./5
#    https://www.youtube.com/watch?v=sLl8uVQRULc
# 2) M�todo de amostragem Metropolis e Metropolis-Hastings 3.2./5
#    https://www.youtube.com/watch?v=Mv58A8m70q0&t=329s
# 3) M�todo de amostragem Gibbs 3.3./5
#    https://www.youtube.com/watch?v=ivk1R5wEDYE&t=244s

#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula11")

# Exemplos de Aplica��es:
# 1) MH - Aceita��o e Rejei��o - (Metropolis-Hastings, 1970)

# Gera��o de ~ Beta(a,b), considerando uma candidata ~ U(0,1)
set.seed(123)
a    = 2.7
b    = 6.3
nsim = 5000
X    = rep(runif(1),nsim)

for (i in 2:nsim)
	{
	    Y  = runif(1)
	 alpha = min(dbeta(Y,a,b)/dbeta(X[i-1],a,b),1)
	  X[i] = X[i-1]+(Y-X[i-1])*(runif(1)<alpha)
	}

burn  = 4500
X.sim = X[burn:nsim]
n.sim = length(X.sim)

par(mfrow=c(2,1))
plot(X,type='l',lwd=2,xlab='iter',ylab='X',bty='n')
plot(1:n.sim,X.sim,type='l',lwd=2,xlab='iter',ylab='X',bty='n')

# Verifica��o do ajuste 
x11()
par(mfrow=c(1,3))
hist(X.sim,main='',xlab='X',ylab='Probabilidade - MH',breaks=50,freq=FALSE)
curve(dbeta(x,a,b),col=2,lwd=2,add=TRUE)
#
hist(rbeta(n.sim,a,b),main='',xlab='X',ylab='Probabilidade - Gera��o direta',breaks=50,freq=FALSE)
curve(dbeta(x,a,b),col=2,lwd=2,add=TRUE)
# Q-Q plot
p = ppoints(100)
qB = qbeta(p,a,b) # Quantis te�ricos da Beta
qqplot(qB,X.sim,xlab='Quantis te�ricos',ylab='Quantis amostrais')
abline(0,1,col=2)
#--------------------------------------------#

# 2) MH para gerar uma amostra de uma distribui��o 'Rayleigh(sigma)'
# http://cursos.leg.ufpr.br/ce089/08_MCMC.html#331_Exemplo_(Rayleigh)

# Define fun��es:
f = function(x,sigma) { (x/sigma^2)*exp(-x^2/(2*sigma^2))*(x>=0)*(sigma>0)}
g = function(x,df) dchisq(x,df)

# Visualiza algumas propostas (pois os graus de liberdade da
# qui-quadrado ir� depender de cada valor sorteado em cada itera��o).
# NOTE que os graus de liberdade da qui-quadrado n�o precisam ser inteiros.

curve(f(x,4.0), from=0, to=20, ylim=c(0,0.3), lwd=2, bty='n')
curve(g(x,1.0), from=0, to=20, add=TRUE, col=2)
curve(g(x,2.5), from=0, to=20, add=TRUE, col=3)
curve(g(x,3.2), from=0, to=20, add=TRUE, col=4)
curve(g(x,4.0), from=0, to=20, add=TRUE, col=5)
legend("topright", legend=c("Rayleigh(4)", 
                   expression(chi^2 ~ (1.0)),
                   expression(chi^2 ~ (2.5)), 
				   expression(chi^2 ~ (3.2)),
                   expression(chi^2 ~ (4.0))), lty=1, col=1:5, bty='n')

# Para gerar valores de uma Rayleigh(4)
# uma implementa��o do algoritmo MH seria:	   

N     = 1e4
sigma = 4
x     = numeric(N)
x[1]  = rchisq(1,df=1)
k     = 0                

for (i in 2:N) 
    {
		y     = rchisq(1,df=x[i-1])
		num   = f(y,sigma)*g(x[i-1],df=y)
		den   = f(x[i-1],sigma)*g(y,df=x[i-1])
		alpha = num/den
		u     = runif(1)
		if (u <= alpha) {
			x[i] = y
			k    = k+1    
		} else {
			x[i] = x[i-1]
		}
    }
	
# Taxa de aceita��o:
k/N

# Tra�o da cadeia
par(mfrow=c(2,1))
burn  = 4500
X.sim = x[burn:nsim]
n.sim = length(X.sim)

par(mfrow=c(2,1))
plot(X,type='l',lwd=2,xlab='iter',ylab='X',bty='n')
plot(1:n.sim,X.sim,type='l',lwd=2,xlab='iter',ylab='X',bty='n')

# Histograma da distribui��o e correla��o entre as observa��es:
par(mfrow=c(1,2))
hist(x, freq=FALSE)
ind = seq(0, max(x), length.out=100)
lines(ind, (f(ind,sigma)), col=2)
acf(x, main='', bty='n')

# Compara acumulada emp�rica com te�rica
# Acumulada te�rica da Rayleigh
Fx = function(x, sigma) { 1 - exp(-x^2/(2 * sigma^2)) * (x >= 0) * (sigma > 0) }

par(mfrow = c(1,1))
plot(ecdf(x))
curve(Fx(x,4), add=TRUE, col=2, from=0)

