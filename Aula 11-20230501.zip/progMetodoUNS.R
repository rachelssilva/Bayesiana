# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula11")
library(BRugs) # Infer�ncia Bayesiana
library(car)   # Para o teste de homgeneidade de vari�ncias
library(coda)  # An�lise de converg�ncia
library(gamlss)# Para uso da distribui��o Skew normal
library(hnp)   # Envelope simulado
library(sn)    # Para uso da distribui��o Skew normal
#--------------------------------------------#

#------------- M�todo dos "UNS" -------------#

# Baseado no "Examples Volume 3" do OpenBUGS:
#            "Fun Shapes: general constraints"
model;
	{
		for (i in 1:n)
		{
		 uns[i]  ~ dbern(p[i])
		   p[i] <- # g(y[i],x[i],beta): f.d.p 
		}
		    beta ~ # priori
	}
# y: resposta
# x: vari�vel explicativa
# n: tamanho amostral
# uns = rep(1,n)
# dados.aux = list(n=n, x=x, y=y, uns=uns)	
#--------------------------------------------#

# Resposta com distribui��o (SN) Skew normal (Azallini,1985) 

# f.d.p.: f(y) = 2*dnorm(z)*pnorm(lambda*z)

# http://azzalini.stat.unipd.it
# Simula��o univariada
# http://azzalini.stat.unipd.it/SN/plot-SN1.html

# Gr�ficos sobrepostos
z      = seq(-4,4,length=80)
lambda = c(-5,0,5) # nu: assimetria (real)
y      = matrix(NA,80,3)

# f.d.p. SN
for (i in 1:3) { y[,i] = 2*dnorm(z,0,1)*pnorm((lambda[i]*z),0,1) }

matplot(z,y,main="",type="l",xlab="z",ylab="f(z)",
        col=1,ylim=c(0,0.8),bty="n")
legend("topright",paste("lambda=",lam),lty=1:3,cex=0.75,bty="n")
#---------------------#

# via 'sn'
# xi   : loca��o    (real)
# omega: escala     (>0) 
# alpha: assimetria (real)
# dsn(x,   xi=0, omega=1, alpha=0)
# psn(x,   xi=0, omega=1, alpha=0)
# qsn(p,   xi=0, omega=1, alpha=0) 
# rsn(n=1, xi=0, omega=1, alpha=0)

# Simula��o:
par(mfrow=c(1,2)) 
curve(dsn(x,xi=0,omega=1,alpha=5),-5,10,bty='n') #y ~ SN(0,1,5)
curve(dsn(x,xi=0,omega=1,alpha=0),-5, 5,bty='n') #y ~ N(0,1)
#---------------------#

# via 'gamlss'
?SN1
# Rigby et al. (2019, p.88)
# mu   : loca��o    (real)
# sigma: escala     (>0) 
# nu   : assimetria (real)
# SN1(mu.link = "identity", sigma.link = "log", nu.link="identity")
# dSN1(x, mu=0, sigma=1, nu=0)
# pSN1(q, mu=0, sigma=1, nu=0)
# qSN1(p, mu=0, sigma=1, nu=0)
# rSN1(n, mu=0, sigma=1, nu=0)

# Simula��o:
# Op��o 1: y ~ SN1(n,mu,sigma,nu)
par(mfrow=c(1,2)) 
curve(dSN1(x,mu=0,sigma=1,nu=5),-5,10,bty='n') #y ~ SN1(0,1,5)
curve(dSN1(x,mu=0,sigma=1,nu=0),-5, 5,bty='n') #y ~ N(0,1)
#---------------------#

# Op��o 2: y ~ SN2(n,mu,sigma,nu)
?SN2
# mu   : loca��o    (real)
# sigma: escala     (>0) 
# nu   : assimetria (>0)
par(mfrow=c(1,2)) 
curve(dSN2(x,mu=0,sigma=1,nu=5),-5,20,bty='n') #y ~ SN2(0,1,5)
curve(dSN2(x,mu=0,sigma=1,nu=1),-5, 5,bty='n') #y ~ N(0,1)
#**************************************************#

# Aplica��o:	
# Modelo Bayesiano para um MRLM - Erros Skew normais (SN)  
# Aplica��o TA1 (Slide de aula)
# Baseado no artigo de Cancho, Lachos e Ortega, p.555 (2010)
bayes.mrlm.sn = function(iter,burn,salto,chutes,semente,dados)
{
# Modelo Bayesiano para um MRLM - Erros Skew normais (SN)
# Baseado no artigo de Cancho, Lachos e Ortega, p.555 (2010)

set.seed(semente)
y = dados[,1]
P = ncol(dados)-1
x = dados[,3:(P+1)]
n = length(y)
uns = rep(1,n)
dados.aux = list(n=n, P=P, x=x, y=y, uns=uns)
sink("modelomrlmsn.txt")
cat("
model
{
for (i in 1:n)
{
    uns[i] ~  dbern(p[i])
      p[i] <- (2/sigma)*(1/(sqrt(2*3.1416)))*exp(-0.5*pow(aux[i],2))*phi(lambda*aux[i])
    aux[i] <- (y[i] - ( beta0 + inprod(x[i, ], beta[]) ) - mu.e)/sigma
}
# prioris
      beta0 ~ dnorm(0,0.000001)
for (j in 1:(P-1))
   {
    beta[j] ~ dnorm(0,0.000001)
   }
     lambda ~ dnorm(0,0.000001)
        tau ~ dgamma(0.001,0.001)
# c�lculos auxiliares
     sigma <- 1/sqrt(tau)
     delta <- lambda/sqrt(1+pow(lambda,2))
      mu.e <- sigma*delta*sqrt(2/3.1416)
beta0.star <- beta0+mu.e   
  skewness <- 0.2180468*pow(delta,3)*pow(1-0.6366385*pow(delta,2),-1.5)
# o modelo estimado ser�:
# y = beta0.star + beta*X + sigma*e; e ~ SN(-mu.e,1,lambda) 
}
",fill=TRUE)
sink()		
modelo = "modelomrlmsn.txt"  
chutes.aux = function() list(beta0=chutes[1],beta=chutes[2:P],
                             lambda=chutes[P+1],tau=1)
parametros = c("beta0","beta0.star","beta",
               "lambda","sigma","tau","delta","mu.e","skewness")
res = BRugsFit(modelFile=modelo, data=dados.aux,  inits=chutes.aux,
               parametersToSave=parametros, 
               numChains=1,  nBurnin=burn, nIter=iter, nThin=salto,
               DIC=TRUE, working.directory=NULL, digits=5)
cat("\n---------------Estimativas Bayesianas---------------")
cat("\n ")
print(res)
nome.pars = c("beta0","beta0.star",paste("beta[",1:(P-1),"]",sep=""),
              "lambda","sigma","tau")
cadeias = samplesSample("beta0")
for (j in 2:length(nome.pars))
 {
 cadeias = cbind(cadeias,samplesSample(nome.pars[j]))
 }
cat("\n -----Crit�rio de converg�ncia Heidelberger e Welch-----")
names(cadeias) = col.nomes = c(nome.pars)
dimnames(cadeias) = list(NULL,col.nomes)
print(heidel.diag(cadeias))
cadeias
}

# Os dados
dados  = read.table("dadosagro.txt",header=T,skip=0)
dados  = as.matrix(dados)
dados  = dados[,c(4,1,2)]
y      = dados[,1] # H (altura)
x1     = dados[,2] # trat
x2     = dados[,3] # vaso
M.aov  = aov(y ~ x1+x2)
M      = model.matrix(M.aov)
dados0 = cbind(y,M)
#-----------------------------#

# Frequentista - Erros normais (N)
reg.N  = lm(y ~ x1+x2)
summary(reg.N)
par(mfrow=c(2,2))        
plot(reg.N)

par(mfrow=c(1,2)) 
e      = residuals(reg.N)
hist(e,xlab='Res�duos',ylab='Probabilidade',main='',prob=TRUE)
p      = seq(0,1,length.out=length(y))
qq     = qnorm(p,0,sd=1)
plot(qq,sort(e),xlab="Quantis te�ricos",ylab="Res�duos ordenados")
with(reg.N, qqline(residuals,col="red"))

# teste de homogeneidade de vari�ncias:
bartlett.test(y ~ x1)
bartlett.test(y ~ x2)
leveneTest(y ~ factor(x1)) 
leveneTest(y ~ factor(x2)) 
  
# teste de normalidade nos erros
ks.test(e,"pnorm")
shapiro.test(e)
#-----------------------------#

# Frequentista - Erros Skew normais (SN)
# via 'sn'
reg.SN = selm(y ~ x1+x2,family="SN")
summary(reg.SN)
par(mfrow=c(2,2))        
plot(reg.SN)
e1 = residuals(reg.SN)
hnp(e1, halfnormal=F)

# via 'gamlss'
reg2.SN = gamlss(y ~ x1+x2,family="SN2")
summary(reg2.SN)
par(mfrow=c(2,2))        
plot(reg2.SN)

e2 = residuals(reg2.SN)
hnp(e2, halfnormal=F)
#-----------------------------#

# Bayesiano
saida = bayes.mrlm.sn(iter=100000,burn=10000,salto=10,chutes=c(-1.8,0.1,0.9,0.8),semente=123,dados=dados0)
#              mean      sd MC_error val2.5pc median val97.5pc start sample
#beta0      -4.4410 0.40300 0.014460 -5.25600 -4.4280  -3.6840 10001  16666
#beta0.star -3.0660 0.41230 0.015960 -3.87500 -3.0540  -2.2820 10001  16666
#beta1       0.1085 0.00998 0.000439  0.09049  0.1081   0.1283 10001  16666 # sig
#beta2       0.9023 0.12710 0.005006  0.65820  0.9019   1.1570 10001  16666 # sig
#delta       0.9752 0.02067 0.001012  0.92480  0.9804   0.9977 10001  16666
#lambda      5.8720 3.14100 0.194500  2.43100  4.9800  14.8200 10001  16666 # sig
#mu          1.3740 0.14280 0.006254  1.10400  1.3720   1.6590 10001  16666
#sigma       1.7640 0.15930 0.006509  1.47800  1.7570   2.0950 10001  16666
#skewness    0.8276 0.11410 0.005909  0.56100  0.8502   0.9771 10001  16666
#       Dbar  Dhat   DIC   pD
#total 342.9 338.4 347.3 4.47    
#-----------------------------#

# An�lise de Res�duos do modelo MRLMSNormal (Erro skew-normal)
# y = b0 + b1*x1 + b2*x2 + sigma*e
f.res2 = function(beta0,beta1,beta2,sigma,lambda,dados)
{
    y = dados[,1]
    n = length(y)
   x1 = dados[,2]
   x2 = dados[,3]
delta = lambda/sqrt(1+lambda**2)  
   mu = sigma*delta*0.7978846
  location = -delta*sqrt(2/pi)
beta0.star = beta0 + mu
     e = numeric()
e.star = numeric()
for (i in 1:n)
{
     e[i] = (y[i] - (beta0.star + beta1*x1[i] + beta2*x2[i]))
e.star[i] = (e[i] + location)
}
par(mfrow=c(1,2))
z  = seq(min(e),max(e),length=100)
hist(e,prob=TRUE,breaks="FD",main='',xlab='Res�duo',ylab='Probabilidade')
lines(z,dsn(z,xi=0,omega=sigma,alpha=lambda),type="l",col=2)
p  = seq(0,1,length.out=n)
qq = qsn(p,xi=0,omega=sigma,alpha=lambda)
plot(qq,sort(e),xlab="Quantis te�ricos",ylab="Res�duos ordenados")
# Fun��o para plotar qqsn
qqline.aux=function (e,xi,omega,alpha) 
{
e.aux = sort(e)
e.aux = quantile(e.aux[!is.na(e.aux)],c(0.25,0.75))
x.aux = qsn(c(0.25, 0.75),xi,omega,alpha)
   b1 = diff(e.aux)/diff(x.aux)
   b0 = e.aux[1L] - b1*x.aux[1L]
abline(b0,b1,col=2)
}
qqline.aux(e,xi=0,omega=sigma,alpha=lambda)
# teste de ajuste nos erros - modelo centrado
cat("\n Ho: Os res�duos s�o Normais") 
print(ks.test(e,"pnorm")) # Normal padr�o
cat("\n Ho: Os res�duos s�o Skew-Normais") 
# Teste de verifica��o se os erros seguem uma Skew normal 
print(ks.test(e,"psn",xi=0,omega=sigma,alpha=lambda))
e          
}

residuo = f.res2(beta0=-4.44,beta1=0.11,beta2=0.90,sigma=1.76,lambda=5.87,dados=cbind(y,x1,x2))
# Ho: Os res�duos s�o normais
#D = 0.4864, p-value < 2.2e-16

# Ho: Os res�duos s�o Skew normais
#D = 0.1077, p-value = 0.1234                                                            
