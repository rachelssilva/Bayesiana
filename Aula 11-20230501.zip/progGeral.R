# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

#------- Utiliza��o de outros pacotes Bayesianos ----------#

rm(list=ls(all=TRUE))
setwd("C:/Users/AulasPraticas/Aula11")

# Algumas livrarias para o procedimento Bayesiano
# 'coda'           # An�lise de Converg�ncia MCMC
# 'BRugs'          # Infer�ncia Bayesiana via OpenBUGS
# 'MCMCpack'       # Modelos de Regress�o Linear Bayesianos
# 'MCMCglmm'       # GLM's Bayesianos 
# 'rjags'          # JAGS http://mcmc-jags.sourceforge.net
# 'rstan'          # STAN https://mc-stan.org
# 'brms'           # (Non)linear multivariate, multilevel modeling by Stan
                   # https://mc-stan.org/users/interfaces/brms
# 'BANOVA          # Modelos Bayesianos Hier�rquicos 
                   # Necessita instala��o do programa JAGS
# 'LaplacesDemon'  # Pacote completo para Infer�ncia Bayesiana
# 'INLA'           # INLA - Modelos Latentes (Estima��o instant�nea) 
                   # www.r-inla.org

# Observa��o 1)
# Existem muitos pacotes Bayesianos oficiais e n�o oficiais.
# Dos oficiais contidos na p�gina do R no menu "Packages" ordenados por nome:
# basta dar uma busca (Ctrl+F) do tema "bayes" ou "bayesian"				   
# https://cran.r-project.org

# A lista completa de pacotes Bayesianos no R:
# http://cran.r-project.org/web/views/Bayesian.html

# Observa��o 2)
# Tamb�m existem programas estat�sticos espec�ficos (gratuitos e comerciais):
# JASP https://jasp-stats.org
# SAS  https://welcome.oda.sas.com	  
#--------------------------------------------#

# Exemplos de aplica��es:
# Dados de Convers�o Alimentar de coelhos
# em fun��o do n�vel de baga�o de uva da ra��o (%).
y = c(2.42,2.59,2.71,2.63,2.82,2.40,2.70,2.77,2.74,2.58,2.86,2.65,
      2.71,2.85,2.82,3.12,2.39,2.96,2.65,3.10,2.75,2.71,2.89,2.96,
      2.98,2.83,2.68,3.00,2.85,2.97,2.46,2.61,2.67,2.76,2.57,2.67,
      2.52,2.69,2.76,3.12,2.53,2.52,2.73,2.78,2.62,2.71,2.76,2.65,
      2.68,3.02)
x = c(5,5,5,5,5,5,5,5,5,5,
      10,10,10,10,10,10,10,10,10,10,
      15,15,15,15,15,15,15,15,15,15,
      20,20,20,20,20,20,20,20,20,20,
      25,25,25,25,25,25,25,25,25,25)
plot(x,y,xlab="N�vel tratamento (%)",ylab="CA",bty="n")

# Estimativas Frequentistas
# Regress�o Linear:
M1 = lm(y~x)
summary(M1)
lines(x,predict(M1),lty=1,col=2)

# Regress�o Quadr�tica:
M2 = lm(y~x+I(x^2))
summary(M2)
lines(x,predict(M2),lty=1,col=4)

AIC(M1)
AIC(M2)
#--------------------------------------------#
     
# Markov Chain Monte Carlo for Gaussian Linear Regression
library(MCMCpack)
?MCMCregress # ver index

# Regress�o Linear:
modelo.M1 = MCMCregress(y ~ x,
                        burnin=5000, mcmc=50000, thin=1,
                        b0=c(2.7,0), B0=c(0.000001,0.000001),
                        c0=0.001, d0=0.001,
                        marginal.likelihood="Chib95")
summary(modelo.M1)

library(coda)
heidel.diag(modelo.M1)
HPDinterval(modelo.M1)
plot(modelo.M1)

# Regress�o Quadr�tica:
modelo.M2 = MCMCregress(y ~ x + I(x^2),
                        burnin=5000, mcmc=50000, thin=1, 
                        b0=c(2.5,0.05,-0.002),
                        B0=c(0.000001,0.000001,0.000001),
                        c0=0.001, d0=0.001,
                        marginal.likelihood="Chib95")
summary(modelo.M2)
heidel.diag(modelo.M2)
HPDinterval(modelo.M2)
plot(modelo.M2)

# C�lculo do Fator de Bayes
BayesFactor(modelo.M1, modelo.M2)
#log marginal likelihood =  -16.08554   (M1)
#log marginal likelihood =  -26.98713   (M2 � mais plaus�vel!)

# Observa��o: O FB est� implementado em alguns pacotes bayesianos
#             Sugestivos: rstan e LaplacesDemon
#--------------------------------------------#

# Multivariate Generalised Linear Mixed Models
library(MCMCglmm)    
?MCMCglmm

dados = data.frame(cbind(x,y))
modelo.M2 = MCMCglmm(y ~ x + I(x^2), data=dados,
                     family="gaussian",
                     nitt=50000, burnin=5000, thin=1, 
                     verbose=FALSE, DIC=TRUE)
# Resultados
summary(modelo.M2)
plot(modelo.M2)

names(modelo.M2)
#--------------------------------------------#

# Outros Programas Bayesianos gratuitos tamb�m est�o dispon�veis na web:
# JAGS: Just Another Gibbs Sampler
# http://mcmc-jags.sourceforge.net
library(rjags)

bayes.MCMC.jags = function(Niter,Nburnin,semente,y,x)
{
set.seed(semente)
Model = "
model
  { 
  for(i in 1:n)
  {
     y[i]  ~ dnorm(mu[i],tau) 
    mu[i] <- beta0 + beta1*x[i]
  }
    beta0 ~ dnorm(0,0.000001) 
    beta1 ~ dnorm(0,0.000001) 
      tau ~ dgamma(0.001, 0.001) 
   sigma <- 1/sqrt(tau)
  }"
cat(Model, file=paste(getwd(),"/modeloregnormal.bug",sep=""))
dados.aux = list("y"=y,"x"=x,"n"=length(y))
est.freq  = lm(y~x)
cat("\n --------- An�lise Frequentista ------------- ")
cat("\n")
print(summary(est.freq))
b0 = est.freq$coef[1]
b1 = est.freq$coef[2]
chutes = function() list(beta0=b0,beta1=b1,tau=1)
parameters = c("beta0","beta1","tau","sigma")
cat("\n --------- An�lise Bayesiana ------------- ")
cat("\n")
res = jags.model(file="modeloregnormal.bug", data=dados.aux,
                 inits=chutes, n.chains=1, n.adapt=Nburnin)
res.out = coda.samples(res, parameters, n.iter=Niter)
print(summary(res.out))
res.out
}

# Exemplo: Simula��o
set.seed(12345)
n    = 100
b0   = 0.5
b1   = 2
x    = rnorm(n)
mu   = b0 + b1*x
dp   = 0.5
y    = rnorm(n, mean = mu, sd = dp)
dados.aux = list(y,x,n=length(y))
plot(x,y,bty="n")
summary(lm(y~x))
lines(x,predict(lm(y~x)),lty=1,col=4)

saida = bayes.MCMC.jags(Niter=1000000,Nburnin=100000,semente=123,y,x)
#--------------------------------------------#

# Estima��o Bayesiana vis STAN
# (Non)linear multivariate, multilevel modeling
# https://cran.rstudio.com/web/packages/brms

library(rstan)    
# https://mc-stan.org
library(brms)    
# https://mc-stan.org/users/interfaces/brms
# https://cran.r-project.org/web/packages/brms/vignettes/brms_nonlinear.html

options(mc.cores=parallel::detectCores())
rstan_options(auto_write=TRUE)

# Exemplo de estima��o N�o Linear
# Modelo exponencial: b1*exp(b2*x)
# Simulando dados
set.seed(123)
b    = c(2, 0.75)
x    = rnorm(100)
y    = rnorm(100, mean=b[1]*exp(b[2]*x))
dat  = data.frame(x,y); dat
plot(x,y,pch=20,bty='n')

prior = prior(normal(1, 2), nlpar="b1") +
        prior(normal(0, 2), nlpar="b2")
		 
fit   = brm(bf(y ~ b1*exp(b2*x), b1+b2 ~ 1, nl=TRUE),
            data=dat, prior=prior)
summary(fit)
# Draws: 4 chains, each with iter = 2000; warmup = 1000; thin = 1;
# total post-warmup draws = 4000

# Population-Level Effects: 
             # Estimate Est.Error l-95% CI u-95% CI Rhat Bulk_ESS Tail_ESS
# b1_Intercept     1.93      0.11     1.71     2.14 1.01     1469     1504
# b2_Intercept     0.75      0.04     0.67     0.83 1.01     1446     1528

# Family Specific Parameters: 
      # Estimate Est.Error l-95% CI u-95% CI Rhat Bulk_ESS Tail_ESS
# sigma     0.98      0.07     0.85     1.13 1.00     2475     2219

plot(fit)

# Ajuste
conditional_effects(fit,add=TRUE)
points(x,y,pch=20,bty='n')

# Observa��o 1: Comparando modelos via 'Fator de Bayes'
?bayes_factor.brmsfit
# Observa��o 2: Comparando modelos via 'LOO'
?loo.brmsfit
# ou via pacote 'loo'
# https://mc-stan.org/loo/index.html
# https://mc-stan.org/loo/articles/loo2-example.html
#--------------------------------------------#

# Modelos Bayesianos Hier�rquicos em ANOVA
library(BANOVA) # Necessita instala��o do programa JAGS
?BANOVA

data(goalstudy)
head(goalstudy)
?goalstudy
# Estudo do impacto da variedade entre os meios de motiva��o para atingir um objetivo

str(goalstudy)
# Resposta:   bid          (continuous)
# Fator:      progress     (dicotomic, 1 or 2)
# Fator:      prodvar      (dicotomic, 1:low or 2:high)
# Covari�vel: perceivedsim (integer ordinal scale, 1=not at all similar - 7=very similar)

# Estimation of BANOVA with a normally distributed dependent variable
res1 = BANOVA.Normal(bid~1, ~progress*prodvar, data=goalstudy, goalstudy$id,
                    sample=1000, burnin=1000, thin=1)					
summary(res1)
# Observa��o: 
# Existem muitas distribui��es implementadas
# ver "Index" em ?BANOVA 
# http://127.0.0.1:14996/library/BANOVA/html/00Index.html
#--------------------------------------------#

# Em especial, um pacote de grande import�ncia na modelagem Bayesiana:

#---- INLA ----# 
# www.r-inla.org

# Os "modelos Gaussianos latentes" (LGM) � talvez a classe de modelos mais
# comuns em aplica��es estat�sticas.
# LGM's incluem, entre outras, grande parte dos modelos lineares (generalizados)
# modelos aditivos(generalizados), modelos de suaviza��o de splines,
# modelos de estado de espa�o, regress�o semi-param�trica, modelos espaciais,
# modelos espa�o-temporais, processos log-Gaussianos de Cox, entre outros.
#
# Integrated Nested Laplace Approximations"(INLA), na sua tradu��o ao portugu�s,
# "Integra��o Aproximada Aninhada de Laplace" � um m�todo proposto por
# Rue et al. (2009) para infer�ncia Bayesiana em LGM's.
# O conceito de LGM � de modelagem por est�gio, o que permite que essa fam�lia
# de modelos seja modelada de forma unificada utilizando uma mesma classe
# de algoritmos.
# Resumidamente, o INLA oferece aproxima��es das marginais a posteriori dos
# par�metros de forma r�pida e precisa atrav�s da utiliza��o de recursos
# algoritmicos e aproxima��es de distribui��es.
# O benef�cio dessas aproxima��es � computacional no qual, enquanto,
# algoritmos de Markov Chain Monte Carlo (MCMC) podem demorar horas ou at� dias
# para atingir converg�ncia das cadeias simuladas, o INLA fornece aproxima��es
# precisas em minutos ou at� segundos.
# Outra vantagem do m�todo � sua generalidade, que permite fazer
# an�lises Bayesianas de forma autom�tica oferecendo crit�rios de compara��o
# de modelos e outras medidas de predi��o para que modelos em estudos
# possam ser comparados.

#----------------------------------------#
# V�ctor Hugo Lachos D�vila              #
# Departmento de Estat�stica-UNICAMP     #
#----------------------------------------#

# Livraria do R
library(INLA) 
# instala��o pelo site www.r-inla.org
install.packages("INLA", repos=c(getOption("repos"), INLA="https://inla.r-inla-download.org/R/stable"), dep=TRUE)
# se precisar de pacotes importantes:
if (!requireNamespace("BiocManager", quietly=TRUE))
install.packages("BiocManager")
BiocManager::install(c("graph", "Rgraphviz"), dep=TRUE)

# ATEN��O: Dependendo da instala��o, s� ir� funcionar 
#          em plataforma 64 bits!

# Fam�lias do pacote
names(inla.models()$likelihood)
inla.doc("normal")

# Exemplos:
# Considerando os dados de Convers�o Alimentar de coelhos
# em fun��o do n�vel de baga�o de uva da ra��o (%).
y = c(2.42,2.59,2.71,2.63,2.82,2.40,2.70,2.77,2.74,2.58,2.86,2.65,
      2.71,2.85,2.82,3.12,2.39,2.96,2.65,3.10,2.75,2.71,2.89,2.96,
      2.98,2.83,2.68,3.00,2.85,2.97,2.46,2.61,2.67,2.76,2.57,2.67,
      2.52,2.69,2.76,3.12,2.53,2.52,2.73,2.78,2.62,2.71,2.76,2.65,
      2.68,3.02)
x = c(5,5,5,5,5,5,5,5,5,5,
      10,10,10,10,10,10,10,10,10,10,
      15,15,15,15,15,15,15,15,15,15,
      20,20,20,20,20,20,20,20,20,20,
      25,25,25,25,25,25,25,25,25,25)
plot(x,y,xlab="N�vel tratamento (%)",ylab="CA",bty="n")

dados.aux = list(y=y, x=x)
formula   = y ~ 1+x+I(x^2)
res = inla(formula, family="gaussian", data=dados.aux)
summary(res)
	   
# Fixed effects:
              # mean    sd 0.025quant 0.5quant 0.975quant   mode kld (#Diverg�ncia de Kullback-Leibler)
# (Intercept)  2.465 0.116      2.237    2.465      2.693  2.465   0
# x            0.047 0.018      0.012    0.047      0.082  0.047   0
# I(x^2)      -0.002 0.001     -0.003   -0.002      0.000 -0.002   0

# Model hyperparameters:
                                         # mean   sd 0.025quant 0.5quant 0.975quant  mode
# Precision for the Gaussian observations 35.68 7.21      22.98    35.19      51.13 34.22

# Expected number of effective parameters(stdev): 3.01(0.002)
# Number of equivalent replicates : 16.61 

# Marginal log-Likelihood:  -11.01 
#--------------------------------------------#

# Outros Exemplos:
# https://haakonbakkagit.github.io/alltopics.html

# Exemplo 1. Normal (m�dia)
set.seed(12345)
n       = 1000
y       = rnorm(n)
dados   = data.frame(y)
formula = y ~ 1

# comando b�sico
res0 = inla(formula, family="gaussian", data=dados)
summary(res0)

# inclus�o de argumentos
hyper   = list(prec=list(initial=0, fixed=T))

res     = inla(formula, family='gaussian', data=dados)
summary(res)

names(res)

plot(res, single=TRUE)
mu.est  = res$marginals.fixed[[1]]      # m�dia a posteriori
inla.hpdmarginal(0.95, mu.est)          # intervalo HPD

tau.est   = res$marginals.hyperpar[[1]] # tau a posteriori
inla.hpdmarginal(0.95, tau.est)
sigma.est = 1/sqrt(tau.est)             # sigma a posteriori
summary(sigma.est)

# Para opera��es/fun��es com as marginais:
# https://rdrr.io/github/andrewzm/INLA/man/marginal.html

# Fun��o 'inla.tmarginal()' 
sigma.est = inla.tmarginal(function(x) 1/sqrt(x), tau.est)
summary(sigma.est[,1])

# Estimativa via MCMC
# Modelo Bayesiano para estimar par�metros de uma popula��o - Erros Normais

# model
# {
   # for(i in 1:n)
      # {
       # y[i] ~ dnorm(mu, tau)
      # }
         # mu ~  dnorm(0, 0.000001)  # M�dia
        # tau ~  dgamma(0.001,0.001) # Precis�o
      # sigma <- 1/sqrt(tau) 	       # Desvio-padr�o
# }

# Fun��o dispon�vel na 'Aula 6'
library(BRugs)
library(coda)
saida1 = normal.bayes(iter=10000,burn=1000,salto=1,semente=123,y)
         # mean      sd  MC_error val2.5pc  median val97.5pc start sample
# mu    0.04627 0.03176 0.0003261 -0.01534 0.04639    0.1094  1001  10000
# sigma 0.99960 0.02247 0.0001904  0.95680 0.99920    1.0450  1001  10000
# tau   1.00200 0.04501 0.0003852  0.91550 1.00200    1.0930  1001  10000

# Estimativas via MCMC via pacote "MCMCglmm"
# Multivariate Generalised Linear Mixed Models
dados = data.frame(y)
library(MCMCglmm)
res.MCMC = MCMCglmm(y ~ 1, family="gaussian", data=dados, verbose=FALSE)
summary(res.MCMC)
# DIC: 2838.357 
# R-structure:  ~units
#            post.mean  l-95% CI u-95% CI eff.samp
#units           0.9971    0.922     1.09     1000         # Vari�ncia
#            post.mean  l-95% CI u-95% CI eff.samp pMCMC
#(Intercept)   0.04488 -0.01493   0.10645     1000 0.154
#--------------------------------------------#

# Exemplo 2. Normal (regress�o)
# Simula��o dos dados
set.seed(12345)
n       = 1000
a       = 1
b       = 1
z       = rnorm(n)
eta     = a + b*z
tau     = 100
scale   = exp(rnorm(n))
prec    = scale*tau
y       = rnorm(n, mean=eta, sd=1/sqrt(prec))
data    = list(y=y, z=z)
formula = y ~ 1 + z
res     = inla(formula, family="gaussian", data=data, keep=TRUE)           
summary(res)

# Estimativa via MCMC
# Modelo Bayesiano para An�lise Regress�o Linear Simples - Erros Normais

#model;
#{
#  for (i in 1:n) 
#	     {	
#		 y[i]  ~ dnorm(mu[i], tau)
#		mu[i] <- beta0 + beta1 * x[i]
#      }
#		beta0 ~ dnorm(0, 0.000001)
#		beta1 ~ dnorm(0, 0.000001)   
#		  tau ~ dgamma(0.001,0.001)
#      sigma <- sqrt(1/tau)             	  
#     sigma2 <- pow(sigma,2)
## C�lculo do valor predito de x0
#	  y.pred <- beta0 + beta1*X0
#}

# Fun��o dispon�vel na 'Aula 9'
saida2 = MRL.bayes(iter=10000,burn=1000,salto=1,semente=123,x=z,y=y,x0=1)
#        mean          sd  MC_error     val2.5pc median val97.5pc start sample
#beta0   0.99780 0.0039980 4.197e-05  0.99000  0.99780    1.0060  1001  10000
#beta1   0.99570 0.0040710 3.914e-05  0.98780  0.99570    1.0040  1001  10000
#sigma   0.12700 0.0028930 2.783e-05  0.12150  0.12690    0.1327  1001  10000
#sigma2  0.01613 0.0007354 7.085e-06  0.01475  0.01611    0.0176  1001  10000
#tau    62.12000 2.8290000 2.712e-02 56.81000 62.07000   67.7900  1001  10000
#y.pred  1.99400 0.0055890 5.345e-05  1.98300  1.99400    2.0040  1001  10000

# Exemplo 2b.
set.seed(12345)
y       = rnorm(50,50,1.5)
z       = rep(1:5,10) 
data    = list(y=y, z=z)
formula = y ~ 1 + z
res     = inla(formula, family="gaussian", data=data, keep=TRUE)
summary(res)

# Estimativa via MCMC
saida2b = MRL.bayes(iter=10000,burn=1000,salto=1,semente=123,x=z,y=y,x0=3)
#           mean      sd  MC_error val2.5pc   median val97.5pc start sample
#beta0  50.87000 0.55570 0.0217200  49.7600 50.87000   51.9900  1001  10000
#beta1  -0.20200 0.16680 0.0065540  -0.5284 -0.20210    0.1255  1001  10000
#sigma   1.66100 0.17500 0.0021690   1.3580  1.64600    2.0380  1001  10000
#sigma2  2.79100 0.59900 0.0074450   1.8450  2.71100    4.1520  1001  10000
#tau     0.37410 0.07722 0.0009457   0.2409  0.36890    0.5422  1001  10000
#y.pred 50.26000 0.23950 0.0027770  49.7900 50.26000   50.7400  1001  10000

# Estimativa via MCMCglmm
dados    = data.frame(cbind(y,z))
res.MCMC = MCMCglmm(y ~ z, family="gaussian", data=dados, verbose=FALSE)
summary(res.MCMC)
# DIC: 195.142 
# R-structure:  ~units
#            post.mean l-95% CI u-95% CI eff.samp
#units           2.782     1.82    4.066     1181          # Vari�ncia
#            post.mean l-95% CI u-95% CI eff.samp  pMCMC    
#(Intercept)   50.8867  49.8439  51.9595     1000 <0.001 ***
#z             -0.2059  -0.5280   0.1290     1000  0.214      
#--------------------------------------------#

# Exemplo 3. Binomial (regress�o glm)
# Simula��o dos dados
set.seed(12345)
n       = 10
a       = 1
b       = 1
z       = rnorm(n)
eta     = a + b*z
N       = sample(c(1,5,10,15), size=n, replace=TRUE)
prob    = exp(eta)/(1 + exp(eta))
y       = rbinom(n, size=N, prob=prob)
dados   = list(y=y, N=N, z=z); dados
formula = y ~ 1 + z

# via GLM (frequentista)
reg     = glm(cbind(y,N-y) ~ z, family=binomial(link="logit"))
summary(reg)
            # Estimate Std. Error z value Pr(>|z|)    
# (Intercept)   0.8635     0.2414   3.578 0.000347 ***
# z             0.8884     0.2623   3.387 0.000706 ***

# Fun��o para c�lculo de probabilidades via curva Log�stica estimada
p.logit = function(beta,x)
          {
            k = length(x)
            beta0 = beta[1]
            beta.aux = beta[2:(k+1)]
            z = beta0 + beta.aux%*%x
            p = exp(z)/(1+exp(z))
            p
          } 

# Gr�fico da Curva Log�stica Ajustada
y.aux    = numeric()
x.aux    = seq(-5,5,0.01) # te�rica
beta.est = reg$coefficients
for (i in 1:length(x.aux)) { y.aux[i] = p.logit(beta=beta.est,x=x.aux[i]) }
plot(x.aux,y.aux, type="l", xlab="x", ylab='p', bty="n")
		  
# via INLA
reg1    = inla(formula, family="binomial", data=dados, N=N)
summary(reg1)
             # mean    sd 0.025quant 0.5quant 0.975quant  mode kld
# (Intercept) 0.866 0.241      0.410    0.860      1.357 0.848   0
# z           0.898 0.262      0.403    0.892      1.433 0.878   0

# via MCMC:

#model;
#{
#for( i in 1:N)
#   {
#          y[i] ~  dbin(p[i], n[i])
#   logit(p[i]) <- beta0 + beta1*x[i]
#   }
## Prioris
#          beta0 ~ dnorm(0, 0.000001)
#          beta1 ~ dnorm(0, 0.000001)
#}

# Somente o Professor:
source("G:\\programas.r")

dados.aux = cbind(y,N,z)
saida3 = bayes.reg.bin.logit(iter=10000,burn=1000,salto=1,dados=dados.aux)
#          mean     sd MC_error val2.5pc median val97.5pc start sample
# alpha0 0.8834 0.2427 0.002585   0.4161 0.8791     1.373  1001  10000
# alpha1 0.9183 0.2688 0.003360   0.4069 0.9128     1.478  1001  10000

# Exemplo 3b: Germinacao de sementes
data(Seeds)
r      = Seeds$r
n      = Seeds$n
z      = Seeds$x1
N      = n-r
dados3b = cbind(r,N); dados3b

# via GLM (frequentista)
reg3b  = glm(dados3b  ~ z, family=binomial(link="logit"), data=Seeds)
summary(reg3b)
            # Estimate Std. Error z value Pr(>|z|)    
# (Intercept)  0.11653    0.08413   1.385    0.166
# z           -0.23789    0.14928  -1.594    0.111

# via MCMC
saida3c = bayes.reg.bin.logit(iter=10000,burn=1000,salto=1,dados=Seeds)
#          mean      sd  MC_error val2.5pc  median val97.5pc start sample
# beta0  0.1166 0.08371 0.0009345 -0.04775  0.1172   0.27820  1001  10000
# beta1 -0.2396 0.15070 0.0015690 -0.53590 -0.2394   0.05272  1001  10000

# via INLA
dados3d  = list(r=r, z=z)
reg3d    = inla(r ~ 1 + z,family="binomial",data=dados3d,N=N)
summary(reg3d)
              # mean    sd 0.025quant 0.5quant 0.975quant   mode kld
# (Intercept)  0.116 0.084     -0.049    0.116      0.282  0.116   0
# z           -0.238 0.149     -0.532   -0.238      0.055 -0.238   0
#--------------------------------------------#

# Exemplo 4. Poisson (regress�o)
# Simula��o de dados
set.seed(12345)
n       = 100
a       = 1
b       = 1
z       = rnorm(n)
eta     = a + b*z
E       = sample(1:10, n, replace=TRUE)
lambda  = E*exp(eta)
y       = rpois(n, lambda=lambda)
data    = list(y=y, z=z)
formula = y ~ 1 + z
result  = inla(formula, family="poisson", data=data, E=E)
summary(result)
             # mean    sd 0.025quant 0.5quant 0.975quant  mode kld
# (Intercept) 0.987 0.030      0.926    0.987      1.046 0.987   0
# z           1.000 0.019      0.963    1.000      1.038 1.000   0

# Exemplo 4b.
# Exemplo 7.1 p.246-Ntzoufras Aircraft damage dataset Montogomery et al. 2006
y = c(0,1,0,0,0,0,1,0,0,2,1,1,1,1,2,3,1,1,1,2,0,1,1,2,5,1,1,5,5,7) 
z = c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1) 
data    = list(y=y, z=z)
formula = y ~ 1+z
res     = inla(formula, family="poisson", data=data,
               control.predictor=list(compute=TRUE),
               control.compute=list(cpo=TRUE,dic=TRUE,config=TRUE))
summary(res)
              # mean    sd 0.025quant 0.5quant 0.975quant   mode kld
# (Intercept) -0.406 0.316     -1.074   -0.389      0.167 -0.354   0
# z            1.281 0.357      0.617    1.268      2.021  1.241   0

# via MCMC       
# Modelo Bayesiano para An�lise Regress�o Linear Simples - Erros Poisson

#model;
#{
#  for ( i in 1:n )
#       {
#              y[i]  ~  dpois(mu[i])
#         log(mu[i]) <- beta0 + beta1*x[i]
#       }
#         beta0 ~ dnorm( 0, 0.000001 )
#         beta1 ~ dnorm( 0, 0.000001 )
#}

# Somente o Professor:  
saida4b = bayes.reg1.poisson(iter=30000,burn=1000,salto=1,y,x=z)
#beta0 -0.4533 0.3242 0.004116  -1.1310 -0.4356    0.1366  1001  30000
#beta1  1.3130 0.3659 0.004575   0.6334  1.3000    2.0600  1001  30000
#--------------------------------------------#

# Exemplo 4c (continua��o com mais covari�veis)                                 
y  = c(0,1,0,0,0,0,1,0,0,2,1,1,1,1,2,3,1,1,1,2,0,1,1,2,5,1,1,5,5,7) 
x1 = c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1) 
x2 = c(4,4,4,5,5,5,6,6,6,7,7,7,8,8,8,7,7,7,10,10,10,12,12,12,8,8,8,14,14,14)
x3 = c(91.5,84,76.5,69,61.5,80,72.5,65,57.5,50,103,95.5,88,80.5,73,116.1,100.6,
       85,69.4,53.9,112.3,96.7,81.1,65.6,50,120,104.4,88.9,73.7,57.8)
x       = cbind(x1,x2,x3)
data    = list(y=y, x=x)
formula = y ~ 1 + x
res     = inla(formula, family="poisson", data=data)
summary(res)

# via MCMC
# Modelo Bayesiano para An�lise Regress�o Linear M�ltipla - Erros Poisson

#model;
#{
#  for ( i in 1:n )
#       {
#         y[i] ~ dpois(mu[i])
#         log(mu[i]) <- beta0 + inprod(x[i, ], beta[])
#       }
#
#         beta0 ~ dnorm( 0, 0.000001 )
#   for (j in 1:P)
#       {
#         beta[j] ~ dnorm( 0, 0.000001 )
#        }
#}

# Somente o Professor:
saida4c = bayes.regmult.poisson(iter=30000,burn=1000,salto=1,y,x)
#            M�dia Desvio-Padr�o  Mediana    P2.5%  P97.5%
#beta0   -0.48068       0.89586 -0.46437 -2.29622 1.21419
#beta[1]  0.57011       0.50862  0.56663 -0.41305 1.56232
#beta[2]  0.17012       0.06770  0.16932  0.03851 0.30392
#beta[3] -0.01380       0.00847 -0.01373 -0.03071 0.00288
#--------------------------------------------#

# Exemplo 5. Beta (regress�o glm)
# Simula��o de dados
set.seed(12345)
n       = 1000
phi     = 5 
z       = rnorm(n, sd=0.2)
eta     = 1 + z
mu      = exp(eta)/(1+exp(eta))
a       = mu * phi
b       = -mu * phi + phi
y       = rbeta(n, a, b)
formula = y ~ 1 + z
res     = inla(formula, data=data.frame(y,z), family="beta")
summary(res)
#--------------------------------------------#

# Exemplo 6. t-Student (regress�o com erros AR1)
set.seed(12345)
n       = 100
phi     = 0.85
mu      = 0.5
eta     = rep(0,n)
for(i in 2:n) eta[i] = mu+phi*(eta[i-1]-mu)+rnorm(1)
nu      = 3
t       = rt(n,df=nu)
y       = eta+t/(sqrt(nu/(nu-2)))
z       = seq(1:n)
data    = list(y=y,z=z)
plot(z,y,type='l') # s�rie temporal
formula = y ~ f(z, model = "ar1")
res     = inla(formula, family="T", data=data)
summary(res)
#--------------------------------------------#

# Exemplo 7. Gamma (regress�o)
# Simula��o de dados
set.seed(12345)
n       = 50
z       = rnorm(n)
eta     = 1 + z
mu      = exp(eta)
prec.scale = runif(n, min = 0.5, max = 2)
prec.par   = 1.2
a       = prec.par * prec.scale
b       = mu/(prec.par * prec.scale)
y       = rgamma(n, shape=a, scale=b)
y
res     = inla(y ~ 1 + z, data=data.frame(y, z), family="gamma")
summary(res)
#--------------------------------------------#

# Exemplo 8. Log�stica (regress�o) com efeito aleat�rio

# Modelo.bug
#model;
# {
#  for (i in 1:N)
#      {
#       y[i] ~ dbinom(p[i],n[i])
#       logit(p[i]) <- alpha+f[i]
#       f[i] ~ dnorm(0,tau) # efeito aleat�rio
#      }
#      alpha ~ dnorm(0,0.000001)
#  log.sigma ~ dunif(0,10000)
#     sigma <- exp(log.sigma)
#       tau <- pow(sigma,-2)
# }
#

rlogistic = function(n, mean=0, sd=1)
{
   p = runif(n)
   A = pi/sqrt(3)
tauA = A/sd^2
return ((tauA * mean - log((1-p)/p))/tauA)
}

# Simula��o de dados
set.seed(12345)
n      = 100
z      = rnorm(n, sd=1)
eta    = 1 + z
mu.eta = mean(eta)
y      = rlogistic(n, mean=eta, sd=1)
dados  = data.frame(y, z)
res    = inla(y ~ 1+z, data=dados, family="logistic",
              control.compute=list(cpo=TRUE))
summary(res)
#--------------------------#

# Algumas op��es interessantes no INLA
res$summary.fixed # somente as sa�das das estimativas dos par�metros
alpha = res$marginals.fixed[[1]]
plot(inla.smarginal(alpha),t="l")
inla.qmarginal(0.05,alpha)
inla.pmarginal(0.911,alpha)
inla.dmarginal(0.911,alpha)
#
plot(res)
# ou esta op��o que cria todos gr�ficos em janelas individuais
plot(res, single = TRUE)
# ou esta op��o indicativa de qual gr�fico deseja conjuntamente
plot(res,
     plot.fixed.effects = TRUE,
     plot.lincomb = FALSE,
     plot.random.effects = FALSE,
     plot.hyperparameters = FALSE,
     plot.predictor = FALSE,
     plot.q = TRUE,
     plot.cpo = TRUE
     )

# Estimativa para a distribui��o preditiva
pred = res$summary.linear.predictor
plot(density(pred[[1]]),main='',xlab="mu.eta",ylab="Densidade",type='l',bty='n')
#--------------------------------------------#

# Exemplo 9.
# Aplica��o (www.r-inla.org/examples/volume-1)

#Regress�o Log�stica com Efeitos Aleat�rios - Aplica��o � dados de sementes
#Este exemplo � uma an�lise aos dados de Crowder (1978 ) e refere-se a
#percentagem de sementes germinadas em que cada uma das 21 placas dispostas
#de acordo com um factorial de 2x2 por "semente" e "tipo de extracto de raiz".
#Os dados s�o mostrados abaixo, em que r e n s�o o n�mero de germina��o
#e o n�mero total de sementes na i-�sia placa, i = 1, ..., n.
#Estes dados tamb�m s�o analisados por Breslow e Clayton (1993).

# Seeds (OpenBUGS vol. I)
# Modelo de efeito fixo
#model;
#{
#   for( i in 1:N)
#   {
#      r[i] ~ dbin(p[i],n[i])
#      logit(p[i]) <- alpha0+alpha1*x1[i]+alpha2*x2[i]+alpha12*x1[i]*x2[i]
#   }
#   alpha0 ~ dnorm(0,0.000001)
#   alpha1 ~ dnorm(0,0.000001)
#   alpha2 ~ dnorm(0,0.000001)
#   alpha12 ~ dnorm(0,0.000001)
#}
   
 # Modelagem via INLA (Com efeito aleat�rio)
data(Seeds)
formula = r ~ x1+x2+x1*x2
mod.seeds = inla(formula, data=Seeds, family="binomial", Ntrials=n)
summary(mod.seeds)

# Estimativa via MCMC
#saida9a = bayes.reg.binomial2i(iter=10000,burn=1000,salto=1,dados=Seeds) 
#           mean     sd MC_error val2.5pc  median val97.5pc start sample
#alpha0  -0.5601 0.1240 0.001441  -0.8022 -0.5587   -0.3219  1001  10000
#alpha1   0.1440 0.2214 0.002466  -0.2911  0.1422    0.5818  1001  10000
#alpha2   1.3220 0.1766 0.001961   0.9749  1.3200    1.6710  1001  10000        
#alpha12 -0.7755 0.3063 0.003309  -1.3810 -0.7741   -0.1711  1001  10000
#--------------------------------------------#

# Modelo de efeito aleat�rio
#model;
#{
# for(i in 1:N)
#    {
#        r[i] ~ dbin(p[i],n[i])
#        b[i] ~ dnorm(0,tau)
#        logit(p[i]) <- alpha0+alpha1*x1[i]+alpha2*x2[i]+alpha12*x1[i]*x2[i]+b[i]
#    }
#        alpha0 ~ dnorm(0,0.000001)
#        alpha1 ~ dnorm(0,0.000001)
#        alpha2 ~ dnorm(0,0.000001)
#        alpha12 ~ dnorm(0,0.000001)
#        tau ~ dgamma(0.001,0.001)
#        sigma <- 1 / sqrt(tau)
#}

# Modelagem via INLA (Com efeito aleat�rio)
data(Seeds)
formula   = r ~ x1+x2+x1*x2+f(plate,model="iid")
mod.seeds = inla(formula, data=Seeds, family="binomial", Ntrials=n)
summary(mod.seeds)

# via MCMC
# Somente professor:
#saida9b = bayes.reg.binomial2iEA(iter=200000,burn=10000,salto=1,dados=Seeds) 
#            mean       sd MC_error val2.5pc   median val97.5pc start sample
#alpha0  -0.55220   0.1929 0.001024 -0.93670 -0.55170  -0.16650 10001 200000
#alpha1   0.08426   0.3135 0.001392 -0.55920  0.09186   0.68570 10001 200000
#alpha2   1.35300   0.2733 0.001539  0.82690  1.34600   1.91600 10001 200000
#alpha12 -0.82690   0.4375 0.002142 -1.71400 -0.82030   0.01769 10001 200000
#sigma    0.28540   0.1428 0.001647  0.04806  0.27670   0.59730 10001 200000     
#***************************************************************************

# Pacote bastante completo para Infer�ncia Bayesiana

library(LaplacesDemon) 
vignette('Examples', package='LaplacesDemon')
?LaplacesDemon #Diferentes algoritmos de estima��o

# Exemplo: An�lise de ponto de mudan�a
https://github.com/curso-r/curso-r.github.com/blob/master/posts/aula08.Rmd

N = 29
y = c(1.12, 1.12, 0.99, 1.03, 0.92, 0.90, 0.81, 0.83, 0.65, 0.67, 0.60,
       0.59, 0.51, 0.44, 0.43, 0.43, 0.33, 0.30, 0.25, 0.24, 0.13, -0.01,
      -0.13, -0.14, -0.30, -0.33, -0.46, -0.43, -0.65)
x = c(-1.39, -1.39, -1.08, -1.08, -0.94, -0.80, -0.63, -0.63, -0.25, -0.25,
       -0.12, -0.12, 0.01, 0.11, 0.11, 0.11, 0.25, 0.25, 0.34, 0.34, 0.44,
        0.59, 0.70, 0.70, 0.85, 0.85, 0.99, 0.99, 1.19)

library(dplyr)
library(ggplot2)		
data_frame(x, y) %>% ggplot() + geom_point(aes(x=x, y=y))

# Queremos ajustar no gr�fico um modelo linear de ponto de mudan�a,
# que vai ajustar duas retas, uma antes e outra depois de certo ponto.
# O ponto de mudan�a � determinado pelo modelo.

# Dados

# No LD, dados n�o s�o especificados em um `data.frame`.
# Ao inv�s disso, temos de criar uma lista contendo,
# al�m dos dados, algumas informa��es iniciais, como

mon.names  = "LP" # vari�veis para monitoramento. No caso, Log Posterior
parm.names = as.parm.names(list(alpha=0, beta=rep(0,2), sigma=0, theta=0)) # nomes dos par�metros
pos.alpha  = grep("alpha", parm.names) # posi��o do par�metro alpha
pos.beta   = grep("beta",  parm.names) # posi��o dos par�metros beta
pos.sigma  = grep("sigma", parm.names) # posi��o do par�metro sigma
pos.theta  = grep("theta", parm.names) # posi��o do par�metro theta

# Fun��o que gera valores iniciais para os par�metros.
# No caso, sem muito crit�rio.
PGF    =  function(Data) return(c(rnorm(1), rnorm(2), runif(1), runif(1)))
MyData =  list(N=N, 
               PGF=PGF, 
               mon.names=mon.names, 
               parm.names=parm.names,
               pos.alpha=pos.alpha, 
               pos.beta=pos.beta, 
               pos.sigma=pos.sigma,
               pos.theta=pos.theta, 
               x=x, 
               y=y)

# O Modelo

# No LD precisamos espeficiar uma fun��o `Model` que ser� respons�vel
# por calcular as informa��es necess�rias para atualiza��o do modelo.
# A fun��o recebe um vetor num�rico de par�metros, e a lista com os dados,
# e retorna uma lista contendo a `LP` (log posteriori sem normaliza��o) calculada,
# o `Dev` (deviance), as informa��es monitoradas (no caso, LP),
# um `yhat` (chute para o valor de y, de acordo com os par�metros calculados),
# e `parm` o vetor de par�metros (usualmente ajustado para ficar dentro do espa�o param�trico).

Model = function(parm, Data)
{  
  # Par�metros
  alpha = parm[Data$pos.alpha]
  beta  = parm[Data$pos.beta]
  sigma = interval(parm[Data$pos.sigma], 1e-100, Inf)
  parm[Data$pos.sigma] = sigma # atualiza o valor para retornar depois
  theta = interval(parm[Data$pos.theta], -1.3, 1.1)
  parm[Data$pos.theta] = theta # atualiza o valor para retornar depois
  
  # Log-Prior (calcula com base nas fun��es das prioris predefinidas)
  alpha.prior = dnormv(alpha, 0, 1000, log=TRUE)
  beta.prior  = sum(dnormv(beta, 0, 1000, log=TRUE))
  sigma.prior = dhalfcauchy(sigma, 25, log=TRUE)
  theta.prior = dunif(theta, -1.3, 1.1, log=TRUE)
  
  # Log-Likelihood (calcula a log-verossimilhan�a com base no modelo concebido)
  mu = alpha + beta[1]*x + beta[2]*(x - theta)*((x - theta) > 0)
  LL = sum(dnorm(Data$y, mu, sigma, log=TRUE))
  
  # Log-Posterior (calcula a log posteriori)
  LP =  LL + alpha.prior + beta.prior + sigma.prior + theta.prior
  
  Modelout = list(LP=LP, 
                  Dev=-2*LL, 
                  Monitor=LP, 
                  yhat=rnorm(length(mu), mu, sigma), 
                  parm=parm)
  
  return(Modelout)
}

# Atualiza��o ("ajuste")
set.seed(666) # reprodutibilidade

# valores iniciais da cadeia
Initial.Values = c(0.5, -0.4, -0.6, 0.02, 0.04) 

Fit = LaplacesDemon(Model, MyData, Initial.Values, 
                    Iterations = 1000000, 
                    Status     = 100000,
                    Thinning   = 1000,
                    Algorithm  = "HARM")
print(Fit)
Consort(Fit)

# Plotando resultados
# Diagn�stico
plot(Fit, BurnIn=100000, MyData, PDF=FALSE, Parms=NULL)

# Resultados
caterpillar.plot(Fit, Parms=c("beta", 'theta'))

# Valores preditos
Pred = predict(Fit, Model, MyData)
plot(Pred, Style="Fitted")

# Um gr�fico muito dif�cil para frequentistas
m = Fit$Posterior2 %>% data.frame %>% summarise_each(funs(median))

data_frame(x, y) %>% 
  ggplot() + 
  geom_point(aes(x=x, y=y)) +
  geom_segment(x=-1.5, xend=m$theta, y=m$alpha + m$beta.1. * (-1.5), 
               yend=m$alpha + m$beta.1. * (m$theta)) +
  geom_segment(x=m$theta, xend=1.2, y=m$alpha + m$beta.1. * (m$theta), 
               yend=m$alpha + m$beta.1. * (1.2) + m$beta.2.*(1.2-m$theta)) +
  geom_point(aes(x=theta, y=alpha + beta.1. * theta), 
             data=data.frame(Fit$Posterior2), alpha=.05,
             colour='red')

# Zoom			 
data_frame(x, y) %>% 
  ggplot() + 
  geom_point(aes(x=x, y=y)) +
  geom_segment(x=-1.5, xend=m$theta, y=m$alpha + m$beta.1. * (-1.5), 
               yend=m$alpha + m$beta.1. * (m$theta)) +
  geom_segment(x=m$theta, xend=1.2, y=m$alpha + m$beta.1. * (m$theta), 
               yend=m$alpha + m$beta.1. * (1.2) + m$beta.2.*(1.2-m$theta)) +
  geom_density2d(aes(x=theta, y=alpha + beta.1. * theta), 
             data=data.frame(Fit$Posterior2), 
             colour='red') +
  scale_x_continuous(limits=c(-.25,.25)) +
  scale_y_continuous(limits=c(.25,.75))
  
# Observa��o: Comparando modelos via 'Fator de Bayes'
?BayesFactor 
#***************************************************************************

# JASP (Jeffrey�s Amazing Statistics Program)
# Mark A. Goss-Sampson - Amsterdam, 2016.

# JASP Team. (2022). JASP (Version 0.16.4) [Computer software]. Retrieved from https://jasp-stats.org

https://jasp-stats.org

# Programa:
https://jasp-stats.org/download       #[JASP 0.16.4 (2022)]

# JASP online (� necess�rio criar uma conta):
https://www.rollapp.com/launch/jasp   #[JASP 0.14 (2022)]

# Materiais:
https://jasp-stats.org/jasp-materials # Manuais/data sets
https://jasp-stats.org/jasp-workshop-materials

# Livros:
https://learnstatswithjasp.com
https://www.amazon.com/dp/1660228182

# V�deo-Aula:
https://www.youtube.com/watch?v=HxqB7CUA-XI

# Dados:
http://bit.ly/2wlbMvf
