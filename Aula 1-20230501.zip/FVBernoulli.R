# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#

# Distribui��o de probabilidade discreta
# Dados dicot�micos: Y ~ Bernoulli(theta)

rm(list=ls(all=TRUE))

# Logaritmo da Fun��o de Verossimilhan�a da Bernoulli (logFV)
lvero.bern = function(t,n,theta)
{
   t*log(theta)+(n-t)*log(1-theta)
}  

# Simula��o
t = 9
n = 30
theta.aux = seq(0.001,0.999,0.01)   # vetor de valores entre 0 e 1
l.theta = lvero.bern(t,n,theta.aux) # respectivos c�lculos na logFV

# Gr�fico do logFV
# Op��o 1:
plot(theta.aux,l.theta,type='l',bty='n',xlab='theta',ylab='l(theta|y)')

# Op��o 2:
library(rpanel)
rp.likelihood("sum(log(dbinom(data, size=n, theta)))", t, 0, 1)

# Estimador Frequentista
theta.est = t/n # e.m.v.
theta.est

# Intervalo com 95% de Confian�a Assint�tico
var.est  = n/(theta.est*(1-theta.est))  # vari�ncia estimada de e.m.v
IC.theta = theta.est+qnorm(c(0.025,0.975))*sqrt(1/var.est)
IC.theta

# Gr�fico da Fun��o de verossimilhan�a: T|theta ~ Bin(n,theta)
veross    = rbinom(1000, n, theta.est)
theta.est = veross/n
hist(theta.est, main="", xlab=expression(paste(theta)),
     ylab=expression(paste("L(",theta, "|T)")), col="gray", bty='n')
