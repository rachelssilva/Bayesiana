# Programa��o Bayesiana             #
# Disciplina: Estat�stica Bayesiana #
# Curso: Estat�stica                #
# Prof. Dr. Robson M. Rossi         #
#-----------------------------------#
# Material did�tico sugerido:
# 1) Introdu��o aos m�todos Bayesianos na an�lise de dados zoot�cnicos
#    com uso do WinBUGS e R (ROSSI, 2011)
# 2) Bayesian Population Analysis Using Winbugs:
#    A hierarchical perspective (KERY e SCHAUB, 2012)
# 3) Bayesian Modeling Using WinBUGS (NTZOUFRAS, 2009)
# 4) Bayesian Computation with R (ALBERT,2007)
#--------------------------------------------#

# Simula��o de algumas distribui��es de probabilidade

install.packages("gamlss.demo") # Pacote completo
library(gamlss.demo)	
demoDist()

# Op��o por implementa��o manual
# Material do curso "Explorando interfaces gr�ficas com o R"
# Prof. Dr. Walmes M. Zeviani (UFPR)
# www.leg.ufpr.br - walmes@ufpr.br
# Eduardo E. Ribeiro Jr
# www.pet.est.ufpr.br - edujrrib@gmail.com

## Pacote para janelas interativas
library(rpanel)

## -------------------- Distribui��es Discretas ------------------------

# OBSERVA��O: SE N�O FUNCIONAR NO RSTUDIO, ABRIR EM OUTRO EDITOR!

## Distribui��o Binomial

pb = function(panel)
{
  with(panel,
{
  x = 0:size
  p = dbinom(x, size=size, prob=prob)
  plot(p~x, type="h", ylim=c(0,max(c(p), 0.5)), ylab= "P(x)", bty="n", main="Binomial")
  if(showEX)  { abline(v=size*prob, col=2) }
  if(showDPX)
    {
    dp = sqrt(size*prob*(1-prob))
	text(0, 0.5, "DP(X) =", cex = 0.6)
	text(1, 0.5, round(dp,3), cex = 0.6)
    }
}
)
panel
}

panel = rp.control(title="Binomial", size=c(300,100))
rp.slider(panel, size, from=2, to=100, initval=10, resolution=1,
          action=pb, showvalue=TRUE, title="n")
rp.slider(panel, prob, from=0.01, to=0.99, initval=0.5, resolution=0.01,
          action=pb, showvalue=TRUE, title="p (probabilidade)")
rp.checkbox(panel, showEX, action=pb, title="E(X)",
            labels="Mostrar o valor esperado")
rp.checkbox(panel, showDPX, action=pb, title="DP(X)",
            labels="Mostrar o desvio-padr�o")			
##----------------------------------------------------------------------

## Distribui��o de Poisson

pp = function(panel)
{
  with(panel,
{
  x = 0:10
  p = dpois(x, lambda=lambda)
  plot(p~x, type="h", ylim=c(0,max(c(p),0.5)), ylab= "P(x)", bty="n", main="Poisson")
  if(showEX){ abline(v=lambda, col=2) }
}
)
panel
}

panel = rp.control(title="Poisson", size=c(300,100))
rp.slider(panel, lambda, from=0, to=10, initval=1, resolution=1,
          action=pp, showvalue=TRUE, title="lambda (m�dia)")
rp.checkbox(panel, showEX, action=pp, title="E(X)",
            labels="Mostrar o valor esperado")
##----------------------------------------------------------------------

## Distribui��o Binomial Negativa

pbn = function(panel)
{
  with(panel,
{
  x = 0:size
  p = dnbinom(x, size=size, prob=prob)
  plot(p~x, type="h", ylim=c(0,max(c(p), 0.5)), ylab= "P(x)", bty="n", main="Binomial Negativa")
  if(showEX){ abline(v=size*(1-prob)/prob, col=2) }
}
)
panel
}

panel = rp.control(title="Binomial Negativa", size=c(300,100))
rp.slider(panel, size, from=2, to=80, initval=10, resolution=1,
          action=pbn, showvalue=TRUE, title="n")
rp.slider(panel, prob, from=0.01, to=0.99, initval=0.5, resolution=0.01,
          action=pbn, showvalue=TRUE, title="p (probabilidade)")
rp.checkbox(panel, showEX, action=pbn, title="E(X)",
            labels="Mostrar o valor esperado")
##----------------------------------------------------------------------

## Distribui��o Hipergeom�trica

## m n�mero de bolas brancas em uma urna
## n n�mero de bolas pretas em uma urna
## k n�mero de bolas retiradas da urna
## x n�mero de bolas brancas retiradas sem reposi��o da urna

ph = function(panel)
{
  with(panel,
{
  x = max(c(0, k-m)):min(c(k, m))
  ## p(x) = choose(m, x) choose(n, k-x) / choose(m+n, k)
  p = dhyper(x, m=m, n=n, k=k)
  plot(p~x, type="h", ylim=c(0, max(c(p), 0.5)), ylab= "P(x)", bty="n", main="Hipergeom�trica")
  if(showEX){ abline(v=k*m/(m+n), col=2) }
}
)
panel
}

panel = rp.control(title="Hipergeom�trica", size=c(300,100))
rp.slider(panel, m, from=5, to=30, initval=10, resolution=1,
          action=ph, showvalue=TRUE, title="Brancas")
rp.slider(panel, n, from=2, to=15, initval=5, resolution=1,
          action=ph, showvalue=TRUE, title="Pretas")
rp.slider(panel, k, from=2, to=15, initval=5, resolution=1,
          action=ph, showvalue=TRUE, title="Retiradas")
rp.checkbox(panel, showEX, action=ph, title="E(X)",
            labels="Mostrar o valor esperado")

## *********************** Distribui��es Cont�nuas *********************

## Distribui��o Normal (Gaussiana)

pn = function(panel)
{
  with(panel,
{
  curve(dnorm(x, mean=mean, sd=sd), -5, 5, ylab="f(x)", ylim=c(0,1), bty="n", main="Normal")
  if(showEX)
  {
    abline(v=mean, col=2)
  }
  if(showDPX)
  {
    segments(mean, -0.01, mean+sd, -0.01, col=4)
  }
}
)
panel
}

panel = rp.control(title="Normal", size=c(300,100))
rp.slider(panel, mean, from=-4, to=4, initval=0, resolution=0.1,
          action=pn, showvalue=TRUE, title="mu (m�dia)")
rp.slider(panel, sd, from=0, to=3, initval=1, resolution=0.1,
          action=pn, showvalue=TRUE, title="sigma (desvio-padr�o)")
rp.checkbox(panel, showEX, action=pn, title="E(X)",
            labels="Mostrar o valor esperado")
rp.checkbox(panel, showDPX, action=pn, title="DP(X)",
            labels="Mostrar o desvio-padr�o")
##----------------------------------------------------------------------

## Distribui��o Beta

pbt = function(panel)
{
  with(panel,
{
  curve(dbeta(x, shape1=sh1, shape2=sh2), 0, 1, ylab="f(x)",
        ylim=c(0,10), bty="n", main="Beta")
  if(showEX)
    {
	media = sh1/(sh1+sh2)
    abline(v=media, col=2)
    text(media+0.05, 0, round(media,3), cex = 0.6)
   }
  if(showDPX)
    {
    dp = sqrt(sh1*sh2/((sh1+sh2)*(sh1+sh2)^2))
	text(0.1, 10, "DP(X) =", cex = 0.6)
	text(0.2, 10, round(dp,3), cex = 0.6)
    }
}
)
panel
}

panel = rp.control(title="Beta", size=c(300,100))
rp.slider(panel, sh1, from=-5, to=5, initval=0, resolution=0.1,
          action=pbt, showvalue=TRUE, title="shape1")
rp.slider(panel, sh2, from=-5, to=5, initval=0, resolution=0.1,
          action=pbt, showvalue=TRUE, title="shape2")
rp.checkbox(panel, showEX, action=pbt, title="E(X)",
            labels="Mostrar o valor esperado")
rp.checkbox(panel, showDPX, action=pbt, title="DP(X)",
            labels="Mostrar o desvio-padr�o")
##----------------------------------------------------------------------

## Distribui��o Gamma

pg = function(panel)
{
  with(panel,
{
  curve(dgamma(x, shape=shape, scale=scale), 0, 50, ylim=c(0, 0.25),
               ylab="f(x)", bty="n", main="Gamma")
  if(showEX)
    {
	media = shape*scale
	abline(v=media, col=2)
	text(media+1, 0, round(media,3), cex = 0.6)
	}
  if(showDPX)
    {
    dp = sqrt(shape*scale^2)
	text(0.1, 0.25, "DP(X) =", cex = 0.6)
	text(3, 0.25, round(dp,3), cex = 0.6)
    }
}
)
panel
}

panel = rp.control(title="Gamma", size=c(300,100))
rp.slider(panel, shape, from=0.1, to=20, initval=5, resolution=0.1,
          action=pg, showvalue=TRUE, title="shape (forma)")
rp.slider(panel, scale, from=0.1, to=10, initval=3, resolution=0.1,
          action=pg, showvalue=TRUE, title="scale (escala)")
rp.checkbox(panel, showEX, action=pg, title="E(X)",
            labels="Mostrar o valor esperado")
rp.checkbox(panel, showDPX, action=pg, title="DP(X)",
            labels="Mostrar o desvio-padr�o")			
##----------------------------------------------------------------------

## Distribui��o Weibull

pw = function(panel)
{
  with(panel,
{
  curve(dweibull(x, shape=shape, scale=scale), 0, 50, ylim=c(0, 0.25),
        ylab="f(x)", bty="n", main="Weibull")
  if(showEX)
  {
    media = scale*gamma(1+1/shape)
	abline(v=media, col=2)
	text(media+2, 0, round(media,3), cex = 0.6)
  }
  if(showDPX)
    {
    dp = sqrt(scale^2 * (gamma(1 + 2/shape) - (gamma(1 + 1/shape))^2))
	text(0.1, 0.25, "DP(X) =", cex = 0.6)
	text(3, 0.25, round(dp,3), cex = 0.6)
    }  
}
)
panel
}

panel = rp.control(title="Weibull", size=c(300,100))
rp.slider(panel, shape, from=0.1, to=10, initval=5, resolution=0.1,
          action=pw, showvalue=TRUE, title="shape (forma)")
rp.slider(panel, scale, from=0.1, to=30, initval=20, resolution=0.1,
          action=pw, showvalue=TRUE, title="scale (escala)")
rp.checkbox(panel, showEX, action=pw, title="E(X)",
            labels="Mostrar o valor esperado")
rp.checkbox(panel, showDPX, action=pw, title="DP(X)",
            labels="Mostrar o desvio-padr�o")				
##**********************************************************************

# Fun��o com todas elas juntas:
panel = rp.control(title="Distribui��es Estat�sticas")
rp.notebook(panel,
            tabs=c(
              "Binomial", "Poisson", "BinNeg", "Hiperg",
              "Normal", "Beta", "Gamma", "Weibull"),
            width=600, height=400,
            pos=list(row=0, column=0),
            ## background="red",
            ## font="Arial",
            name="main")
##--------------------------------------------
	
# Binomial			
rp.slider(panel, size, from=2, to=100, initval=10, resolution=1,
          action=pb, showvalue=TRUE, title="n",parentname="Binomial")
rp.slider(panel, prob, from=0.01, to=0.99, initval=0.5, resolution=0.01,
          action=pb, showvalue=TRUE, title="p (probabilidade)",parentname="Binomial")
rp.checkbox(panel, showEX, action=pb, title="E(X)",
            labels="Mostrar o valor esperado",parentname="Binomial")
rp.checkbox(panel, showDPX, action=pb, title="DP(X)",
            labels="Mostrar o desvio-padr�o",parentname="Binomial")				
##--------------------------------------------

# Poisson
rp.slider(panel, lambda, from=0.5, to=90, initval=10, resolution=0.25,
          action=pp, showvalue=TRUE, title="lambda (m�dia)",parentname="Poisson")
rp.checkbox(panel, showEX, action=pp, title="E(X)",
            labels="Mostrar o valor esperado",parentname="Poisson")
##--------------------------------------------

# Binomial Negativa
rp.slider(panel, size, from=2, to=80, initval=10, resolution=1,
          action=pbn, showvalue=TRUE, title="n", parentname="BinNeg")
rp.slider(panel, prob, from=0.01, to=0.99, initval=0.5, resolution=0.01,
          action=pbn, showvalue=TRUE, title="p (probabilidade)", parentname="BinNeg")
rp.checkbox(panel, showEX, action=pbn, title="E(X)",
            labels="Mostrar o valor esperado", parentname="BinNeg")			
##--------------------------------------------

## Hipergeom�trica
rp.slider(panel, m, from=5, to=30, initval=10, resolution=1,
          action=ph, showvalue=TRUE, title="Brancas", parentname="Hiperg")
rp.slider(panel, n, from=2, to=15, initval=5, resolution=1,
          action=ph, showvalue=TRUE, title="Pretas", parentname="Hiperg")
rp.slider(panel, k, from=2, to=15, initval=5, resolution=1,
          action=ph, showvalue=TRUE, title="Retiradas", parentname="Hiperg")
rp.checkbox(panel, showEX, action=ph, title="E(X)",
            labels="Mostrar o valor esperado", parentname="Hiperg")
##--------------------------------------------

## Normal
rp.slider(panel, mean, from=-4, to=4, initval=0, resolution=0.1,
          action=pn, showvalue=TRUE, title="mu (m�dia)", parentname="Normal")
rp.slider(panel, sd, from=0, to=3, initval=1, resolution=0.1,
          action=pn, showvalue=TRUE, title="sigma (desvio-padr�o)", parentname="Normal")
rp.checkbox(panel, showEX, action=pn, title="E(X)",
            labels="Mostrar o valor esperado", parentname="Normal")
rp.checkbox(panel, showDPX, action=pn, title="DP(X)",
            labels="Mostrar o desvio-padr�o", parentname="Normal")
##--------------------------------------------

## Beta
rp.slider(panel, sh1, from=-5, to=5, initval=0, resolution=0.1,
          action=pbt, showvalue=TRUE, title="shape1", parentname="Beta")
rp.slider(panel, sh2, from=-5, to=5, initval=0, resolution=0.1,
          action=pbt, showvalue=TRUE, title="shape2", parentname="Beta")
rp.checkbox(panel, showEX, action=pbt, title="E(X)",
            labels="Mostrar o valor esperado", parentname="Beta")
rp.checkbox(panel, showDPX, action=pbt, title="DP(X)",
            labels="Mostrar o desvio-padr�o", parentname="Beta")
##--------------------------------------------

## Gamma
rp.slider(panel, shape, from=0.1, to=20, initval=5, resolution=0.1,
          action=pg, showvalue=TRUE, title="shape (forma)", parentname="Gamma")
rp.slider(panel, scale, from=0.1, to=10, initval=3, resolution=0.1,
          action=pg, showvalue=TRUE, title="scale (escala)", parentname="Gamma")
rp.checkbox(panel, showEX, action=pg, title="E(X)",
            labels="Mostrar o valor esperado", parentname="Gamma")
rp.checkbox(panel, showDPX, action=pg, title="DP(X)",
            labels="Mostrar o desvio-padr�o", parentname="Gamma")
##--------------------------------------------

## Weibull
rp.slider(panel, shape, from=0.1, to=10, initval=5, resolution=0.1,
          action=pw, showvalue=TRUE, title="shape (forma)", parentname="Weibull")
rp.slider(panel, scale, from=0.1, to=30, initval=20, resolution=0.1,
          action=pw, showvalue=TRUE, title="scale (escala)", parentname="Weibull")
rp.checkbox(panel, showEX, action=pw, title="E(X)",
            labels="Mostrar o valor esperado", parentname="Weibull")
rp.checkbox(panel, showDPX, action=pw, title="DP(X)",
            labels="Mostrar o desvio-padr�o", parentname="Weibull")
			